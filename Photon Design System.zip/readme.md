# Photon Design System

Photon is a Windows desktop app: a smoked-glass window that opens from a global shortcut (Win+Alt+Espace by default) and replaces the desktop with a **grid of widgets you arrange yourself** — clock, system load, disks, app launcher, weather, calendar, to-do, notes, pomodoro, sound, YT Music, network, folders and a Claude assistant. A second shortcut (Alt+Espace) opens the **command bar alone** (search apps/files/sites, calculate, run commands, ask Claude). Users keep several **profiles** (Principal, Travail, Focus, Chill, Gaming…) and switch with Ctrl+1…9.

The product UI is entirely in **French**. Stack: Electron + Svelte 5 + TypeScript + gridstack.js.

## Sources

- Codebase: `ergo-app/` (local mount, read-only). Key files: `src/renderer/app.css` (tokens), `src/renderer/App.svelte` (shell), `src/renderer/grid/WidgetFrame.svelte` (glass card), `src/renderer/bar/CommandBar.svelte`, `src/renderer/profiles/Profiles.svelte`, `src/renderer/theme/SettingsPanel.svelte`, `src/renderer/widgets/*/`, `src/shared/model.ts` (theme defaults), `src/shared/templates.ts` (profile templates), (logo and background deliberately excluded — see below).
- Design doc referenced by the codebase as source of truth: https://claude.ai/artifact/PozosXRE6sFL3Cmswz6uB1 (not accessed).
- Font: Satoshi (Indian Type Foundry, ITF Free Font License) — `fonts/Satoshi-Variable.woff2`, copied from the repo.
- Icons: Phosphor (MIT) — the app uses `phosphor-svelte`; here we load `@phosphor-icons/web@2.1.1` from CDN (same glyphs).

## Index

- `styles.css` — entry point; `@import`s only.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `effects.css` (glass, radii, shadows), `motion.css`, `base.css`.
- `fonts/` — Satoshi variable woff2.
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Effects, Brand).
- `components/` — React primitives (see list below), one `@dsCard` per folder.
- `ui_kits/photon/` — interactive recreation of the app (`index.html`) and the mini command bar (`mini.html`).
- `thumbnail.html` — homepage tile. `SKILL.md` — Agent Skill entry.

## Components

- **icons/** — `Icon` (Phosphor web-font wrapper)
- **actions/** — `Button`, `IconButton`, `PlayButton`, `Chip`, `FileChip`
- **forms/** — `TextField`, `Segmented`, `Slider`, `Checkbox`, `Select`, `Swatch`
- **glass/** — `WidgetCard`, `Menu`, `MenuItem`, `MenuLabel`, `Drawer`, `DrawerSection`
- **data/** — `WidgetLabel`, `RollingNumber`, `MeterBar`, `ProgressRing`
- **navigation/** — `CommandBar`, `ResultItem`, `ResultIcon`, `ProfilePills`, `ProfilePill`, `Kbd`
- **feedback/** — `Approval`

The codebase has no formal component library; these primitives are lifted from the shared CSS classes (`.action`, `.menu`, range inputs) and the repeated widget patterns (glass card, uppercase label, meter bar, ring, pills, chips, approval box).

**Intentional additions:** `Icon` — wraps the Phosphor web font so components and kits share one glyph API (the app imports Svelte icon components instead).

## UI kits

- `ui_kits/photon/index.html` — fullscreen glass window. Click profiles (or Ctrl+1…5), type in the command bar (try « spo », « 42*36 », « réglages », « éteindre »), pencil = edit mode (remove badges, « Ajouter » menu, rename profile, Focus toggle), gear = settings drawer (accent, blur, opacity, radius, density, mode apply live). Widgets: all 14.
- `ui_kits/photon/mini.html` — mini-mode command bar window.

---

## CONTENT FUNDAMENTALS

- **Language:** French throughout, including key names (Entrée, Échap, Maj, Espace) and units with a non-breaking space before them: « 48 px », « 50 % », « 31,8 Go », « 412 Go libres sur C: ». Decimal comma. Dates via `fr-FR` with an initial capital: « Samedi 1 novembre ».
- **Voice:** informal **tu**. « Glisse un raccourci ici », « Connecte ton compte Google une fois. », « Pose une question, glisse un fichier ou colle une capture. », « Claude demande ton accord ». The app never says « je »; it describes what happens.
- **Casing:** sentence case for everything — buttons, menu items, headings (« Couleur d'accent », « Barre de commande seule »). Uppercase only via CSS on widget labels and drawer section heads.
- **Labels:** one or two nouns — « Système », « Disque », « Apps », « Agenda », « To-do », « Son », « Réseau », « Favoris », « Récents ». Buttons are bare verbs or past participles: « Ajouter », « Terminé », « Réessayer », « Autoriser », « Refuser », « Activer », « Annuler ».
- **Messages:** short, factual, no exclamation marks, no apology. « Ce widget a rencontré un problème. » · « Lecture impossible » · « Lecteur absent » · « Rien de prévu sur 14 jours » · « Son indisponible » · « Claude Code est introuvable » · « Impossible d'ouvrir ».
- **Hints explain the next step concretely:** « Clique sur le crayon en haut à droite, puis sur « Ajouter ». » · « Google Agenda › Paramètres de l'agenda › Adresse secrète au format iCal » (› as a path separator).
- **Confirmation by repetition:** dangerous commands say « Entrée encore une fois pour confirmer »; deleting a profile turns the button into « Supprimer ? ».
- **Punctuation:** French guillemets « » with spaces, ellipsis character « … » in placeholders and buttons that open a picker (« Choisir une image… », « Rechercher, calculer, demander à Claude… »), middle dot · as a separator (« Lyon · 8° / 14° »), em dash — for empty values.
- **Emoji:** never. Unicode symbols used: — (no data), ° , ›, ·, ↑ ↓ in docs only.
- **Vibe:** calm, precise, utilitarian; a tool that stays out of the way.

## VISUAL FOUNDATIONS

- **Direction « lumière »:** smoked dark glass with luminous accents. Dark only (`color-scheme: dark`); there is no light theme.
- **Colour:** near-black base `#07080b`, text `#f3f4f6` / muted `#a3a8b3` / faint `#8b909b`. One **accent**, live-themed: by default extracted from the wallpaper (average of saturated pixels, normalised to saturation ≥ .55, lightness .62–.78), otherwise a preset — Bleu `#7CC4FF` (default), Violet `#B69CFF`, Orange `#FFB86B`, Menthe `#6EF2C2` — or any hex. Text on accent is `#07080b` or white by WCAG luminance. Secondary glow violet `#7a5cff`. Danger `#ff4d5e` with soft pink text `#ff9aa8`. Everything else is white or black at low alpha (4–18 %).
- **Backgrounds:** ⚠️ the product's background treatment has changed since the code this system was built from, so it is **not documented here**. The UI kit uses a flat `--bg` placeholder. The glass panel is designed to blur whatever sits behind it.
- **Glass recipe:** fill `rgb(16 18 24 / var(--glass))` (opacity 0.5 default) + diagonal sheen `linear-gradient(165deg, white 11 % → 3 % at 38 % → 1.5 %)`, 1px edge `white 13 %`, inset rim `0 1px 0 white 24 %` + `0 -1px 0 white 5 %`, `backdrop-filter: blur(48px) saturate(1.7)`. Menus blur 24, drawer 30. Widget cards carry only the sheen (they sit on the blurred panel).
- **Type:** Satoshi variable, single family. Body 14px; secondary 13; labels 12 uppercase 0.1em faint; small 11. Titles 18/600/−0.01em. Big numerals are **Light 300** with −0.04em tracking and tabular figures (clock up to 96px, temperature 44, free space 40). Changing numbers roll digit-by-digit on a spring.
- **Spacing:** panel padding 24, gap 20; widget padding fluid `clamp(12px, 9cqmin, 20px)` (up to 24–28); grid 12 columns × 100px rows, 10px margin per side (compact: 80 / 6). Exact values like 5, 7, 14, 18 px are used as-is.
- **Corner radii:** generous and nested — panel 28 (= card + 8), card 20 (user-tunable 0–40), popover 18, tile/composer 16, menu 14, row 12, input 10, icon tile 9, kbd 6. Every button, pill, chip and segmented control is fully round (999px).
- **Cards:** glass sheen, 1px glass edge, rim, drop `0 10px 30px -14px rgb(0 0 0 / .55)`. No coloured borders at rest, no left stripes.
- **Shadows:** always long, soft, negative-spread drops paired with the inset rim: menu `0 16px 40px -16px /.6`, popover/drawer `0 24px 60px -20px /.7`, panel `0 40px 100px -30px /.65`.
- **Glow:** accent light is the signature. Meter fills `box-shadow 0 0 10px accent`; live dots `0 0 8px`; pomodoro ring drop-shadow; card hover adds a 55 % accent border, a `0 0 40px -12px` halo and a 220px radial spot that **follows the cursor inside a 1px masked ring**.
- **Hover:** cards lift `translateY(-2px)` and light up (opacity transition 200ms). Buttons/rows go from transparent or white 5 % to white 6–9 %; muted text goes to full `--text`. Remove badges turn pink on `#2a1d22`.
- **Press:** scale down — cards .97 (120ms ease-out), buttons .97, pills .96, chips .95, round controls .9 — then **spring back** over 300–450ms with the 12 %-overshoot `--ease-spring`.
- **Selection:** accent 16 % fill + accent 45 % border (active profile, current audio device); segmented controls use solid accent with `--on-accent` text; focus ring 2px accent, offset 2.
- **Animation:** transform and opacity only, everything < 300ms. Opening: a circle of accent light bursts from the cursor (280ms) and `[data-reveal]` elements cascade in from `translateY(8px) scale(.98)` over 180ms, delayed by distance (max 100ms). Profile switch: 220ms fade. Drawer: 180ms fade + 16px slide. Meter fills animate `scaleX` over 400ms. « Réduire les animations » sets every duration to 0.
- **Transparency & blur:** only on chrome that floats over content (panel, menus, drawer, command results). Content inside cards is opaque text on glass.
- **Imagery:** none of its own; album art tints the music widget with a saturated radial wash of its average colour. App/file icons are the real Windows icons; fallback is a duotone Phosphor glyph in accent.
- **Layout:** fullscreen panel `min(1280px, 100% − 96px)` centred with 48px margins; header row (name « Photon » 18/600, profile pills, centred command bar max 560px, actions right). In window mode the panel is the window and the header drags it. Cards never scroll internally except Claude's thread and long lists; overflow fades out with a 24px mask.
- **Bypass mode:** a red inner halo (`inset 0 0 0 1px rgb(255 77 94 / .55), inset 0 0 120px -40px …`) on the whole panel while active.

## ICONOGRAPHY

- **System:** [Phosphor](https://phosphoricons.com) only, imported per icon from `phosphor-svelte`. In this design system use the web font from CDN: `<script src="https://unpkg.com/@phosphor-icons/web@2.1.1"></script>` and the `Icon` component (`<Icon name="gear-six" weight="duotone" />`).
- **Weights:** `duotone` is the default (header pencil/gear, menu items, result icons, launcher fallback, weather). `bold` for check, plus, x, arrows (« Terminé », « Ajouter », close). `fill` for media and states (play, pause, skip, stop, moon when Focus is on). `regular` for small inline glyphs (speaker, copy, history, clipboard).
- **Sizes:** 12, 14, 16, 18 (header), 20 (menus, results), 24, 32 (launcher tiles), 44 (weather).
- **Colour:** inherits text colour (muted by default); accent for menu item icons in « Ajouter », weather glyphs, launcher fallbacks, Claude result icon.
- **Glyphs in use:** gear-six, pencil-simple, check, plus, x, magnifying-glass, app-window, file, folder, folder-open, globe, calculator, command, sliders-horizontal, sparkle, clock, cpu, hard-drives, rocket-launch, cloud-sun (+ sun, moon, cloud, cloud-rain, cloud-snow, cloud-fog, cloud-lightning, cloud-moon), wifi-high, arrow-up/down, calendar-dots, note, timer, list-checks, speaker-high/low/slash, music-notes, play, pause, skip-back/forward, stop, arrow-counter-clockwise, arrow-square-out, clock-counter-clockwise, copy, clipboard-text, download-simple, trash, moon.
- **No** emoji, no PNG icon sprites, no custom SVG icon set. The only bespoke SVGs are data drawings (pomodoro ring, network sparkline).
- **Logo:** ⚠️ the logo has changed and the previous mark has been removed from this system. Until the new one is supplied, set the name « Photon » in Satoshi 18/600, −0.01em, wherever a mark would go. There is no `assets/` folder for now.

## Font note

Satoshi is shipped as the original variable woff2 from the repo — no substitution.
