// Info widgets: Clock, System, Disks, Network, Weather. Recreated from src/renderer/widgets/*.
const { WidgetLabel, RollingNumber, MeterBar, Icon } = window.PhotonDesignSystem_d1dfae;

const two = (n) => String(n).padStart(2, '0');
const capital = (s) => s.replace(/^./, (l) => l.toUpperCase());
const pad = (min, mid, max) => `clamp(${min}px, ${mid}cqmin, ${max}px)`;

function useTick(ms, fn) {
  const [v, setV] = React.useState(fn);
  React.useEffect(() => { const t = setInterval(() => setV(fn()), ms); return () => clearInterval(t); }, []);
  return v;
}

function ClockWidget({ editing, settings = {}, save }) {
  const now = useTick(250, () => new Date());
  const time = `${two(now.getHours())}:${two(now.getMinutes())}` + (settings.seconds ? `:${two(now.getSeconds())}` : '');
  const date = capital(new Intl.DateTimeFormat('fr-FR', { weekday: 'long', day: 'numeric', month: 'long' }).format(now));
  const span = settings.seconds ? 4.25 : 2.75;
  const editRows = editing ? 36 : 0;
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: pad(14, 6, 28), display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 12 }}>
      <p style={{ margin: 0, fontSize: `min(96px, 100cqh - 2 * ${pad(14, 6, 28)} - 32px - ${editRows}px, (100cqw - 2 * ${pad(14, 6, 28)}) / ${span})`, fontWeight: 300, letterSpacing: '-0.04em', lineHeight: 1, whiteSpace: 'nowrap' }}>
        <RollingNumber value={time} />
      </p>
      <p style={{ margin: 0, fontSize: 'clamp(12px, 7cqw, 16px)', lineHeight: '20px', color: 'var(--text-muted)', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{date}</p>
      {editing && (
        <label style={{ alignSelf: 'flex-start', minHeight: 24, display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-muted)', cursor: 'pointer' }}>
          <input type="checkbox" checked={!!settings.seconds} onChange={(e) => save({ ...settings, seconds: e.currentTarget.checked })} style={{ width: 16, height: 16, margin: 0, accentColor: 'var(--accent)' }} />
          <span>Afficher les secondes</span>
        </label>
      )}
    </div>
  );
}

function Measure({ name, value, temp, detail }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', gap: 8, fontSize: 13 }}>
        <span style={{ color: 'var(--text-muted)' }}>{name}</span>
        {temp && <span style={{ marginLeft: 'auto', fontVariantNumeric: 'tabular-nums', color: 'var(--text-faint)' }}>{temp}</span>}
        <span style={{ fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}><RollingNumber value={String(value)} />&nbsp;%</span>
      </div>
      <MeterBar value={value / 100} />
      {detail && <span style={{ fontSize: 12, fontVariantNumeric: 'tabular-nums', color: 'var(--text-faint)' }}>{detail}</span>}
    </div>
  );
}

function SystemWidget({ h }) {
  const s = useTick(2000, () => ({ cpu: 12 + Math.round(Math.random() * 30), ram: 58 + Math.round(Math.random() * 6), gpu: 4 + Math.round(Math.random() * 12) }));
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: pad(12, 10, 24), display: 'flex', flexDirection: 'column', gap: 'clamp(6px, 4.5cqh, 14px)', lineHeight: 1.3 }}>
      <WidgetLabel>Système</WidgetLabel>
      <Measure name="CPU" value={s.cpu} temp="54°" />
      <Measure name="RAM" value={s.ram} detail={h >= 3 ? `${(s.ram * 0.318).toFixed(1).replace('.', ',')} / 31,8 Go` : ''} />
      <Measure name="GPU" value={s.gpu} temp="41°" />
    </div>
  );
}

function DisksWidget() {
  const others = [['D:', '1,2', 'To', 0.42], ['E:', '86', 'Go', 0.91]];
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: 24, display: 'flex', flexDirection: 'column', gap: 'clamp(8px, 7cqh, 14px)' }}>
      <WidgetLabel>Disque</WidgetLabel>
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'baseline', columnGap: 8, rowGap: 2 }}>
        <span style={{ fontSize: 'clamp(18px, min(11.2cqw, 22cqh), 40px)', fontWeight: 300, lineHeight: 1, fontVariantNumeric: 'tabular-nums' }}><RollingNumber value="412" /></span>
        <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>Go libres sur C:</span>
      </div>
      <MeterBar value={0.56} />
      <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6, overflow: 'hidden' }}>
        {others.map(([l, v, u, used]) => (
          <li key={l} style={{ display: 'grid', gridTemplateColumns: '1.5em 3.6em 1fr', alignItems: 'center', columnGap: 8, fontSize: 13, lineHeight: '16px' }}>
            <span style={{ color: 'var(--text-muted)' }}>{l}</span>
            <span style={{ textAlign: 'right', whiteSpace: 'nowrap' }}>{v} {u}</span>
            <MeterBar value={used} thickness={3} />
          </li>
        ))}
      </ul>
    </div>
  );
}

function NetworkWidget() {
  const [hist, setHist] = React.useState(() => Array.from({ length: 30 }, () => 200000 + Math.random() * 1800000));
  React.useEffect(() => { const t = setInterval(() => setHist((h) => [...h.slice(1), 200000 + Math.random() * 1800000]), 1000); return () => clearInterval(t); }, []);
  const fmt = (b) => (b < 1e6 ? `${Math.round(b / 1000)} Ko/s` : `${(b / 1e6).toFixed(1).replace('.', ',')} Mo/s`);
  const peak = Math.max(...hist, 1);
  const path = hist.map((v, i) => `${i ? 'L' : 'M'}${(i * 100 / 29).toFixed(1)},${(30 - (v / peak) * 28).toFixed(1)}`).join(' ');
  const p = { margin: 0, display: 'flex', alignItems: 'center', gap: 6, fontSize: 'clamp(14px, 8cqmin, 20px)', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' };
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: pad(12, 9, 20), display: 'flex', flexDirection: 'column', gap: 8 }}>
      <WidgetLabel>Réseau</WidgetLabel>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '4px 16px' }}>
        <p style={p}><Icon name="arrow-down" weight="bold" size={14} label="Reçu" />{fmt(hist[29])}</p>
        <p style={{ ...p, color: 'var(--text-muted)' }}><Icon name="arrow-up" weight="bold" size={14} label="Envoyé" />{fmt(hist[29] / 9)}</p>
      </div>
      <svg viewBox="0 0 100 30" preserveAspectRatio="none" aria-hidden="true" style={{ flex: 1, minHeight: 0, width: '100%' }}>
        <path d={`${path} L100,30 L0,30 Z`} style={{ fill: 'color-mix(in srgb, var(--accent) 18%, transparent)' }} />
        <path d={path} style={{ fill: 'none', stroke: 'var(--accent)', strokeWidth: 1.5, vectorEffect: 'non-scaling-stroke' }} />
      </svg>
    </div>
  );
}

function WeatherWidget({ w }) {
  const days = [['dim', 'cloud-rain', 9, 13], ['lun', 'cloud', 8, 12], ['mar', 'cloud-sun', 7, 14], ['mer', 'sun', 6, 15]];
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: pad(12, 9, 20), display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 8 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <Icon name="cloud-sun" weight="duotone" size={44} color="var(--accent)" />
        <div>
          <p style={{ margin: 0, fontSize: 'clamp(26px, 16cqmin, 44px)', fontWeight: 300, lineHeight: 1 }}>12°</p>
          <p style={{ margin: 0, fontSize: 13, color: 'var(--text-muted)' }}>Peu nuageux</p>
        </div>
      </div>
      <p style={{ margin: 0, fontSize: 13, color: 'var(--text-muted)' }}>Lyon <span style={{ color: 'var(--text-faint)' }}>· 8° / 14°</span></p>
      {w >= 5 && (
        <ul style={{ display: 'flex', margin: '4px 0 0', padding: 0, listStyle: 'none', gap: 6 }}>
          {days.map(([d, ic, lo, hi]) => (
            <li key={d} style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--text-muted)' }}>
              <span>{d}</span><Icon name={ic} weight="duotone" size={20} />
              <span style={{ color: 'var(--text-faint)', fontVariantNumeric: 'tabular-nums' }}>{lo}° {hi}°</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

Object.assign(window, { ClockWidget, SystemWidget, DisksWidget, NetworkWidget, WeatherWidget, useTick, pad });
