# Photon UI kit

Interactive recreation of the Photon widget window (Electron + Svelte app in `ergo-app/`).

- `index.html` — fullscreen glass panel. Profiles from `src/shared/templates.ts` (Principal = default profile, Travail, Focus, Chill) plus « Maison » to show the remaining widgets (Météo, Réseau, Son, Dossiers).
- `mini.html` — the mini-mode command bar window.
- `Shell.jsx` — backdrop, panel, header (logo, profile pills, command bar, actions), grid, add menu, settings drawer.
- `WidgetsInfo.jsx` — Horloge, Système, Disques, Réseau, Météo.
- `WidgetsTools.jsx` — Lanceur, Dossiers, Agenda, To-do, Notes.
- `WidgetsMedia.jsx` — Pomodoro, Son, YT Music, Claude.

Shortcuts: placement on the grid is static (no drag/resize); data is fake; the backdrop is a flat neutral placeholder (the product's background has changed and isn't documented); there is no logo, only the name; real Windows app icons are replaced by the app's own fallback (duotone app-window in accent); album art by the music-notes fallback.
