// Tool widgets: Launcher, Folders, Calendar, Todo, Notes. Recreated from src/renderer/widgets/*.
const { WidgetLabel, Checkbox, TextField, Chip, Icon } = window.PhotonDesignSystem_d1dfae;

function LauncherWidget({ editing }) {
  const [apps, setApps] = React.useState(['Discord', 'Steam', 'Visual Studio Code', 'Firefox', 'Spotify', 'OBS Studio']);
  const [hover, setHover] = React.useState(null);
  const tile = { width: 72, display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 8, padding: 0, border: 0, borderRadius: 12, background: 'none', cursor: 'pointer', transition: 'transform 300ms var(--ease-spring)' };
  const square = (h, add) => ({ boxSizing: 'border-box', width: 64, height: 64, display: 'grid', placeItems: 'center', border: '1px ' + (add ? 'dashed' : 'solid') + ' var(--line)', borderRadius: 16, background: add ? 'transparent' : h ? 'rgb(255 255 255 / .12)' : 'rgb(255 255 255 / .07)' });
  const name = { maxWidth: '100%', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', fontSize: 12, color: 'var(--text-muted)' };
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: 'clamp(14px, 6cqmin, 24px)', display: 'flex', flexDirection: 'column', gap: 12, overflow: 'hidden auto' }}>
      <WidgetLabel>Apps</WidgetLabel>
      <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'flex-start', gap: 16 }}>
        {apps.map((a) => (
          <div key={a} style={{ position: 'relative' }}>
            <button type="button" title={a} style={{ ...tile, transform: hover === a ? 'translateY(-2px)' : 'none' }} onMouseEnter={() => setHover(a)} onMouseLeave={() => setHover(null)}>
              <span style={square(hover === a)}><Icon name="app-window" weight="duotone" size={32} color="var(--accent)" /></span>
              <span style={name}>{a}</span>
            </button>
            {editing && (
              <button type="button" aria-label={'Retirer ' + a} onClick={() => setApps(apps.filter((x) => x !== a))}
                style={{ position: 'absolute', top: -6, right: -2, width: 20, height: 20, display: 'grid', placeItems: 'center', padding: 0, border: '1px solid var(--line)', borderRadius: '50%', background: 'var(--surface-chip)', color: 'var(--text)', cursor: 'pointer' }}>
                <Icon name="x" weight="duotone" size={14} />
              </button>
            )}
          </div>
        ))}
        {editing && (
          <button type="button" style={tile}><span style={square(false, true)}><Icon name="plus" weight="duotone" size={32} color="var(--accent)" /></span><span style={name}>Ajouter</span></button>
        )}
      </div>
    </div>
  );
}

function FoldersWidget({ editing }) {
  const favs = ['Documents', 'Téléchargements', 'Projets', 'Photos'];
  const recents = [['rapport-q3.pdf', 'file'], ['photon', 'folder'], ['facture-octobre.xlsx', 'file'], ['Captures', 'folder']];
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: 'clamp(12px, 8cqmin, 20px)', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <WidgetLabel>Favoris</WidgetLabel>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        {favs.map((f) => <Chip key={f} size="md" icon="folder">{f}</Chip>)}
        {editing && <Chip size="md" variant="dashed" icon={<Icon name="plus" size={14} />}>Ajouter</Chip>}
      </div>
      <WidgetLabel style={{ marginTop: 4 }}>Récents</WidgetLabel>
      <ul style={{ flex: 1, minHeight: 0, margin: 0, padding: 0, listStyle: 'none', overflow: 'hidden' }}>
        {recents.map(([n, k]) => (
          <li key={n}><button type="button" style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 8, minHeight: 28, padding: '0 6px', border: 0, borderRadius: 8, background: 'none', fontSize: 13, color: 'var(--text-muted)', textAlign: 'left', cursor: 'pointer' }}>
            <Icon name={k} size={16} /><span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{n}</span>
          </button></li>
        ))}
      </ul>
    </div>
  );
}

function CalendarWidget({ editing }) {
  const groups = [
    ["Aujourd'hui", [['En cours', 'Point équipe produit', true], ['14:30', 'Revue design Photon'], ['18:00', 'Salle de sport']]],
    ['Demain', [['Journée', 'Anniversaire de Léa'], ['09:15', 'Dentiste']]],
    ['Lundi 3 nov.', [['10:00', 'Comité de pilotage'], ['12:30', 'Déjeuner avec Marc']]],
  ];
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: 24, display: 'flex', flexDirection: 'column', gap: 12 }}>
      <WidgetLabel>Agenda</WidgetLabel>
      {editing ? (
        <TextField variant="inset" label="Adresse iCal secrète" placeholder="https://calendar.google.com/calendar/ical/…/basic.ics" hint="Google Agenda › Paramètres de l'agenda › Adresse secrète au format iCal" />
      ) : (
        <div style={{ flex: '1 1 0', minHeight: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 12, WebkitMask: 'linear-gradient(#000 calc(100% - 24px), transparent)', mask: 'linear-gradient(#000 calc(100% - 24px), transparent)' }}>
          {groups.map(([day, evs]) => (
            <section key={day} style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
              <h3 style={{ margin: 0, fontSize: 12, fontWeight: 500, color: 'var(--text-muted)' }}>{day}</h3>
              <ul style={{ margin: 0, padding: 0, listStyle: 'none', display: 'flex', flexDirection: 'column', gap: 6 }}>
                {evs.map(([t, title, now]) => (
                  <li key={title} style={{ display: 'grid', gridTemplateColumns: '6px 4.6em 1fr', alignItems: 'center', columnGap: 10, fontSize: 13, lineHeight: '18px' }}>
                    <span style={{ width: 6, height: 6, borderRadius: '50%', background: now ? 'var(--accent)' : 'color-mix(in srgb, var(--accent) 60%, transparent)', boxShadow: now ? '0 0 8px var(--accent)' : 'none' }} />
                    <span style={{ color: now ? 'var(--accent)' : 'var(--text-muted)', fontVariantNumeric: 'tabular-nums', whiteSpace: 'nowrap' }}>{t}</span>
                    <span style={{ overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</span>
                  </li>
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

function TodoWidget() {
  const [tasks, setTasks] = React.useState([
    { id: 1, text: 'Envoyer le devis à Camille', done: false },
    { id: 2, text: 'Appeler le garage', done: false },
    { id: 3, text: 'Relire la doc des widgets', done: false },
    { id: 4, text: 'Sauvegarder le NAS', done: true },
  ]);
  const [draft, setDraft] = React.useState('');
  const [hover, setHover] = React.useState(null);
  const sorted = [...tasks.filter((t) => !t.done), ...tasks.filter((t) => t.done)];
  const left = tasks.filter((t) => !t.done).length;
  const add = () => { if (!draft.trim()) return; setTasks([...tasks, { id: Date.now(), text: draft.trim(), done: false }]); setDraft(''); };
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: 'clamp(12px, 9cqmin, 20px)', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <WidgetLabel aside={`${left} à faire`}>To-do</WidgetLabel>
      <ul style={{ flex: 1, minHeight: 0, margin: 0, padding: 0, listStyle: 'none', overflowY: 'auto' }}>
        {sorted.map((t) => (
          <li key={t.id} onMouseEnter={() => setHover(t.id)} onMouseLeave={() => setHover(null)} style={{ display: 'flex', alignItems: 'center', gap: 10, minHeight: 30, fontSize: 14 }}>
            <Checkbox variant="task" checked={t.done} label={t.text} onChange={() => setTasks(tasks.map((x) => (x.id === t.id ? { ...x, done: !x.done } : x)))} />
            <span style={{ flex: 1, minWidth: 0, opacity: t.done ? 0.45 : 1, textDecoration: t.done ? 'line-through' : 'none', transition: 'opacity 200ms var(--ease-out)' }}>{t.text}</span>
            <button type="button" aria-label={`Supprimer « ${t.text} »`} onClick={() => setTasks(tasks.filter((x) => x.id !== t.id))}
              style={{ width: 22, height: 22, display: 'grid', placeItems: 'center', padding: 0, border: 0, borderRadius: '50%', background: 'none', color: 'var(--text-faint)', opacity: hover === t.id ? 1 : 0, cursor: 'pointer' }}>
              <Icon name="x" size={12} />
            </button>
          </li>
        ))}
      </ul>
      <TextField value={draft} onChange={(e) => setDraft(e.currentTarget.value)} onKeyDown={(e) => e.key === 'Enter' && add()} placeholder="Ajouter une tâche…" aria-label="Nouvelle tâche" />
    </div>
  );
}

function NotesWidget() {
  const [text, setText] = React.useState('Code portail : 4512B\n\nIdées widget :\n— minuteur cuisine\n— cours de la bourse');
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: 'clamp(12px, 9cqmin, 20px)', display: 'flex', flexDirection: 'column', gap: 8 }}>
      <WidgetLabel>Notes</WidgetLabel>
      <textarea value={text} onChange={(e) => setText(e.currentTarget.value)} placeholder="Une idée, un numéro, une liste…" aria-label="Notes"
        style={{ flex: 1, minHeight: 0, padding: 0, border: 0, outline: 0, resize: 'none', background: 'none', color: 'var(--text)', fontFamily: 'inherit', fontSize: 14, lineHeight: 1.5 }} />
    </div>
  );
}

Object.assign(window, { LauncherWidget, FoldersWidget, CalendarWidget, TodoWidget, NotesWidget });
