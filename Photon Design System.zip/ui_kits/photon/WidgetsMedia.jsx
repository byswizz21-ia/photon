// Media + Claude widgets: Pomodoro, Volume, Music, Claude. Recreated from src/renderer/widgets/*.
const { WidgetLabel, ProgressRing, PlayButton, IconButton, Slider, Segmented, Chip, Approval, Icon } = window.PhotonDesignSystem_d1dfae;

function PomodoroWidget({ editing }) {
  const box = React.useRef(null);
  const [narrow, setNarrow] = React.useState(false); // column layout when the card is too narrow for ring + side (Pomodoro.svelte @container)
  React.useEffect(() => {
    const ro = new ResizeObserver(([e]) => setNarrow(e.contentRect.width < 300));
    ro.observe(box.current);
    return () => ro.disconnect();
  }, []);
  const [running, setRunning] = React.useState(false);
  const [phase, setPhase] = React.useState('idle');
  const [left, setLeft] = React.useState(25 * 60);
  React.useEffect(() => {
    if (!running) return;
    const t = setInterval(() => setLeft((l) => Math.max(0, l - 1)), 1000);
    return () => clearInterval(t);
  }, [running]);
  const total = phase === 'pause' ? 5 * 60 : 25 * 60;
  const clock = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`;
  const label = phase === 'focus' ? 'Travail' : phase === 'pause' ? 'Pause' : 'Pomodoro';
  const field = { display: 'flex', flexDirection: 'column', gap: 4, fontSize: 12, color: 'var(--text-muted)' };
  const num = { width: 72, minHeight: 28, padding: '0 8px', border: '1px solid var(--line)', borderRadius: 8, background: 'rgb(255 255 255 / .05)', color: 'var(--text)', fontFamily: 'inherit', boxSizing: 'border-box' };
  return (
    <div ref={box} style={{ boxSizing: 'border-box', height: '100%', padding: 'clamp(12px, 8cqmin, 20px)', display: 'flex', flexDirection: narrow ? 'column' : 'row', justifyContent: narrow ? 'center' : 'flex-start', alignItems: 'center', gap: 'clamp(12px, 6cqmin, 20px)' }}>
      <ProgressRing progress={left / total} label={clock} tone={phase === 'pause' ? 'secondary' : 'accent'} size={160} style={narrow ? { width: 'min(60%, 100cqh - 90px)', height: 'auto', aspectRatio: '1', minHeight: 0 } : { height: '100%', width: 'auto', aspectRatio: '1', maxHeight: 160 }} />
      <div style={{ minWidth: 0, display: 'flex', flexDirection: 'column', alignItems: narrow ? 'center' : 'stretch', gap: 10 }}>
        {!narrow && <WidgetLabel>{label}</WidgetLabel>}
        {editing ? (
          <>
            <label style={field}>Travail (min)<input type="number" defaultValue={25} style={num} /></label>
            <label style={field}>Pause (min)<input type="number" defaultValue={5} style={num} /></label>
          </>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <PlayButton size={38} playing={running} onClick={() => { setRunning(!running); if (phase === 'idle') setPhase('focus'); }} />
            {phase !== 'idle' && (
              <>
                <IconButton variant="ghost" size="sm" icon="skip-forward" iconWeight="fill" label="Phase suivante" onClick={() => { const p = phase === 'focus' ? 'pause' : 'focus'; setPhase(p); setLeft(p === 'pause' ? 300 : 1500); }} />
                <IconButton variant="ghost" size="sm" icon="arrow-counter-clockwise" iconWeight="regular" label="Arrêter" onClick={() => { setRunning(false); setPhase('idle'); setLeft(1500); }} />
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function VolumeWidget() {
  const [vol, setVol] = React.useState(62);
  const [muted, setMuted] = React.useState(false);
  const [current, setCurrent] = React.useState('casque');
  const devices = [['casque', 'Casque', 'Realtek Audio'], ['hp', 'Haut-parleurs', 'NVIDIA High Definition Audio'], ['tv', 'LG TV', 'Intel Display Audio']];
  return (
    <div style={{ boxSizing: 'border-box', height: '100%', padding: 'clamp(12px, 8cqmin, 20px)', display: 'flex', flexDirection: 'column', gap: 10 }}>
      <WidgetLabel>Son</WidgetLabel>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <IconButton variant="ghost" icon={muted ? 'speaker-slash' : vol < 50 ? 'speaker-low' : 'speaker-high'} iconWeight="regular" iconSize={20} label={muted ? 'Rétablir le son' : 'Couper le son'} pressed={muted} onClick={() => setMuted(!muted)} style={{ color: 'var(--text)' }} />
        <Slider value={vol} label="Volume" muted={muted} onChange={(v) => { setVol(v); setMuted(false); }} />
        <span style={{ flex: 'none', minWidth: '3ch', textAlign: 'right', fontSize: 13, fontVariantNumeric: 'tabular-nums', color: 'var(--text-muted)' }}>{vol}</span>
      </div>
      <ul style={{ flex: 1, minHeight: 0, margin: 0, padding: 0, listStyle: 'none', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 2 }}>
        {devices.map(([id, n, d]) => {
          const on = id === current;
          return (
            <li key={id}><button type="button" aria-pressed={on} onClick={() => setCurrent(id)} style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', padding: '6px 10px', borderRadius: 10, textAlign: 'left', cursor: 'pointer', fontFamily: 'inherit',
              border: '1px solid ' + (on ? 'color-mix(in srgb, var(--accent) 45%, transparent)' : 'transparent'), background: on ? 'color-mix(in srgb, var(--accent) 16%, transparent)' : 'none', color: on ? 'var(--text)' : 'var(--text-muted)' }}>
              <span style={{ fontSize: 13 }}>{n}</span><span style={{ fontSize: 11, color: 'var(--text-faint)' }}>{d}</span>
            </button></li>
          );
        })}
      </ul>
    </div>
  );
}

function MusicWidget({ w }) {
  const [playing, setPlaying] = React.useState(true);
  const [time, setTime] = React.useState(74);
  const [vol, setVol] = React.useState(70);
  React.useEffect(() => { if (!playing) return; const t = setInterval(() => setTime((x) => (x + 1) % 258), 1000); return () => clearInterval(t); }, [playing]);
  const clock = (s) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  return (
    <div style={{ position: 'relative', boxSizing: 'border-box', height: '100%', padding: 'clamp(12px, 7cqmin, 20px)', display: 'flex', alignItems: 'center', gap: 'clamp(12px, 5cqmin, 20px)' }}>
      <span aria-hidden="true" style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at 15% 50%, color-mix(in srgb, rgb(122 92 255) 55%, transparent), transparent 75%)', filter: 'saturate(1.6)', opacity: 0.5, pointerEvents: 'none' }} />
      <div style={{ position: 'relative', flex: 'none', height: '100%', aspectRatio: '1', maxWidth: '45%', display: 'grid', placeItems: 'center', borderRadius: 14, overflow: 'hidden', background: 'rgb(255 255 255 / .06)', color: 'var(--text-faint)', boxShadow: '0 10px 24px -12px rgb(0 0 0 / .7)' }}>
        <Icon name="music-notes" size={28} />
      </div>
      <div style={{ position: 'relative', flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column', gap: 8 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <p style={{ margin: 0, fontSize: 15, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>Nightcall</p>
            <p style={{ margin: 0, fontSize: 13, color: 'var(--text-muted)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>Kavinsky</p>
          </div>
          <IconButton variant="ghost" icon="arrow-square-out" iconWeight="regular" iconSize={18} label="Ouvrir YT Music" />
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 11, color: 'var(--text-faint)', fontVariantNumeric: 'tabular-nums' }}>
          <span>{clock(time)}</span><Slider value={time} max={258} label="Position dans le morceau" onChange={setTime} /><span>4:18</span>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          <IconButton variant="ghost" icon="skip-back" iconWeight="fill" iconSize={20} label="Morceau précédent" />
          <PlayButton playing={playing} size={40} onClick={() => setPlaying(!playing)} />
          <IconButton variant="ghost" icon="skip-forward" iconWeight="fill" iconSize={20} label="Morceau suivant" />
          {w >= 5 && (
            <label style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6, color: 'var(--text-muted)' }}>
              <Icon name="speaker-high" size={16} /><Slider value={vol} label="Volume" onChange={setVol} style={{ width: 72, flex: 'none' }} />
            </label>
          )}
        </div>
      </div>
    </div>
  );
}

const QUICK = ['Corriger', 'Traduire', 'Résumer', 'Expliquer'];

function ClaudeWidget() {
  const [mode, setMode] = React.useState('question');
  const [confirm, setConfirm] = React.useState(false);
  const [draft, setDraft] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const [messages, setMessages] = React.useState([
    { role: 'user', text: 'Comment vider le cache DNS sous Windows ?' },
    { role: 'assistant', text: 'Ouvre un terminal et lance :\n\nipconfig /flushdns\n\nWindows répond « Cache de résolution DNS vidé ». Pas besoin de redémarrer.' },
  ]);
  const thread = React.useRef(null);
  React.useEffect(() => { if (thread.current) thread.current.scrollTop = thread.current.scrollHeight; }, [messages]);
  const send = (text) => {
    if (!text.trim() || busy) return;
    setMessages((m) => [...m, { role: 'user', text }, { role: 'assistant', text: '', status: 'Réflexion…' }]);
    setDraft(''); setBusy(true);
    setTimeout(() => { setMessages((m) => [...m.slice(0, -1), { role: 'assistant', text: 'C\u2019est noté. Voici une réponse d\u2019exemple : dans ce prototype, Claude ne répond pas vraiment.' }]); setBusy(false); }, 1400);
  };
  const choose = (m) => { if (m === 'bypass' && mode !== 'bypass') setConfirm(true); else { setConfirm(false); setMode(m); } };
  return (
    <div data-bypass={mode === 'bypass' || undefined} style={{ boxSizing: 'border-box', height: '100%', padding: 18, display: 'flex', flexDirection: 'column', gap: 10, borderRadius: 'inherit',
      boxShadow: mode === 'bypass' ? 'inset 0 0 0 1px rgb(255 77 94 / .7), inset 0 0 40px -10px rgb(255 77 94 / .45)' : 'none', transition: 'box-shadow 150ms var(--ease-out)' }}>
      <header style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
        <WidgetLabel>Claude</WidgetLabel>
        <Segmented size="sm" label="Mode de Claude" value={mode} onChange={choose} options={[
          { value: 'question', label: 'Question', hint: 'Lit les fichiers donnés, ne modifie et ne lance rien' },
          { value: 'agent', label: 'Agent', hint: 'Agit sur le PC, chaque action te sera demandée' },
          { value: 'bypass', label: 'Bypass', hint: 'Agit sur le PC sans rien demander', danger: true }]} />
        <div style={{ marginLeft: 'auto', display: 'flex', gap: 4 }}>
          <IconButton variant="square" icon="clock-counter-clockwise" iconWeight="regular" label="Historique" />
          <IconButton variant="square" icon="plus" iconWeight="regular" label="Nouvelle conversation" onClick={() => setMessages([])} disabled={busy || !messages.length} />
        </div>
      </header>
      {confirm && (
        <Approval tone="danger" acceptLabel="Activer" refuseLabel="Annuler" onRefuse={() => setConfirm(false)} onAccept={() => { setConfirm(false); setMode('bypass'); }}>
          <strong>Bypass</strong> : Claude agit sur ton PC (fichiers, commandes) sans rien te demander. Il revient en mode Question dès que Photon se ferme.
        </Approval>
      )}
      <div ref={thread} style={{ flex: '1 1 0', minHeight: 0, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 14, fontSize: 13, userSelect: 'text' }}>
        {messages.length === 0 && <p style={{ margin: 'auto 0', fontSize: 13, color: 'var(--text-faint)', textAlign: 'center' }}>Pose une question, glisse un fichier ou colle une capture.</p>}
        {messages.map((m, i) => m.role === 'user' ? (
          <div key={i} style={{ alignSelf: 'flex-end', maxWidth: '85%', padding: '8px 12px', border: '1px solid var(--glass-edge)', borderRadius: '14px 14px 4px 14px', background: 'rgb(255 255 255 / .07)' }}>
            <p style={{ margin: 0, whiteSpace: 'pre-wrap' }}>{m.text}</p>
          </div>
        ) : (
          <div key={i} style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: 6 }}>
            {m.text && m.text.split('\n\n').map((para, j) => para.startsWith('ipconfig')
              ? <pre key={j} style={{ margin: 0, padding: '8px 10px', borderRadius: 8, background: 'rgb(0 0 0 / .3)', fontSize: 12, alignSelf: 'stretch' }}>{para}</pre>
              : <p key={j} style={{ margin: 0, lineHeight: 1.5 }}>{para}</p>)}
            {m.status && <p style={{ margin: 0, display: 'flex', alignItems: 'center', gap: 8, color: 'var(--text-muted)' }}><span style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--accent)', boxShadow: '0 0 8px var(--accent)' }} />{m.status}</p>}
            {m.text && <IconButton variant="square" size="sm" icon="copy" iconWeight="regular" iconSize={14} label="Copier la réponse" style={{ marginLeft: -6, color: 'var(--text-faint)' }} />}
          </div>
        ))}
      </div>
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
        <Chip icon="clipboard-text" title="Coller le texte copié dans le champ">Presse-papier</Chip>
        {QUICK.map((q) => <Chip key={q} disabled={busy} title={q + ' le texte copié'}>{q}</Chip>)}
      </div>
      <div style={{ display: 'flex', alignItems: 'flex-end', gap: 8, padding: '6px 6px 6px 12px', border: '1px solid var(--glass-edge)', borderRadius: 16, background: 'rgb(0 0 0 / .22)' }}>
        <textarea rows={1} value={draft} onChange={(e) => setDraft(e.currentTarget.value)} onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(draft); } }}
          placeholder="Demande à Claude…" aria-label="Question pour Claude" style={{ flex: 1, minHeight: 22, maxHeight: 132, margin: '4px 0', padding: 0, border: 0, outline: 0, resize: 'none', background: 'none', color: 'var(--text)', fontFamily: 'inherit', fontSize: 13, lineHeight: '22px' }} />
        <button type="button" aria-label={busy ? 'Arrêter' : 'Envoyer'} title={busy ? 'Arrêter' : 'Envoyer (Entrée)'} disabled={!busy && !draft.trim()} onClick={() => send(draft)}
          style={{ flex: 'none', width: 30, height: 30, display: 'grid', placeItems: 'center', padding: 0, border: 0, borderRadius: 10, background: 'var(--accent)', color: 'var(--on-accent)', cursor: 'pointer', opacity: !busy && !draft.trim() ? 0.4 : 1 }}>
          <Icon name={busy ? 'stop' : 'arrow-up'} weight={busy ? 'fill' : 'bold'} size={16} />
        </button>
      </div>
    </div>
  );
}

Object.assign(window, { PomodoroWidget, VolumeWidget, MusicWidget, ClaudeWidget });
