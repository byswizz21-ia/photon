// Photon shell: backdrop, glass panel, header (name, profiles, command bar, actions), grid, settings drawer.
const { ProfilePill, IconButton, Button, Menu, MenuItem, MenuLabel, CommandBar, WidgetCard, Drawer, DrawerSection, Segmented, Slider, Swatch, Checkbox, Select, Icon } = window.PhotonDesignSystem_d1dfae;

const WIDGETS = {
  clock: { name: 'Horloge', icon: 'clock', size: [6, 2], C: window.ClockWidget },
  system: { name: 'Système', icon: 'cpu', size: [3, 2], C: window.SystemWidget },
  disks: { name: 'Disques', icon: 'hard-drives', size: [3, 2], C: window.DisksWidget },
  launcher: { name: 'Lanceur', icon: 'rocket-launch', size: [6, 2], C: window.LauncherWidget },
  weather: { name: 'Météo', icon: 'cloud-sun', size: [3, 2], C: window.WeatherWidget },
  network: { name: 'Réseau', icon: 'wifi-high', size: [3, 2], C: window.NetworkWidget },
  calendar: { name: 'Agenda', icon: 'calendar-dots', size: [4, 3], C: window.CalendarWidget },
  claude: { name: 'Claude', icon: 'sparkle', size: [5, 5], C: window.ClaudeWidget, noPress: true },
  folders: { name: 'Dossiers', icon: 'folder-open', size: [4, 3], C: window.FoldersWidget },
  notes: { name: 'Notes', icon: 'note', size: [3, 3], C: window.NotesWidget, noPress: true },
  pomodoro: { name: 'Pomodoro', icon: 'timer', size: [3, 2], C: window.PomodoroWidget },
  todo: { name: 'To-do', icon: 'list-checks', size: [3, 3], C: window.TodoWidget, noPress: true },
  volume: { name: 'Son', icon: 'speaker-high', size: [3, 3], C: window.VolumeWidget, noPress: true },
  ytmusic: { name: 'YT Music', icon: 'music-notes', size: [4, 2], C: window.MusicWidget, noPress: true },
};

const slots = (list) => list.map(([type, x, y, w, h]) => ({ id: type, type, x, y, w, h, settings: {} }));
const INITIAL_PROFILES = [
  { id: 'default', name: 'Principal', focus: false, widgets: slots([['clock', 0, 0, 6, 2], ['system', 6, 0, 3, 2], ['disks', 9, 0, 3, 2], ['launcher', 0, 2, 12, 2]]) },
  { id: 'work', name: 'Travail', focus: false, widgets: slots([['clock', 0, 0, 8, 2], ['system', 8, 0, 4, 2], ['calendar', 0, 2, 5, 4], ['claude', 5, 2, 7, 4]]) },
  { id: 'focus', name: 'Focus', focus: true, widgets: slots([['clock', 0, 0, 8, 2], ['pomodoro', 8, 0, 4, 2], ['todo', 0, 2, 6, 4], ['notes', 6, 2, 6, 4]]) },
  { id: 'chill', name: 'Chill', focus: false, widgets: slots([['ytmusic', 0, 0, 6, 2], ['clock', 6, 0, 6, 2], ['launcher', 0, 2, 12, 2]]) },
  { id: 'home', name: 'Maison', focus: false, widgets: slots([['weather', 0, 0, 5, 2], ['network', 5, 0, 4, 2], ['volume', 9, 0, 3, 4], ['folders', 0, 2, 9, 2]]) },
];

const APPS = ['Spotify', 'Steam', 'Discord', 'Firefox', 'Visual Studio Code', 'OBS Studio', 'Paramètres', 'Explorateur de fichiers', 'Terminal'];

function search(q, profiles) {
  const t = q.trim().toLowerCase();
  if (!t) return [];
  const out = [];
  if (/^[\d\s+\-*/().,]+$/.test(t) && /\d/.test(t)) {
    try { const v = Function('return (' + t.replace(/,/g, '.') + ')')(); if (Number.isFinite(v)) out.push({ id: 'calc', kind: 'calc', title: '= ' + String(Math.round(v * 1000) / 1000).replace('.', ','), subtitle: 'Calcul · Entrée pour copier' }); } catch (e) {}
  }
  APPS.filter((a) => a.toLowerCase().includes(t)).slice(0, 4).forEach((a) => out.push({ id: 'app:' + a, kind: 'app', title: a, subtitle: 'Application' }));
  if ('modifier la grille'.includes(t)) out.push({ id: 'ui:edit', kind: 'action', title: 'Modifier la grille', subtitle: 'Photon' });
  if ('réglages'.includes(t)) out.push({ id: 'ui:settings', kind: 'action', title: 'Réglages', subtitle: 'Photon' });
  profiles.filter((p) => p.name.toLowerCase().includes(t)).forEach((p) => out.push({ id: 'ui:profile:' + p.id, kind: 'action', title: 'Profil « ' + p.name + ' »', subtitle: 'Basculer de profil' }));
  if ('éteindre'.includes(t) || 'redémarrer'.includes(t)) out.push({ id: 'cmd:off', kind: 'command', title: 'Éteindre', subtitle: 'Commande système', confirm: true });
  out.push({ id: 'web', kind: 'web', title: 'Rechercher « ' + q.trim() + ' »', subtitle: 'Sur le web' });
  out.push({ id: 'claude', kind: 'claude', title: 'Demander à Claude', subtitle: '« ' + q.trim() + ' »' });
  return out;
}

function onAccent(hex) {
  const [r, g, b] = [1, 3, 5].map((i) => { const v = parseInt(hex.slice(i, i + 2), 16) / 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.18 ? '#07080b' : '#ffffff';
}

function Header({ profiles, active, setActive, editing, setEditing, settingsOpen, setSettingsOpen, onAdd, renameActive, toggleFocus, fullscreen }) {
  const [query, setQuery] = React.useState('');
  const [sel, setSel] = React.useState(0);
  const [confirmId, setConfirmId] = React.useState('');
  const [addOpen, setAddOpen] = React.useState(false);
  const results = search(query, profiles).map((r) => ({ ...r, warn: r.id === confirmId }));
  const run = (r) => {
    if (!r) return;
    if (r.confirm && confirmId !== r.id) { setConfirmId(r.id); return; }
    if (r.id === 'ui:edit') { setEditing(true); setSettingsOpen(false); }
    else if (r.id === 'ui:settings') setSettingsOpen(true);
    else if (r.id.startsWith('ui:profile:')) setActive(r.id.slice(11));
    setQuery(''); setConfirmId('');
  };
  const onKey = (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') { e.preventDefault(); if (results.length) setSel((sel + (e.key === 'ArrowDown' ? 1 : results.length - 1)) % results.length); setConfirmId(''); }
    else if (e.key === 'Enter') { e.preventDefault(); run(results[sel]); }
    else if (e.key === 'Escape') { setQuery(''); }
  };
  const activeProfile = profiles.find((p) => p.id === active);
  return (
    <header data-reveal style={{ display: 'flex', alignItems: 'center', gap: 10, minHeight: 36, position: 'relative', zIndex: 20 }}>
      <span style={{ fontSize: 18, fontWeight: 600, letterSpacing: '-0.01em' }}>Photon</span>
      <div style={{ minWidth: 0, display: 'flex', alignItems: 'center', gap: 6 }}>
        <div role="group" aria-label="Profils" style={{ minWidth: 0, display: 'flex', alignItems: 'center', gap: 4, overflowX: 'auto', scrollbarWidth: 'none' }}>
          {profiles.map((p, i) => editing && p.id === active ? (
            <React.Fragment key={p.id}>
              <input value={p.name} onChange={(e) => renameActive(e.currentTarget.value)} size={Math.max(p.name.length, 4)} aria-label="Nom du profil" spellCheck="false"
                style={{ flex: 'none', height: 30, padding: '0 12px', boxSizing: 'border-box', border: '1px solid var(--accent)', borderRadius: 999, background: 'color-mix(in srgb, var(--accent) 16%, transparent)', color: 'var(--text)', fontFamily: 'inherit', fontSize: 13, outline: 0 }} />
              <button type="button" aria-pressed={p.focus} onClick={toggleFocus} title="Profil Focus : « Ne pas déranger » de Windows et pomodoro lancé à l'activation"
                style={{ flex: 'none', height: 30, display: 'inline-flex', alignItems: 'center', gap: 6, padding: '0 8px', border: 0, borderRadius: 999, background: p.focus ? 'rgb(255 255 255 / .08)' : 'none', color: p.focus ? 'var(--text)' : 'var(--text-faint)', fontFamily: 'inherit', fontSize: 12, cursor: 'pointer' }}>
                <Icon name="moon" weight={p.focus ? 'fill' : 'regular'} size={15} />Focus
              </button>
            </React.Fragment>
          ) : (
            <ProfilePill key={p.id} name={p.name} focus={p.focus} active={p.id === active} title={i < 9 ? 'Ctrl+' + (i + 1) : undefined} onClick={() => setActive(p.id)} />
          ))}
        </div>
        <IconButton icon="plus" iconWeight="bold" size="sm" label="Nouveau profil" onClick={onAdd} />
      </div>
      <div onKeyDown={onKey} style={{ flex: 1, minWidth: 0, display: 'flex' }}>
        <CommandBar value={query} onChange={(v) => { setQuery(v); setSel(0); setConfirmId(''); }} results={results} selected={sel} onHover={setSel} onSelect={(r) => run(r)} />
      </div>
      <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8 }}>
        {editing ? (
          <>
            <div style={{ position: 'relative' }}>
              <Button icon="plus" aria-haspopup="menu" aria-expanded={addOpen} onClick={() => setAddOpen(!addOpen)}>Ajouter</Button>
              {addOpen && (
                <Menu style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', zIndex: 10, maxHeight: 420, overflowY: 'auto' }}>
                  {Object.entries(WIDGETS).map(([type, m]) => <MenuItem key={type} icon={m.icon} onClick={() => { onAdd(type); setAddOpen(false); }}>{m.name}</MenuItem>)}
                </Menu>
              )}
            </div>
            <Button variant="primary" icon="check" onClick={() => { setEditing(false); setAddOpen(false); }}>Terminé</Button>
          </>
        ) : (
          <>
            <IconButton icon="pencil-simple" label="Modifier la grille" onClick={() => { setSettingsOpen(false); setEditing(true); }} />
            <IconButton icon="gear-six" label="Réglages" aria-expanded={settingsOpen} onClick={() => setSettingsOpen(!settingsOpen)} />
          </>
        )}
      </div>
    </header>
  );
}

function Grid({ profile, editing, density, onRemove, onSave }) {
  const cell = density === 'compact' ? 80 : 100;
  const gap = density === 'compact' ? 12 : 20;
  if (!profile.widgets.length) {
    return (
      <div style={{ padding: '48px 24px', textAlign: 'center', color: 'var(--text-muted)' }}>
        <p style={{ margin: 0 }}>Aucun widget pour l'instant.</p>
        <p style={{ margin: '6px 0 0', fontSize: 13, color: 'var(--text-faint)' }}>Clique sur le crayon en haut à droite, puis sur « Ajouter ».</p>
      </div>
    );
  }
  return (
    <div key={profile.id} style={{ display: 'grid', gridTemplateColumns: 'repeat(12, minmax(0, 1fr))', gridAutoRows: cell, gap, animation: 'pt-fade 220ms var(--ease-out)' }}>
      {profile.widgets.map((w) => {
        const m = WIDGETS[w.type];
        const C = m.C;
        return (
          <div key={w.id} style={{ gridColumn: `${w.x + 1} / span ${w.w}`, gridRow: `${w.y + 1} / span ${w.h}`, position: 'relative' }}>
            <WidgetCard label={m.name} editing={editing} noPress={m.noPress} onRemove={() => onRemove(w.id)}>
              <C editing={editing} w={w.w} h={w.h} settings={w.settings} save={(s) => onSave(w.id, s)} />
            </WidgetCard>
            {editing && <span aria-hidden="true" style={{ position: 'absolute', right: 0, bottom: 0, width: 18, height: 18, borderRight: '2px solid var(--accent)', borderBottom: '2px solid var(--accent)', borderBottomRightRadius: 'var(--radius)', opacity: 0.8 }} />}
          </div>
        );
      })}
    </div>
  );
}

function SettingsPanel({ theme, setTheme, settings, setSettings, onClose }) {
  const [tab, setTab] = React.useState(theme.background);
  const set = (p) => setTheme({ ...theme, ...p });
  const SW = [['Bleu', '#7CC4FF'], ['Violet', '#B69CFF'], ['Orange', '#FFB86B'], ['Menthe', '#6EF2C2']];
  const color = (label, value, onChange) => (
    <label style={{ display: 'inline-flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--text-muted)', cursor: 'pointer' }}>
      <input type="color" value={value} onChange={(e) => onChange(e.currentTarget.value)} style={{ width: 28, height: 28, padding: 0, border: 0, borderRadius: '50%', background: 'none', cursor: 'pointer' }} />{label}
    </label>
  );
  return (
    <Drawer title="Réglages" onClose={onClose} style={{ position: 'absolute', top: 12, right: 12, bottom: 12, zIndex: 40, animation: 'pt-open 180ms var(--ease-out)' }}>
      <DrawerSection title="Fond">
        <Segmented label="Type de fond" value={tab} onChange={(v) => { setTab(v); if (v !== 'image') set({ background: v }); }} options={[{ value: 'wallpaper', label: "Fond d'écran" }, { value: 'image', label: 'Image' }, { value: 'gradient', label: 'Dégradé' }]} />
        {tab === 'image' && <div style={{ display: 'flex', gap: 12 }}><Button>Choisir une image…</Button></div>}
        {tab === 'gradient' && <div style={{ display: 'flex', flexWrap: 'wrap', gap: '12px 16px' }}>{color('Début', theme.from, (from) => set({ from }))}{color('Fin', theme.to, (to) => set({ to }))}</div>}
      </DrawerSection>
      <DrawerSection title="Couleur d'accent">
        <Segmented label="Mode de l'accent" value={theme.auto ? 'auto' : 'manual'} onChange={(v) => set({ auto: v === 'auto', accent: v === 'auto' ? '#7CC4FF' : theme.accent })} options={[{ value: 'auto', label: 'Auto (extraite du fond)' }, { value: 'manual', label: 'Manuelle' }]} />
        <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', gap: '12px 16px' }}>
          {SW.map(([n, hex]) => <Swatch key={hex} color={hex} label={n} pressed={!theme.auto && theme.accent.toLowerCase() === hex.toLowerCase()} onClick={() => set({ auto: false, accent: hex })} />)}
          {color('Personnalisée', theme.accent, (accent) => set({ auto: false, accent }))}
        </div>
      </DrawerSection>
      <DrawerSection title="Verre">
        <Slider variant="accent" label="Flou du verre" value={theme.blur} max={120} valueText={theme.blur + ' px'} onChange={(blur) => set({ blur })} />
        <Slider variant="accent" label="Opacité du verre" value={theme.opacity} max={1} step={0.01} valueText={Math.round(theme.opacity * 100) + ' %'} onChange={(opacity) => set({ opacity })} />
        <Slider variant="accent" label="Arrondi" value={theme.radius} max={40} valueText={theme.radius + ' px'} onChange={(radius) => set({ radius })} />
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <span style={{ fontSize: 13 }}>Densité</span>
          <Segmented label="Densité" value={theme.density} onChange={(density) => set({ density })} options={[{ value: 'compact', label: 'Compacte' }, { value: 'comfortable', label: 'Aérée' }]} />
        </div>
      </DrawerSection>
      <DrawerSection title="Général">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <span style={{ fontSize: 13 }}>Mode</span>
          <Segmented label="Mode" value={settings.mode} onChange={(mode) => setSettings({ ...settings, mode })} options={[{ value: 'fullscreen', label: 'Plein écran' }, { value: 'window', label: 'Fenêtre' }]} />
        </div>
        <Checkbox label="Toujours au-dessus" hint={settings.mode !== 'window' ? 'Mode fenêtre uniquement' : undefined} disabled={settings.mode !== 'window'} />
        <Select label="Écran" value="mouse" hint="Jamais par-dessus un jeu ou une vidéo en plein écran s'il y a un autre écran" options={[{ value: 'mouse', label: 'Écran de la souris' }, { value: 'primary', label: 'Écran principal' }]} />
        <Select label="Raccourci" value="a" options={[{ value: 'a', label: 'Win+Alt+Espace' }, { value: 'b', label: 'Win+Maj+Espace' }, { value: 'c', label: 'Ctrl+Alt+Espace' }]} />
        <Select label="Barre de commande seule" value="a" options={[{ value: 'a', label: 'Alt+Espace' }, { value: 'b', label: 'Win+Ctrl+Espace' }, { value: 'c', label: 'Ctrl+Maj+Espace' }]} />
        <Checkbox label="Réduire les animations" checked={settings.reduceMotion} onChange={(reduceMotion) => setSettings({ ...settings, reduceMotion })} />
      </DrawerSection>
    </Drawer>
  );
}

function App() {
  const [profiles, setProfiles] = React.useState(INITIAL_PROFILES);
  const [active, setActive] = React.useState('default');
  const [editing, setEditing] = React.useState(false);
  const [settingsOpen, setSettingsOpen] = React.useState(false);
  const [theme, setTheme] = React.useState({ background: 'wallpaper', from: '#16181f', to: '#0e1016', auto: true, accent: '#7CC4FF', blur: 48, opacity: 0.5, radius: 20, density: 'comfortable' });
  const [settings, setSettings] = React.useState({ mode: 'fullscreen', reduceMotion: false });
  const root = React.useRef(null);
  const profile = profiles.find((p) => p.id === active);
  const fullscreen = settings.mode === 'fullscreen';

  React.useEffect(() => {
    const s = document.documentElement.style;
    s.setProperty('--accent', theme.accent); s.setProperty('--on-accent', onAccent(theme.accent));
    s.setProperty('--glass', String(theme.opacity)); s.setProperty('--radius', theme.radius + 'px');
    s.setProperty('--radius-panel', theme.radius + 8 + 'px'); s.setProperty('--blur', theme.blur + 'px');
  }, [theme]);

  React.useEffect(() => {
    if (settings.reduceMotion) return;
    const x = window.innerWidth / 2, y = 60;
    root.current.querySelectorAll('[data-reveal], .pt-card').forEach((el) => {
      const b = el.getBoundingClientRect();
      const d = Math.hypot(b.x + b.width / 2 - x, b.y + b.height / 2 - y);
      el.animate([{ opacity: 0, transform: 'translateY(8px) scale(0.98)' }, { opacity: 1, transform: 'none' }], { duration: 180, delay: Math.min(100, d / 12), easing: 'cubic-bezier(0.2, 0.8, 0.2, 1)', fill: 'backwards' });
    });
  }, []);

  React.useEffect(() => {
    const onKey = (e) => {
      if (e.key === 'Escape') { if (settingsOpen) setSettingsOpen(false); else if (editing) setEditing(false); }
      if (e.ctrlKey && /^[1-9]$/.test(e.key) && profiles[+e.key - 1]) { e.preventDefault(); setActive(profiles[+e.key - 1].id); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [settingsOpen, editing, profiles]);

  const update = (fn) => setProfiles((ps) => ps.map((p) => (p.id === active ? fn(p) : p)));
  const addWidget = (type) => {
    if (typeof type !== 'string') { // « + » profile button: new blank profile
      const id = 'p' + Date.now();
      setProfiles((ps) => [...ps, { id, name: 'Sans nom', focus: false, widgets: [] }]); setActive(id); setEditing(true); return;
    }
    const [w, h] = WIDGETS[type].size;
    update((p) => { const y = p.widgets.reduce((m, x) => Math.max(m, x.y + x.h), 0); return { ...p, widgets: [...p.widgets, { id: type + Date.now(), type, x: 0, y, w, h, settings: {} }] }; });
  };

  const bg = `linear-gradient(135deg, ${theme.from}, ${theme.to})`;
  return (
    <div ref={root} style={{ position: 'relative', height: '100%', overflow: 'hidden', background: fullscreen ? 'var(--bg)' : 'var(--bg)' }} data-reduce-motion={settings.reduceMotion || undefined}>
      <div aria-hidden="true" style={{ position: 'absolute', inset: 0, overflow: 'hidden', pointerEvents: 'none' }}>
        {/* Backdrop intentionally neutral: the product's background has changed and is not in this system yet. */}
        {fullscreen && theme.background === 'gradient' && <div style={{ position: 'absolute', inset: 0, background: bg }} />}
      </div>
      <main style={fullscreen ? {
        position: 'relative', boxSizing: 'border-box', width: 'min(1280px, calc(100% - 96px))', maxHeight: 'calc(100% - 96px)', margin: '48px auto', padding: 24, display: 'flex', flexDirection: 'column', gap: 20, overflow: 'auto',
        background: 'var(--glass-sheen), var(--panel-bg)', border: '1px solid var(--glass-edge)', borderRadius: 'var(--radius-panel)', backdropFilter: 'var(--glass-filter)', WebkitBackdropFilter: 'var(--glass-filter)',
        boxShadow: profile.widgets.some((w) => w.type === 'claude') && false ? 'var(--halo-bypass)' : 'var(--glass-rim), 0 40px 100px -30px rgb(0 0 0 / .65)' }
        : { position: 'relative', boxSizing: 'border-box', height: '100%', padding: 24, display: 'flex', flexDirection: 'column', gap: 20, overflow: 'auto', background: 'var(--glass-sheen), var(--panel-bg)' }}>
        <Header profiles={profiles} active={active} setActive={(id) => { setActive(id); }} editing={editing} setEditing={setEditing} settingsOpen={settingsOpen} setSettingsOpen={setSettingsOpen}
          onAdd={addWidget} renameActive={(name) => update((p) => ({ ...p, name }))} toggleFocus={() => update((p) => ({ ...p, focus: !p.focus }))} fullscreen={fullscreen} />
        <Grid profile={profile} editing={editing} density={theme.density} onRemove={(id) => update((p) => ({ ...p, widgets: p.widgets.filter((w) => w.id !== id) }))}
          onSave={(id, s) => update((p) => ({ ...p, widgets: p.widgets.map((w) => (w.id === id ? { ...w, settings: s } : w)) }))} />
      </main>
      {settingsOpen && <SettingsPanel theme={theme} setTheme={setTheme} settings={settings} setSettings={setSettings} onClose={() => setSettingsOpen(false)} />}
    </div>
  );
}

Object.assign(window, { PhotonApp: App, WIDGETS });
