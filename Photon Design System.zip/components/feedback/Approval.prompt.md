Ask-before-acting box inside the Claude widget or command bar.

```jsx
<Approval title="Claude veut lancer une commande" detail="ipconfig /flushdns" />
<Approval tone="danger" acceptLabel="Activer" refuseLabel="Annuler">
  <strong>Bypass</strong> : Claude agit sur ton PC sans rien te demander.
</Approval>
```
