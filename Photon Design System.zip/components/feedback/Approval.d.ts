/** Inline confirmation box: accent-tinted (Claude asks to run an action) or danger-tinted (enable Bypass). Nothing is accepted by default. */
export interface ApprovalProps {
  title?: string;
  /** Full command/detail in a dark pre block, scrolls past 8 lines */
  detail?: string;
  /** Explanatory sentence */
  children?: React.ReactNode;
  tone?: 'accent' | 'danger';
  acceptLabel?: string;
  refuseLabel?: string;
  onAccept?: () => void;
  onRefuse?: () => void;
  style?: React.CSSProperties;
}
export declare function Approval(props: ApprovalProps): JSX.Element;
