import React from 'react';
import { Chip } from '../actions/Chip.jsx';

export function Approval({ title, detail, children, tone = 'accent', acceptLabel = 'Autoriser', refuseLabel = 'Refuser', onAccept, onRefuse, style }) {
  const danger = tone === 'danger';
  return (
    <div role="alertdialog" aria-label={title} style={{ display: 'flex', flexDirection: 'column', gap: 8, padding: '10px 12px', borderRadius: 14, fontSize: 12, fontFamily: 'var(--font-sans)', color: 'var(--text)',
      border: '1px solid ' + (danger ? 'rgb(255 77 94 / .45)' : 'color-mix(in srgb, var(--accent) 45%, transparent)'),
      background: danger ? 'rgb(255 77 94 / .1)' : 'color-mix(in srgb, var(--accent) 8%, transparent)', ...style }}>
      {title && !danger && <p style={{ margin: 0, fontWeight: 600 }}>{title}</p>}
      {children && <p style={{ margin: 0 }}>{children}</p>}
      {detail && <pre style={{ maxHeight: '8lh', margin: 0, padding: 8, overflow: 'auto', borderRadius: 8, background: 'rgb(0 0 0 / .3)', fontFamily: 'inherit', fontSize: 11, lineHeight: 1.45, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' }}>{detail}</pre>}
      <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 6 }}>
        <Chip onClick={onRefuse} style={{ paddingInline: 12 }}>{refuseLabel}</Chip>
        <Chip variant={danger ? 'danger' : 'accent'} onClick={onAccept} style={{ paddingInline: 12 }}>{acceptLabel}</Chip>
      </div>
    </div>
  );
}
