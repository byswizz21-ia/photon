Play/pause disc for media and timers.

```jsx
<PlayButton playing={false} size={38} onClick={toggle} />
<PlayButton playing overlay size={44} />   {/* on artwork */}
```
