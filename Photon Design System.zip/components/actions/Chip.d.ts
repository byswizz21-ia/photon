/** Small pill button: quick prompts (sm, 26px) and folder favourites (md, 30px). */
export interface ChipProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  children?: React.ReactNode;
  /** Phosphor name or node, 14px */
  icon?: string | React.ReactNode;
  size?: 'sm' | 'md';
  /** danger = solid #ff4d5e (« Activer » Bypass); accent = solid accent (« Autoriser »); dashed = muted add chip */
  variant?: 'default' | 'danger' | 'accent' | 'dashed';
}
export declare function Chip(props: ChipProps): JSX.Element;
export interface FileChipProps { name: string; title?: string; onRemove?: () => void }
/** Attached file token in the Claude composer. */
export declare function FileChip(props: FileChipProps): JSX.Element;
