Pill action button — the only button shape in Photon chrome (header, menus, drawer, empty states).

```jsx
<Button icon="plus">Ajouter</Button>
<Button variant="primary" icon="check">Terminé</Button>
<Button size="sm">Réessayer</Button>
```

- Press = scale(.97) in 100ms, spring back 300ms. Hover = white 9 % fill.
- Labels are short French verbs/nouns in sentence case: « Ajouter », « Terminé », « Choisir une image… ».
- Only one primary per surface.
