import React from 'react';
import { Icon } from '../icons/Icon.jsx';
const CSS = `.pt-chip{box-sizing:border-box;display:inline-flex;align-items:center;gap:5px;border:1px solid var(--line);border-radius:999px;font-family:var(--font-sans);white-space:nowrap;cursor:pointer;transition:transform 300ms var(--ease-spring)}
.pt-chip.pt-s{min-height:26px;padding:0 10px;font-size:12px;background:rgb(255 255 255 / .04);color:var(--text-muted)}
.pt-chip.pt-m{height:30px;padding:0 12px;gap:6px;font-size:13px;background:rgb(255 255 255 / .05);color:var(--text)}
.pt-chip:not(:disabled):hover{color:var(--text);background:rgb(255 255 255 / .08)}
.pt-chip:not(:disabled):active{transform:scale(.95);transition-duration:100ms}
.pt-chip.pt-danger{border-color:transparent;background:var(--danger);color:#fff}
.pt-chip.pt-danger:hover{background:var(--danger)}
.pt-chip.pt-accent{border-color:transparent;background:var(--accent);color:var(--on-accent)}
.pt-chip.pt-accent:hover{background:var(--accent);color:var(--on-accent)}
.pt-chip.pt-dashed{color:var(--text-muted);background:none}
.pt-chip:disabled{opacity:.4;cursor:default}
.pt-file{max-width:180px;display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:999px;background:color-mix(in srgb,var(--accent) 16%,transparent);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pt-file button{display:grid;padding:0;border:0;background:none;color:inherit;cursor:pointer}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-chip-css')) { const s = document.createElement('style'); s.id = 'pt-chip-css'; s.textContent = CSS; document.head.appendChild(s); }

export function Chip({ children, icon, size = 'sm', variant = 'default', type = 'button', ...rest }) {
  const cls = 'pt-chip ' + (size === 'md' ? 'pt-m' : 'pt-s') + (variant !== 'default' ? ' pt-' + variant : '');
  return (
    <button type={type} className={cls} {...rest}>
      {typeof icon === 'string' ? <Icon name={icon} size={14} weight={size === 'md' ? 'duotone' : 'regular'} /> : icon}
      {children}
    </button>
  );
}

// Attached-file token (accent 16 % fill, 11px).
export function FileChip({ name, title, onRemove }) {
  return (
    <span className="pt-file" title={title || name}>
      {name}
      {onRemove && <button type="button" aria-label={'Retirer ' + name} onClick={onRemove}><Icon name="x" size={11} /></button>}
    </span>
  );
}
