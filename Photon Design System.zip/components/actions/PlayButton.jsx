import React from 'react';
import { Icon } from '../icons/Icon.jsx';
import './Button.jsx';

// Solid light disc with dark glyph — the one high-contrast control inside widgets (pomodoro, music).
export function PlayButton({ playing = false, size = 40, overlay = false, onClick, ...rest }) {
  return (
    <button
      type="button"
      className="pt-ghost"
      aria-label={playing ? 'Pause' : 'Lecture'}
      onClick={onClick}
      style={{ width: size, height: size, border: 0, background: overlay ? 'rgb(0 0 0 / .45)' : 'var(--text)', color: overlay ? '#fff' : 'var(--bg)' }}
      {...rest}
    >
      <Icon name={playing ? 'pause' : 'play'} weight="fill" size={size >= 40 ? 20 : 18} />
    </button>
  );
}
