/** Icon-only button. "action" = round bordered pill (header gear/pencil); "ghost" = borderless round muted (widget controls); "square" = 9px-radius tool (Claude header). */
export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Phosphor name or node */
  icon: string | React.ReactNode;
  /** Required: becomes aria-label and title (French, e.g. « Réglages ») */
  label: string;
  variant?: 'action' | 'ghost' | 'square';
  size?: 'md' | 'sm';
  iconSize?: number;
  iconWeight?: 'regular' | 'bold' | 'fill' | 'duotone';
  pressed?: boolean;
}
export declare function IconButton(props: IconButtonProps): JSX.Element;
