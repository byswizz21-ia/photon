import React from 'react';
import { Icon } from '../icons/Icon.jsx';
const CSS = `.pt-action{box-sizing:border-box;min-height:36px;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:0 14px;border:1px solid var(--line);border-radius:999px;background:rgb(255 255 255 / .05);font-family:var(--font-sans);font-size:13px;font-weight:500;color:var(--text);cursor:pointer;white-space:nowrap;transition:transform 300ms var(--ease-spring)}
.pt-action:hover{background:rgb(255 255 255 / .09)}
.pt-action:active{transform:scale(.97);transition-duration:100ms}
.pt-action.pt-primary{border-color:transparent;background:var(--accent);color:var(--on-accent)}
.pt-action.pt-sm{min-height:30px}
.pt-action.pt-icon{width:36px;padding:0}
.pt-action.pt-icon.pt-sm{width:30px}
.pt-action:disabled{opacity:.4;cursor:default;transform:none}
.pt-ghost{box-sizing:border-box;flex:none;display:grid;place-items:center;padding:0;border:1px solid transparent;border-radius:50%;background:none;color:var(--text-muted);cursor:pointer;transition:transform 300ms var(--ease-spring)}
.pt-ghost:hover{color:var(--text);background:rgb(255 255 255 / .08)}
.pt-ghost:active{transform:scale(.9);transition-duration:100ms}
.pt-ghost.pt-square{border-radius:9px;color:var(--text)}
.pt-ghost.pt-square:hover{border-color:var(--line);background:rgb(255 255 255 / .06)}
.pt-ghost[aria-pressed=true]{color:var(--text);background:rgb(255 255 255 / .08)}
.pt-ghost:disabled{opacity:.4;cursor:default}
.pt-ghost:disabled:hover{background:none;border-color:transparent}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-action-css')) { const s = document.createElement('style'); s.id = 'pt-action-css'; s.textContent = CSS; document.head.appendChild(s); }

export function Button({ variant = 'default', size = 'md', icon, iconWeight = 'bold', children, type = 'button', ...rest }) {
  const cls = 'pt-action' + (variant === 'primary' ? ' pt-primary' : '') + (size === 'sm' ? ' pt-sm' : '');
  return (
    <button type={type} className={cls} {...rest}>
      {typeof icon === 'string' ? <Icon name={icon} weight={iconWeight} size={16} /> : icon}
      {children}
    </button>
  );
}
