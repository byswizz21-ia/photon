/**
 * Pill action button (header bar, menus, settings). 36px tall, hairline border, white 5 % fill.
 * @startingPoint section="Actions" subtitle="Pill action buttons — default and accent primary" viewport="700x220"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = solid accent fill with --on-accent text (e.g. « Terminé ») */
  variant?: 'default' | 'primary';
  /** md 36px, sm 30px */
  size?: 'md' | 'sm';
  /** Phosphor name or a node, rendered before the label at 16px */
  icon?: string | React.ReactNode;
  iconWeight?: 'regular' | 'bold' | 'fill' | 'duotone';
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
