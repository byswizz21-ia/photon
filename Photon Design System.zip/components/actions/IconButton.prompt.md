Icon-only button in three Photon flavours; always pass a French `label`.

```jsx
<IconButton icon="gear-six" label="Réglages" />                 {/* header, 36px */}
<IconButton icon="plus" iconWeight="bold" size="sm" label="Nouveau profil" />
<IconButton icon="skip-forward" iconWeight="fill" variant="ghost" label="Phase suivante" />
<IconButton icon="clock-counter-clockwise" iconWeight="regular" variant="square" label="Historique" />
```
