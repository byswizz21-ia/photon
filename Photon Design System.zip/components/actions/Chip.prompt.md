Compact pill for secondary actions and tokens — quick prompts, folder favourites, confirm rows.

```jsx
<Chip icon="clipboard-text">Presse-papier</Chip>
<Chip>Résumer</Chip>
<Chip size="md" icon="folder">Documents</Chip>
<Chip variant="danger">Activer</Chip>
<FileChip name="capture.png" onRemove={() => {}} />
```
