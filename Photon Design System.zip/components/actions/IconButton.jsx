import React from 'react';
import { Icon } from '../icons/Icon.jsx';
import './Button.jsx';

const SIZES = { action: { md: 36, sm: 30 }, ghost: { md: 32, sm: 30 }, square: { md: 30, sm: 26 } };

export function IconButton({ icon, label, variant = 'action', size = 'md', iconSize, iconWeight = 'duotone', pressed, type = 'button', style, ...rest }) {
  const px = SIZES[variant][size];
  const cls = variant === 'action' ? 'pt-action pt-icon' + (size === 'sm' ? ' pt-sm' : '') : 'pt-ghost' + (variant === 'square' ? ' pt-square' : '');
  const glyph = iconSize || (variant === 'action' ? (size === 'sm' ? 14 : 18) : 16);
  return (
    <button type={type} className={cls} aria-label={label} title={label} aria-pressed={pressed} style={variant === 'action' ? style : { width: px, height: px, ...style }} {...rest}>
      {typeof icon === 'string' ? <Icon name={icon} weight={iconWeight} size={glyph} /> : icon}
    </button>
  );
}
