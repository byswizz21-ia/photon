/** Round play/pause disc: var(--text) fill, var(--bg) glyph, fill-weight icon. */
export interface PlayButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  playing?: boolean;
  /** 38 (pomodoro) or 40 (music) */
  size?: number;
  /** Translucent black variant laid over album art */
  overlay?: boolean;
}
export declare function PlayButton(props: PlayButtonProps): JSX.Element;
