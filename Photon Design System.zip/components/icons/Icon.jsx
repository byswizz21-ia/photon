import React from 'react';

// Phosphor web-font wrapper. Requires <script src="https://unpkg.com/@phosphor-icons/web@2.1.1"></script> on the page.
export function Icon({ name, weight = 'regular', size = 18, color, style, label, className = '' }) {
  const cls = weight === 'regular' ? 'ph' : 'ph-' + weight;
  return (
    <i
      className={cls + ' ph-' + name + (className ? ' ' + className : '')}
      aria-hidden={label ? undefined : 'true'}
      aria-label={label}
      role={label ? 'img' : undefined}
      style={{ fontSize: size, lineHeight: 1, display: 'inline-flex', flex: 'none', color, ...style }}
    />
  );
}
