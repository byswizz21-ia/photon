Phosphor icon wrapper — use for every glyph in Photon; never hand-draw icons.

```jsx
<Icon name="gear-six" weight="duotone" size={18} />
<Icon name="check" weight="bold" size={16} />
<Icon name="sun" weight="duotone" size={44} color="var(--accent)" />
```

- Load `https://unpkg.com/@phosphor-icons/web@2.1.1` once per page.
- Weights by role: `duotone` toolbar/menu/widget glyphs; `bold` check, plus, x, arrows; `fill` play/pause/skip/moon-active; `regular` small inline (speaker, copy, history).
- Sizes in use: 12, 14, 16, 18, 20, 24, 32, 44.
