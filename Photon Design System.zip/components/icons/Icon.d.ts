/** Phosphor icon (web font). Photon uses duotone by default, bold for check/plus/x, fill for media controls. */
export interface IconProps {
  /** Phosphor name in kebab-case, e.g. "gear-six", "magnifying-glass" */
  name: string;
  weight?: 'regular' | 'bold' | 'fill' | 'duotone' | 'thin' | 'light';
  /** px */
  size?: number;
  color?: string;
  /** Accessible label; omit for decorative icons */
  label?: string;
  className?: string;
  style?: React.CSSProperties;
}
export declare function Icon(props: IconProps): JSX.Element;
