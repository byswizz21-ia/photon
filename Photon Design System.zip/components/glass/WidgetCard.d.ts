/**
 * The glass card every widget lives in: sheen fill, 1px glass edge, top rim, soft drop. Hover lifts 2px and lights an accent ring with a spot that follows the cursor; press scales to .97 with a spring return.
 * @startingPoint section="Glass" subtitle="Glass widget card with hover light ring" viewport="700x260"
 */
export interface WidgetCardProps {
  children?: React.ReactNode;
  /** aria-label, e.g. "Horloge" */
  label?: string;
  /** Edit mode: grab cursor, no lift, shows remove badge when onRemove is set */
  editing?: boolean;
  /** Disable the press scale (widgets where you type/select text) */
  noPress?: boolean;
  /** Show the contained error state */
  failed?: boolean;
  onRetry?: () => void;
  onRemove?: () => void;
  style?: React.CSSProperties;
  className?: string;
}
export declare function WidgetCard(props: WidgetCardProps): JSX.Element;
