import React from 'react';
import { Icon } from '../icons/Icon.jsx';
const CSS = `.pt-menu{min-width:200px;margin:0;padding:6px;list-style:none;border-radius:14px;background:var(--glass-sheen),rgb(20 22 29 / .6);backdrop-filter:blur(24px) saturate(1.7);-webkit-backdrop-filter:blur(24px) saturate(1.7);border:1px solid var(--glass-edge);box-shadow:var(--glass-rim),0 16px 40px -16px rgb(0 0 0 / .6);font-family:var(--font-sans);color:var(--text);box-sizing:border-box}
.pt-menu button{width:100%;min-height:40px;display:flex;align-items:center;gap:10px;padding:0 12px;border:0;border-radius:10px;background:transparent;font-size:14px;color:var(--text);text-align:left;cursor:pointer}
.pt-menu button:hover,.pt-menu button:focus-visible{background:rgb(255 255 255 / .06)}
.pt-menu .pt-menu-label{padding:8px 12px 4px;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--text-faint)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-menu-css')) { const s = document.createElement('style'); s.id = 'pt-menu-css'; s.textContent = CSS; document.head.appendChild(s); }

export function Menu({ children, style, label }) {
  return <ul className="pt-menu" role="menu" aria-label={label} style={style}>{children}</ul>;
}
export function MenuItem({ children, icon, onClick }) {
  return (
    <li role="none">
      <button type="button" role="menuitem" onClick={onClick}>
        {typeof icon === 'string' ? <Icon name={icon} weight="duotone" size={20} color="var(--accent)" /> : icon}
        {children}
      </button>
    </li>
  );
}
export function MenuLabel({ children }) {
  return <li role="separator" className="pt-menu-label">{children}</li>;
}
