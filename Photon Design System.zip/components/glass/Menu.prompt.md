Glass dropdown menu anchored under an action button.

```jsx
<div style={{ position: 'relative' }}>
  <Button icon="plus">Ajouter</Button>
  <Menu style={{ position: 'absolute', right: 0, top: 'calc(100% + 8px)', zIndex: 10 }}>
    <MenuItem icon="clock">Horloge</MenuItem>
    <MenuItem icon="cpu">Système</MenuItem>
    <MenuLabel>Modèles</MenuLabel>
    <MenuItem>Travail</MenuItem>
  </Menu>
</div>
```
