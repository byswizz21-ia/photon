import React from 'react';
import { Icon } from '../icons/Icon.jsx';
const CSS = `.pt-card{position:relative;box-sizing:border-box;height:100%;border-radius:var(--radius);background:var(--glass-sheen);border:1px solid var(--glass-edge);box-shadow:var(--glass-rim),0 10px 30px -14px rgb(0 0 0 / .55);transition:transform 450ms var(--ease-spring);color:var(--text);font-family:var(--font-sans)}
.pt-card::before{content:'';position:absolute;inset:-1px;border-radius:inherit;border:1px solid color-mix(in srgb,var(--accent) 55%,transparent);box-shadow:0 0 40px -12px var(--accent);opacity:0;transition:opacity 200ms var(--ease-out);pointer-events:none}
.pt-card:hover{transform:translateY(-2px)}
.pt-card:hover::before,.pt-card:hover .pt-ring{opacity:1}
.pt-card:active:not(.pt-nopress){transform:translateY(-1px) scale(.97);transition-duration:120ms;transition-timing-function:var(--ease-out)}
.pt-card.pt-editing{cursor:grab;transform:none}
.pt-ring{position:absolute;inset:-1px;padding:1px;border-radius:inherit;overflow:hidden;-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box exclude,linear-gradient(#000 0 0);opacity:0;transition:opacity 200ms var(--ease-out);pointer-events:none}
.pt-spot{position:absolute;left:-110px;top:-110px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,var(--accent),transparent 70%);will-change:transform}
.pt-card-content{height:100%;container-type:size;overflow:hidden;border-radius:inherit}
.pt-remove{position:absolute;top:-8px;right:-8px;width:28px;height:28px;display:grid;place-items:center;padding:0;border:1px solid var(--line);border-radius:50%;background:var(--surface-chip);color:var(--text);cursor:pointer;z-index:2}
.pt-remove:hover{background:var(--surface-chip-danger);color:var(--danger-text)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-card-css')) { const s = document.createElement('style'); s.id = 'pt-card-css'; s.textContent = CSS; document.head.appendChild(s); }

export function WidgetCard({ children, label, editing = false, noPress = false, failed = false, onRetry, onRemove, style, className = '' }) {
  const [spot, setSpot] = React.useState({ x: 0, y: 0 });
  const track = (e) => {
    const box = e.currentTarget.getBoundingClientRect();
    setSpot({ x: e.clientX - box.left, y: e.clientY - box.top });
  };
  return (
    <article className={'pt-card' + (editing ? ' pt-editing' : '') + (noPress ? ' pt-nopress' : '') + (className ? ' ' + className : '')} aria-label={label} onPointerMove={track} style={style}>
      <span className="pt-ring" aria-hidden="true"><span className="pt-spot" style={{ transform: 'translate(' + spot.x + 'px, ' + spot.y + 'px)' }} /></span>
      <div className="pt-card-content">
        {failed ? (
          <div role="alert" style={{ height: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 10, padding: 16, boxSizing: 'border-box', textAlign: 'center', color: 'var(--text-muted)', fontSize: 13 }}>
            <p style={{ margin: 0 }}>Ce widget a rencontré un problème.</p>
            <button type="button" className="pt-action" onClick={onRetry}>Réessayer</button>
          </div>
        ) : children}
      </div>
      {editing && onRemove && (
        <button className="pt-remove" type="button" aria-label={'Supprimer ' + (label || '')} onClick={onRemove}><Icon name="x" weight="bold" size={14} /></button>
      )}
    </article>
  );
}
