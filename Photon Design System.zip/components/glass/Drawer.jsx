import React from 'react';
import { IconButton } from '../actions/IconButton.jsx';

export function Drawer({ title, onClose, children, style }) {
  return (
    <div role="dialog" aria-label={title} style={{ boxSizing: 'border-box', width: 'min(360px, calc(100% - 24px))', padding: 20, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 24,
      border: '1px solid var(--glass-edge)', borderRadius: 'var(--radius-panel)', background: 'var(--glass-sheen), rgb(14 16 22 / .6)', backdropFilter: 'blur(30px) saturate(1.7)', WebkitBackdropFilter: 'blur(30px) saturate(1.7)',
      boxShadow: 'var(--glass-rim), 0 24px 60px -20px rgb(0 0 0 / .7)', color: 'var(--text)', fontFamily: 'var(--font-sans)', ...style }}>
      <header style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 600, letterSpacing: '-0.01em' }}>{title}</h2>
        {onClose && <IconButton icon="x" iconWeight="bold" label="Fermer" onClick={onClose} />}
      </header>
      {children}
    </div>
  );
}

export function DrawerSection({ title, children }) {
  return (
    <section style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
      <h3 style={{ margin: 0, fontSize: 12, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.1em', color: 'var(--text-faint)' }}>{title}</h3>
      {children}
    </section>
  );
}
