Glass side drawer for settings; opens with a 180ms fade + 16px slide from the right.

```jsx
<Drawer title="Réglages" onClose={close} style={{ position: 'absolute', top: 12, right: 12, bottom: 12 }}>
  <DrawerSection title="Verre">
    <Slider variant="accent" label="Flou du verre" value={48} max={120} valueText="48 px" />
  </DrawerSection>
</Drawer>
```
