/** Floating glass dropdown (Ajouter, profils). Position it yourself: absolute, top calc(100% + 8px). */
export interface MenuProps { children?: React.ReactNode; label?: string; style?: React.CSSProperties }
export declare function Menu(props: MenuProps): JSX.Element;
export interface MenuItemProps {
  children?: React.ReactNode;
  /** Phosphor name → 20px duotone in accent; or node */
  icon?: string | React.ReactNode;
  onClick?: () => void;
}
export declare function MenuItem(props: MenuItemProps): JSX.Element;
export interface MenuLabelProps { children?: React.ReactNode }
/** 11px uppercase group label */
export declare function MenuLabel(props: MenuLabelProps): JSX.Element;
