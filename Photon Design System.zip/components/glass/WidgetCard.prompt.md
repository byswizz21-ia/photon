Glass card container for any widget or tile-sized content; give it an explicit height.

```jsx
<WidgetCard label="Horloge" style={{ height: 210 }}>
  <div style={{ padding: 24 }}>…</div>
</WidgetCard>
<WidgetCard editing onRemove={remove} />
<WidgetCard failed onRetry={retry} />
```

- Content is a size container: widgets size type with `cqw` / `cqh`.
- Inner padding is 12–24px (`clamp(12px, 9cqmin, 20px)` typical).
- Never add a second border, left accent stripe or opaque fill.
