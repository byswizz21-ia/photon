/** Right-hand glass drawer (Réglages): 360px, panel radius, blur 30. Place absolutely top/right/bottom 12px. */
export interface DrawerProps { title: string; onClose?: () => void; children?: React.ReactNode; style?: React.CSSProperties }
export declare function Drawer(props: DrawerProps): JSX.Element;
export interface DrawerSectionProps { title: string; children?: React.ReactNode }
/** Section with 12px uppercase faint heading, 14px gap */
export declare function DrawerSection(props: DrawerSectionProps): JSX.Element;
