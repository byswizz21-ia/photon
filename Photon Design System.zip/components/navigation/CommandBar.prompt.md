The header search / launcher bar; results float below in a glass popover.

```jsx
<CommandBar value="spo" results={[{ kind: 'app', title: 'Spotify', subtitle: 'Application' }, { kind: 'web', title: 'Rechercher « spo »', subtitle: 'Sur le web' }]} />
<CommandBar mini results={favourites} />
```

Keyboard: ↑ ↓ choose, Entrée open, Ctrl+Entrée open folder, Tab ask Claude, Échap clear.
