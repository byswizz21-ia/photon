/**
 * Command bar: pill search field (38px, black 20 % fill) with a floating glass result list. mini = standalone launcher window (44px field, 14px radius, list in flow).
 * @startingPoint section="Navigation" subtitle="Search / calculate / ask Claude bar with results" viewport="700x380"
 */
export interface CommandResult {
  id?: string;
  kind: 'app' | 'file' | 'folder' | 'site' | 'web' | 'calc' | 'command' | 'action' | 'claude';
  title: string;
  subtitle?: string;
  warn?: boolean;
  iconSrc?: string;
}
export interface CommandBarProps {
  value?: string;
  onChange?: (value: string) => void;
  placeholder?: string;
  results?: CommandResult[];
  selected?: number;
  onSelect?: (result: CommandResult, index: number) => void;
  onHover?: (index: number) => void;
  mini?: boolean;
  /** Short inline notice at the right of the field (« Impossible d'ouvrir ») */
  notice?: string;
  /** Force the list open/closed; default = open when typing (always in mini) */
  open?: boolean;
  style?: React.CSSProperties;
}
export declare function CommandBar(props: CommandBarProps): JSX.Element;
