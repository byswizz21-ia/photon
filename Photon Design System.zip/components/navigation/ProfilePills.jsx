import React from 'react';
import { Icon } from '../icons/Icon.jsx';
import { IconButton } from '../actions/IconButton.jsx';
const CSS = `.pt-pill{flex:none;display:inline-flex;align-items:center;gap:5px;height:30px;padding:0 12px;border:1px solid transparent;border-radius:999px;background:none;color:var(--text-muted);font-family:var(--font-sans);font-size:13px;white-space:nowrap;cursor:pointer;transition:transform 300ms var(--ease-spring);box-sizing:border-box}
.pt-pill:hover{color:var(--text);background:rgb(255 255 255 / .06)}
.pt-pill:active{transform:scale(.96);transition-duration:100ms}
.pt-pill.pt-active{border-color:color-mix(in srgb,var(--accent) 45%,transparent);background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--text)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-pill-css')) { const s = document.createElement('style'); s.id = 'pt-pill-css'; s.textContent = CSS; document.head.appendChild(s); }

export function ProfilePill({ name, active, focus, title, onClick }) {
  return (
    <button type="button" className={'pt-pill' + (active ? ' pt-active' : '')} aria-pressed={!!active} title={title} onClick={onClick}>
      {focus && <Icon name="moon" weight="fill" size={12} label="Focus" />}
      {name}
    </button>
  );
}

export function ProfilePills({ profiles = [], active, onSelect, onAdd }) {
  return (
    <div style={{ minWidth: 0, display: 'flex', alignItems: 'center', gap: 6 }}>
      <div role="group" aria-label="Profils" style={{ minWidth: 0, display: 'flex', alignItems: 'center', gap: 4, overflowX: 'auto', scrollbarWidth: 'none' }}>
        {profiles.map((p, i) => <ProfilePill key={p.id} name={p.name} focus={p.focus} active={p.id === active} title={i < 9 ? 'Ctrl+' + (i + 1) : undefined} onClick={() => onSelect && onSelect(p.id)} />)}
      </div>
      {onAdd !== null && <IconButton icon="plus" iconWeight="bold" size="sm" label="Nouveau profil" onClick={onAdd} />}
    </div>
  );
}
