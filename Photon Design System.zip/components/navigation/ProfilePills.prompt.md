Profile switcher pills in the header (Ctrl+1…9).

```jsx
<ProfilePills active="default" profiles={[{id:'default',name:'Principal'},{id:'focus',name:'Focus',focus:true},{id:'gaming',name:'Gaming'}]} />
```
