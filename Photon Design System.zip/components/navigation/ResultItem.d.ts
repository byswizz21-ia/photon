export type ResultKind = 'app' | 'file' | 'folder' | 'site' | 'web' | 'calc' | 'command' | 'action' | 'claude';
/** One row of the command bar result list: 32px icon tile, title 14 / subtitle 12, key hint on the selected row. */
export interface ResultItemProps {
  kind: ResultKind;
  title: string;
  subtitle?: string;
  selected?: boolean;
  /** Heavy command awaiting a second Enter: subtitle turns red */
  warn?: boolean;
  kbd?: string;
  /** Real Windows icon (apps, files) */
  iconSrc?: string;
  id?: string;
  onClick?: () => void;
  onPointerMove?: () => void;
}
export declare function ResultItem(props: ResultItemProps): JSX.Element;
export interface ResultIconProps { kind?: ResultKind; src?: string }
/** 32px rounded tile with Phosphor duotone glyph; Claude tinted accent. */
export declare function ResultIcon(props: ResultIconProps): JSX.Element;
