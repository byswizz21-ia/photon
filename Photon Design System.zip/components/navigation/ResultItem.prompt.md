Command-bar result row.

```jsx
<ResultItem kind="app" title="Spotify" subtitle="Application" selected />
<ResultItem kind="calc" title="= 1 512" subtitle="Calcul · 42 × 36" />
<ResultItem kind="claude" title="Demander à Claude" subtitle="« comment vider le cache DNS »" />
```
