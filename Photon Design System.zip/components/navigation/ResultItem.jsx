import React from 'react';
import { Icon } from '../icons/Icon.jsx';
import { Kbd } from './Kbd.jsx';

const ICONS = { app: 'app-window', file: 'file', folder: 'folder', site: 'globe', web: 'magnifying-glass', calc: 'calculator', command: 'command', action: 'sliders-horizontal', claude: 'sparkle' };

export function ResultIcon({ kind = 'app', src }) {
  const claude = kind === 'claude';
  return (
    <span aria-hidden="true" style={{ flex: 'none', width: 32, height: 32, display: 'grid', placeItems: 'center', borderRadius: 9,
      background: claude ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'rgb(255 255 255 / .06)', color: claude ? 'var(--accent)' : 'var(--text-muted)' }}>
      {src ? <img src={src} alt="" width="24" height="24" /> : <Icon name={ICONS[kind] || 'app-window'} weight="duotone" size={20} />}
    </span>
  );
}

export function ResultItem({ kind, title, subtitle, selected, warn, kbd, iconSrc, onClick, onPointerMove, id }) {
  return (
    <li id={id} role="option" aria-selected={!!selected} onClick={onClick} onPointerMove={onPointerMove}
      style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '7px 10px', borderRadius: 12, cursor: 'pointer', background: selected ? 'rgb(255 255 255 / .08)' : 'transparent', listStyle: 'none' }}>
      <ResultIcon kind={kind} src={iconSrc} />
      <span style={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <span style={{ fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{title}</span>
        <span style={{ fontSize: 12, color: warn ? 'var(--danger-text)' : 'var(--text-faint)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
          {warn ? 'Entrée encore une fois pour confirmer' : subtitle}
        </span>
      </span>
      {selected && <Kbd>{kbd || (kind === 'claude' ? 'Tab' : 'Entrée')}</Kbd>}
    </li>
  );
}
