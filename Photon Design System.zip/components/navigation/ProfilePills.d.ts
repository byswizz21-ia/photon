export interface Profile { id: string; name: string; focus?: boolean }
/** Header profile switcher: borderless 30px pills; active = accent 45 % border on accent 16 % fill; trailing « + » button. */
export interface ProfilePillsProps {
  profiles?: Profile[];
  active?: string;
  onSelect?: (id: string) => void;
  /** Pass null to hide the « + » button */
  onAdd?: (() => void) | null;
}
export declare function ProfilePills(props: ProfilePillsProps): JSX.Element;
export interface ProfilePillProps { name: string; active?: boolean; focus?: boolean; title?: string; onClick?: () => void }
export declare function ProfilePill(props: ProfilePillProps): JSX.Element;
