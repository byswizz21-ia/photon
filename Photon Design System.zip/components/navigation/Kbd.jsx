import React from 'react';

export function Kbd({ children }) {
  return <kbd style={{ flex: 'none', padding: '2px 7px', border: '1px solid var(--line)', borderRadius: 6, fontFamily: 'var(--font-sans)', fontSize: 11, color: 'var(--text-faint)' }}>{children}</kbd>;
}
