Key hint shown on the selected command result.

```jsx
<Kbd>Entrée</Kbd>  <Kbd>Tab</Kbd>
```
