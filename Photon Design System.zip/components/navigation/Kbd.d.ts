/** Keyboard hint: 11px, hairline border, 6px radius. Key names in French (Entrée, Échap, Tab, Ctrl+1). */
export interface KbdProps { children?: React.ReactNode }
export declare function Kbd(props: KbdProps): JSX.Element;
