import React from 'react';
import { Icon } from '../icons/Icon.jsx';
import { ResultItem } from './ResultItem.jsx';

export function CommandBar({ value = '', onChange, placeholder = 'Rechercher, calculer, demander à Claude…', results = [], selected = 0, onSelect, onHover, mini = false, notice, open, style }) {
  const [focus, setFocus] = React.useState(false);
  const show = open != null ? open : results.length > 0 && (mini || value.trim() !== '');
  const list = show && (
    <ul role="listbox" aria-label="Résultats" style={mini ? { margin: '8px 0 0', padding: 0 } : {
      position: 'absolute', top: 'calc(100% + 8px)', left: 0, right: 0, zIndex: 30, margin: 0, padding: 6, border: '1px solid var(--glass-edge)', borderRadius: 18,
      background: 'var(--glass-sheen), rgb(16 18 24 / .86)', backdropFilter: 'var(--glass-filter)', WebkitBackdropFilter: 'var(--glass-filter)', boxShadow: 'var(--glass-rim), 0 24px 60px -20px rgb(0 0 0 / .7)' }}>
      {results.map((r, i) => <ResultItem key={r.id || i} {...r} selected={i === selected} onClick={() => onSelect && onSelect(r, i)} onPointerMove={() => onHover && onHover(i)} />)}
    </ul>
  );
  return (
    <div style={{ position: 'relative', flex: 1, minWidth: 0, maxWidth: mini ? 'none' : 560, margin: '0 auto', padding: mini ? 12 : 0, fontFamily: 'var(--font-sans)', ...style }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, height: mini ? 44 : 38, padding: '0 14px', boxSizing: 'border-box', borderRadius: mini ? 14 : 999, background: 'rgb(0 0 0 / .2)', color: 'var(--text-faint)',
        border: '1px solid ' + (focus ? 'color-mix(in srgb, var(--accent) 50%, transparent)' : 'var(--line)') }}>
        <Icon name="magnifying-glass" size={18} />
        <input value={value} onChange={(e) => onChange && onChange(e.currentTarget.value)} onFocus={() => setFocus(true)} onBlur={() => setFocus(false)}
          type="text" spellCheck="false" autoComplete="off" placeholder={placeholder} aria-label="Barre de commande" role="combobox" aria-expanded={!!show}
          style={{ flex: 1, minWidth: 0, border: 0, outline: 0, background: 'none', color: 'var(--text)', fontFamily: 'inherit', fontSize: mini ? 16 : 14 }} />
        {notice && <span style={{ fontSize: 12 }}>{notice}</span>}
      </div>
      {list}
    </div>
  );
}
