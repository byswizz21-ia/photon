/** Uppercase widget heading: 12px, 0.1em tracking, --text-faint. Optional right-aligned aside (count). */
export interface WidgetLabelProps { children?: React.ReactNode; aside?: React.ReactNode; style?: React.CSSProperties }
export declare function WidgetLabel(props: WidgetLabelProps): JSX.Element;
