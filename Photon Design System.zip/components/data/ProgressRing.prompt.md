Countdown ring for timers.

```jsx
<ProgressRing progress={0.64} label="16:02" />
<ProgressRing progress={0.3} label="1:30" tone="secondary" />   {/* pause */}
```
