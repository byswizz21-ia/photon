/** Pomodoro ring: 6-unit stroke, white 10 % track, accent (or violet in pause) with drop-shadow glow; empties clockwise from 12 o'clock. */
export interface ProgressRingProps {
  /** 1 = full, 0 = empty */
  progress?: number;
  /** Centre text, e.g. "25:00" */
  label?: React.ReactNode;
  /** Label font size; default scales with the rendered ring (clamp 12–30px, 22cqmin) */
  labelSize?: number | string;
  tone?: 'accent' | 'secondary';
  size?: number;
  style?: React.CSSProperties;
}
export declare function ProgressRing(props: ProgressRingProps): JSX.Element;
