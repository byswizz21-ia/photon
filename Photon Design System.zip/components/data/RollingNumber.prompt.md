Use for any number that changes live (clock, CPU %, free space).

```jsx
<span style={{ fontSize: 96, fontWeight: 300, letterSpacing: '-0.04em' }}><RollingNumber value="14:32" /></span>
<RollingNumber value={23} /> %
```
