Top-left label of every widget — one or two French words.

```jsx
<WidgetLabel>Système</WidgetLabel>
<WidgetLabel aside="3 à faire">To-do</WidgetLabel>
```
