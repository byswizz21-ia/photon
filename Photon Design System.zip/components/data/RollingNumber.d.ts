/** Text whose digits roll on a spring when they change ("14:32", "23", "412"). Tabular numerals. */
export interface RollingNumberProps { value: string | number; style?: React.CSSProperties }
export declare function RollingNumber(props: RollingNumberProps): JSX.Element;
