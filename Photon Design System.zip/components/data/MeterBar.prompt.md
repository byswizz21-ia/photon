Usage meter for CPU / RAM / GPU / disk.

```jsx
<MeterBar value={0.23} />
<MeterBar value={0.71} thickness={3} />
```
