/** Thin usage bar: white 12 % track, accent fill with glow, animated with scaleX only. */
export interface MeterBarProps {
  /** 0..1 */
  value?: number;
  /** 4 (default) or 3 for secondary rows */
  thickness?: number;
  glow?: boolean;
  color?: string;
  style?: React.CSSProperties;
}
export declare function MeterBar(props: MeterBarProps): JSX.Element;
