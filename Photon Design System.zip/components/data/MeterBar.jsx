import React from 'react';

export function MeterBar({ value = 0, thickness = 4, glow = true, color = 'var(--accent)', style }) {
  const v = Math.min(1, Math.max(0, value));
  return (
    <div aria-hidden="true" style={{ flex: 'none', height: thickness, borderRadius: 4, background: 'rgb(255 255 255 / .12)', ...style }}>
      <div style={{ height: '100%', borderRadius: 'inherit', background: color, boxShadow: glow ? '0 0 10px ' + color : 'none', transformOrigin: 'left', transform: 'scaleX(' + v + ')', transition: 'transform 400ms var(--ease-out)' }} />
    </div>
  );
}
