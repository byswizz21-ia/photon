import React from 'react';

export function WidgetLabel({ children, aside, style }) {
  const label = <span style={{ fontSize: 12, letterSpacing: '0.1em', textTransform: 'uppercase', color: 'var(--text-faint)', ...(aside ? {} : style) }}>{children}</span>;
  if (!aside) return label;
  return (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', ...style }}>
      {label}
      <span style={{ fontSize: 12, color: 'var(--text-faint)' }}>{aside}</span>
    </div>
  );
}
