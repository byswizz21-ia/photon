import React from 'react';

const R = 44;
const C = 2 * Math.PI * R;

export function ProgressRing({ progress = 1, label, tone = 'accent', size = 120, labelSize, style }) {
  const stroke = tone === 'secondary' ? 'var(--glow-secondary)' : 'var(--accent)';
  return (
    <div style={{ position: 'relative', width: size, height: size, flex: 'none', display: 'grid', placeItems: 'center', containerType: 'size', ...style }}>
      <svg viewBox="0 0 100 100" aria-hidden="true" style={{ position: 'absolute', inset: 0, transform: 'rotate(-90deg)' }}>
        <circle cx="50" cy="50" r={R} fill="none" strokeWidth="6" strokeLinecap="round" stroke="rgb(255 255 255 / .1)" />
        <circle cx="50" cy="50" r={R} fill="none" strokeWidth="6" strokeLinecap="round" stroke={stroke} strokeDasharray={C} strokeDashoffset={C * (1 - progress)}
          style={{ filter: 'drop-shadow(0 0 6px color-mix(in srgb, ' + stroke + ' 60%, transparent))' }} />
      </svg>
      {label != null && <span style={{ position: 'relative', fontSize: labelSize || 'clamp(12px, 22cqmin, 30px)', fontWeight: 300, fontVariantNumeric: 'tabular-nums' }}>{label}</span>}
    </div>
  );
}
