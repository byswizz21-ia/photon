import React from 'react';

function Digit({ value }) {
  return (
    <span style={{ display: 'inline-block', height: '1em', overflow: 'hidden', lineHeight: 1 }}>
      <span style={{ display: 'flex', flexDirection: 'column', transform: 'translateY(' + -value + 'em)', transition: 'transform 600ms var(--ease-spring)', willChange: 'transform' }}>
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => <span key={n} style={{ height: '1em' }}>{n}</span>)}
      </span>
    </span>
  );
}

// Digits roll like a counter instead of jumping; other characters stay put.
export function RollingNumber({ value, style }) {
  const chars = String(value).split('');
  return (
    <span style={{ display: 'inline-block', fontVariantNumeric: 'tabular-nums', ...style }} aria-label={String(value)}>
      <span style={{ display: 'inline-flex' }} aria-hidden="true">
        {chars.map((c, i) => (c >= '0' && c <= '9' ? <Digit key={i} value={Number(c)} /> : <span key={i}>{c}</span>))}
      </span>
    </span>
  );
}
