import React from 'react';
const CSS = `.pt-seg{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:2px;min-width:0;margin:0;padding:3px;border:1px solid var(--line);border-radius:999px;background:rgb(255 255 255 / .04)}
.pt-seg label{position:relative;display:flex}
.pt-seg input{position:absolute;inset:0;width:100%;height:100%;margin:0;border-radius:999px;opacity:0;cursor:pointer}
.pt-seg span{flex:1;display:grid;place-items:center;min-height:32px;padding:4px 10px;border-radius:999px;font-family:var(--font-sans);font-size:13px;font-weight:500;line-height:1.2;text-align:center;text-wrap:balance;color:var(--text-muted)}
.pt-seg input:not(:checked):hover + span{color:var(--text);background:rgb(255 255 255 / .06)}
.pt-seg input:checked + span{background:var(--accent);color:var(--on-accent)}
.pt-seg input:focus-visible + span{outline:2px solid var(--accent);outline-offset:2px}
.pt-modes{display:inline-flex;padding:2px;border-radius:999px;background:rgb(0 0 0 / .22)}
.pt-modes button{padding:2px 9px;border:0;border-radius:999px;background:none;font-family:var(--font-sans);font-size:11px;color:var(--text-faint);cursor:pointer}
.pt-modes button:hover{color:var(--text)}
.pt-modes [aria-checked=true]{color:var(--accent);background:color-mix(in srgb,var(--accent) 16%,transparent)}
.pt-modes .pt-danger[aria-checked=true]{color:var(--danger-text-strong);background:rgb(255 77 94 / .18)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-seg-css')) { const s = document.createElement('style'); s.id = 'pt-seg-css'; s.textContent = CSS; document.head.appendChild(s); }

let uid = 0;
export function Segmented({ options, value, onChange, label, name, size = 'md' }) {
  const [auto] = React.useState(() => 'pt-seg-' + ++uid);
  const group = name || auto;
  if (size === 'sm') {
    return (
      <div className="pt-modes" role="radiogroup" aria-label={label}>
        {options.map((o) => (
          <button key={o.value} type="button" role="radio" className={o.danger ? 'pt-danger' : undefined} aria-checked={value === o.value} title={o.hint} onClick={() => onChange && onChange(o.value)}>{o.label}</button>
        ))}
      </div>
    );
  }
  return (
    <fieldset className="pt-seg">
      {label && <legend style={{ position: 'absolute', width: 1, height: 1, overflow: 'hidden', clipPath: 'inset(50%)' }}>{label}</legend>}
      {options.map((o) => (
        <label key={o.value}>
          <input type="radio" name={group} value={o.value} checked={value === o.value} onChange={() => onChange && onChange(o.value)} />
          <span>{o.label}</span>
        </label>
      ))}
    </fieldset>
  );
}
