/** native = OS checkbox tinted with accent-color + 13px label (settings, widget options). task = 18px rounded square that fills with accent (to-do). */
export interface CheckboxProps {
  checked?: boolean;
  onChange?: (checked: boolean) => void;
  label?: string;
  hint?: string;
  disabled?: boolean;
  variant?: 'native' | 'task';
  style?: React.CSSProperties;
}
export declare function Checkbox(props: CheckboxProps): JSX.Element;
