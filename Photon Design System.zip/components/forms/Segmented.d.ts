/** Pill radio group. md: settings drawer (accent-filled selection); sm: Claude mode toggle (11px, accent text on accent 16 %). */
export interface SegmentedOption { value: string; label: string; hint?: string; /** sm only: red when selected (Bypass) */ danger?: boolean }
export interface SegmentedProps {
  options: SegmentedOption[];
  value: string;
  onChange?: (value: string) => void;
  /** Accessible group label */
  label?: string;
  name?: string;
  size?: 'md' | 'sm';
}
export declare function Segmented(props: SegmentedProps): JSX.Element;
