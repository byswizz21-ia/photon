Checkbox: native (accent-tinted) for settings, task for to-do rows.

```jsx
<Checkbox label="Toujours au-dessus" hint="Mode fenêtre uniquement" disabled />
<Checkbox label="Afficher les secondes" checked />
<Checkbox variant="task" checked label="Appeler le garage" />
```
