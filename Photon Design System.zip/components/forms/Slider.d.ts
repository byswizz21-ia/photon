/** Range input. thin: 4px white fill, thumb appears on hover (volume, music progress). accent: settings slider with accent track, white ringed thumb, label row. */
export interface SliderProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'onChange' | 'value'> {
  value: number;
  min?: number;
  max?: number;
  step?: number;
  onChange?: (value: number) => void;
  variant?: 'thin' | 'accent';
  /** accent: visible label; thin: aria-label */
  label?: string;
  /** Right-aligned formatted value, e.g. "48 px", "50 %" */
  valueText?: string;
  /** thin: dimmed when muted */
  muted?: boolean;
}
export declare function Slider(props: SliderProps): JSX.Element;
