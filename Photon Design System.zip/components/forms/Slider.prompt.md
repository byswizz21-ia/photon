Range slider in Photon's two treatments.

```jsx
<Slider value={62} label="Volume" />                                       {/* thin */}
<Slider variant="accent" label="Flou du verre" value={48} max={120} valueText="48 px" />
```

Units are written French-style with a space: « 48 px », « 50 % ».
