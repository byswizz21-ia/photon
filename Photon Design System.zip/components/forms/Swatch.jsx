import React from 'react';

export function Swatch({ color, label, pressed, onClick, size = 28 }) {
  const [hover, setHover] = React.useState(false);
  return (
    <button type="button" aria-label={label} title={label} aria-pressed={pressed} onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{ width: size, height: size, padding: 0, border: 0, borderRadius: '50%', background: color, cursor: 'pointer',
        boxShadow: 'inset 0 0 0 1px rgb(255 255 255 / .25)' + (pressed ? ', 0 0 0 2px var(--surface-ring), 0 0 0 4px var(--text)' : ''),
        transform: hover ? 'scale(1.12)' : 'none', transition: 'transform 150ms var(--ease-out)' }} />
  );
}
