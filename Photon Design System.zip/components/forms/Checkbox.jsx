import React from 'react';
import { Icon } from '../icons/Icon.jsx';

export function Checkbox({ checked, onChange, label, hint, disabled, variant = 'native', style }) {
  if (variant === 'task') {
    return (
      <button type="button" role="checkbox" aria-checked={!!checked} aria-label={label} onClick={() => onChange && onChange(!checked)}
        style={{ flex: 'none', width: 18, height: 18, display: 'grid', placeItems: 'center', padding: 0, cursor: 'pointer', boxSizing: 'border-box',
          border: '1.5px solid ' + (checked ? 'var(--accent)' : 'var(--text-faint)'), borderRadius: 6, background: checked ? 'var(--accent)' : 'none', color: 'var(--on-accent)', ...style }}>
        {checked && <Icon name="check" weight="bold" size={12} />}
      </button>
    );
  }
  return (
    <label style={{ display: 'grid', gridTemplateColumns: '18px 1fr', alignItems: 'center', gap: '2px 10px', fontSize: 13, cursor: disabled ? 'default' : 'pointer', opacity: disabled ? 0.6 : 1, ...style }}>
      <input type="checkbox" checked={!!checked} disabled={disabled} onChange={(e) => onChange && onChange(e.currentTarget.checked)} style={{ margin: 0, accentColor: 'var(--accent)', cursor: 'inherit' }} />
      <span>{label}</span>
      {hint && <small style={{ gridColumn: 2, color: 'var(--text-faint)', fontSize: 12 }}>{hint}</small>}
    </label>
  );
}
