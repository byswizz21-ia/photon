/** 28px colour dot with inner hairline; selected = gap ring + text-colour ring; hover scale 1.12. */
export interface SwatchProps {
  color: string;
  /** French colour name: Bleu, Violet, Orange, Menthe */
  label?: string;
  pressed?: boolean;
  onClick?: () => void;
  size?: number;
}
export declare function Swatch(props: SwatchProps): JSX.Element;
