Dropdown for longer option lists in the settings drawer (screen, shortcuts).

```jsx
<Select label="Raccourci" value="Super+Alt+Space" options={[{value:'Super+Alt+Space',label:'Win+Alt+Espace'}]} />
```
