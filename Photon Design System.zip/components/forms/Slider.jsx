import React from 'react';
const CSS = `.pt-range{appearance:none;-webkit-appearance:none;flex:1;min-width:0;margin:0;cursor:pointer;background:transparent}
.pt-range.pt-thin{height:4px;border-radius:2px;background:linear-gradient(to right,var(--text) var(--fill),rgb(255 255 255 / .15) var(--fill))}
.pt-range.pt-thin::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:12px;height:12px;border-radius:50%;background:var(--text);opacity:0;transition:opacity 150ms var(--ease-out)}
.pt-range.pt-thin:hover::-webkit-slider-thumb,.pt-range.pt-thin:focus-visible::-webkit-slider-thumb{opacity:1}
.pt-range.pt-thin.pt-muted{opacity:.4}
.pt-range.pt-accent{flex:none;width:100%;height:20px}
.pt-range.pt-accent::-webkit-slider-runnable-track{height:4px;border-radius:2px;background:linear-gradient(to right,var(--accent) var(--fill),rgb(255 255 255 / .18) var(--fill))}
.pt-range.pt-accent::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:16px;height:16px;margin-top:-6px;border:0;border-radius:50%;background:#fff;box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 40%,transparent),0 2px 6px rgb(0 0 0 / .5);transition:transform 150ms var(--ease-out)}
.pt-range.pt-accent:active::-webkit-slider-thumb{transform:scale(1.15)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-range-css')) { const s = document.createElement('style'); s.id = 'pt-range-css'; s.textContent = CSS; document.head.appendChild(s); }

export function Slider({ value, min = 0, max = 100, step = 1, onChange, variant = 'thin', label, valueText, muted, style, ...rest }) {
  const fill = ((value - min) / (max - min || 1)) * 100 + '%';
  const input = (
    <input type="range" className={'pt-range pt-' + variant + (muted ? ' pt-muted' : '')} min={min} max={max} step={step} value={value} aria-label={label} aria-valuetext={valueText}
      style={{ '--fill': fill, ...(label && variant === 'accent' ? {} : style) }} onChange={(e) => onChange && onChange(e.currentTarget.valueAsNumber)} {...rest} />
  );
  if (variant !== 'accent' || !label) return input;
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 8, ...style }}>
      <span style={{ display: 'flex', justifyContent: 'space-between', fontSize: 13 }}>
        <span>{label}</span>
        <span style={{ color: 'var(--text-muted)', fontVariantNumeric: 'tabular-nums' }} aria-hidden="true">{valueText}</span>
      </span>
      {input}
    </label>
  );
}
