/** Native select: 36px, 12px radius, white 6 % fill; options on #14161d. */
export interface SelectOption { value: string; label: string }
export interface SelectProps {
  options: SelectOption[];
  value: string;
  onChange?: (value: string) => void;
  label?: string;
  hint?: string;
  style?: React.CSSProperties;
}
export declare function Select(props: SelectProps): JSX.Element;
