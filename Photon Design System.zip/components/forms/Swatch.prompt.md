Accent colour picker dot.

```jsx
<Swatch color="#7CC4FF" label="Bleu" pressed />
<Swatch color="#B69CFF" label="Violet" />
```
