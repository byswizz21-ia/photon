import React from 'react';
const CSS = `.pt-select{min-height:36px;padding:0 10px;border:1px solid var(--line);border-radius:12px;background:rgb(255 255 255 / .06);color:var(--text);font-family:var(--font-sans);font-size:13px;cursor:pointer}
.pt-select option{background:var(--surface-option);color:var(--text)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-select-css')) { const s = document.createElement('style'); s.id = 'pt-select-css'; s.textContent = CSS; document.head.appendChild(s); }

export function Select({ options, value, onChange, label, hint, style }) {
  const select = (
    <select className="pt-select" value={value} onChange={(e) => onChange && onChange(e.currentTarget.value)} aria-label={label}>
      {options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}
    </select>
  );
  if (!label) return select;
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 8, ...style }}>
      <span style={{ fontSize: 13 }}>{label}</span>
      {select}
      {hint && <small style={{ color: 'var(--text-faint)', fontSize: 12 }}>{hint}</small>}
    </label>
  );
}
