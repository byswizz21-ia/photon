Single-line input used inside widgets (to-do, weather city, calendar URL).

```jsx
<TextField placeholder="Ajouter une tâche…" />
<TextField label="Ville" placeholder="Lyon, Paris…" hint="Entrée pour valider" />
<TextField variant="inset" label="Adresse iCal secrète" placeholder="https://…/basic.ics" />
```

Placeholders end with an ellipsis « … ».
