/** Widget text input: 32px, 10px radius, white 5 % fill; focus = accent 50 % border. */
export interface TextFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label?: string;
  hint?: string;
  /** inset = 34px, glass-edge border, black 25 % fill (calendar iCal URL) */
  variant?: 'default' | 'inset';
  inputStyle?: React.CSSProperties;
}
export declare function TextField(props: TextFieldProps): JSX.Element;
