Segmented pill control for 2–3 mutually exclusive options.

```jsx
<Segmented label="Mode" value="fullscreen" options={[{value:'fullscreen',label:'Plein écran'},{value:'window',label:'Fenêtre'}]} />
<Segmented size="sm" value="question" options={[{value:'question',label:'Question'},{value:'agent',label:'Agent'},{value:'bypass',label:'Bypass',danger:true}]} />
```
