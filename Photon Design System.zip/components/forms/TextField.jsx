import React from 'react';
const CSS = `.pt-input{box-sizing:border-box;min-height:32px;padding:0 10px;border:1px solid var(--line);border-radius:10px;background:rgb(255 255 255 / .05);color:var(--text);font-family:var(--font-sans);font-size:13px;outline:0;user-select:text}
.pt-input:focus{border-color:color-mix(in srgb,var(--accent) 50%,transparent)}
.pt-input.pt-inset{min-height:34px;border-color:var(--glass-edge);background:rgb(0 0 0 / .25)}
.pt-input.pt-inset:focus-visible{outline:2px solid var(--accent);outline-offset:0}
.pt-input::placeholder{color:var(--text-faint)}
.pt-input:disabled{opacity:.6}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-field-css')) { const s = document.createElement('style'); s.id = 'pt-field-css'; s.textContent = CSS; document.head.appendChild(s); }

export function TextField({ label, hint, variant = 'default', style, inputStyle, ...rest }) {
  const input = <input className={'pt-input' + (variant === 'inset' ? ' pt-inset' : '')} style={inputStyle} {...rest} />;
  if (!label && !hint) return React.cloneElement(input, { style: { ...inputStyle, ...style } });
  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6, fontSize: variant === 'inset' ? 13 : 12, color: variant === 'inset' ? 'var(--text)' : 'var(--text-muted)', ...style }}>
      {label && <span>{label}</span>}
      {input}
      {hint && <small style={{ fontSize: variant === 'inset' ? 11 : 12, color: 'var(--text-faint)' }}>{hint}</small>}
    </label>
  );
}
