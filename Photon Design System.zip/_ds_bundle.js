/* @ds-bundle: {"format":4,"namespace":"PhotonDesignSystem_d1dfae","components":[{"name":"Button","sourcePath":"components/actions/Button.jsx"},{"name":"Chip","sourcePath":"components/actions/Chip.jsx"},{"name":"FileChip","sourcePath":"components/actions/Chip.jsx"},{"name":"IconButton","sourcePath":"components/actions/IconButton.jsx"},{"name":"PlayButton","sourcePath":"components/actions/PlayButton.jsx"},{"name":"MeterBar","sourcePath":"components/data/MeterBar.jsx"},{"name":"ProgressRing","sourcePath":"components/data/ProgressRing.jsx"},{"name":"RollingNumber","sourcePath":"components/data/RollingNumber.jsx"},{"name":"WidgetLabel","sourcePath":"components/data/WidgetLabel.jsx"},{"name":"Approval","sourcePath":"components/feedback/Approval.jsx"},{"name":"Checkbox","sourcePath":"components/forms/Checkbox.jsx"},{"name":"Segmented","sourcePath":"components/forms/Segmented.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Slider","sourcePath":"components/forms/Slider.jsx"},{"name":"Swatch","sourcePath":"components/forms/Swatch.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"Drawer","sourcePath":"components/glass/Drawer.jsx"},{"name":"DrawerSection","sourcePath":"components/glass/Drawer.jsx"},{"name":"Menu","sourcePath":"components/glass/Menu.jsx"},{"name":"MenuItem","sourcePath":"components/glass/Menu.jsx"},{"name":"MenuLabel","sourcePath":"components/glass/Menu.jsx"},{"name":"WidgetCard","sourcePath":"components/glass/WidgetCard.jsx"},{"name":"Icon","sourcePath":"components/icons/Icon.jsx"},{"name":"CommandBar","sourcePath":"components/navigation/CommandBar.jsx"},{"name":"Kbd","sourcePath":"components/navigation/Kbd.jsx"},{"name":"ProfilePill","sourcePath":"components/navigation/ProfilePills.jsx"},{"name":"ProfilePills","sourcePath":"components/navigation/ProfilePills.jsx"},{"name":"ResultIcon","sourcePath":"components/navigation/ResultItem.jsx"},{"name":"ResultItem","sourcePath":"components/navigation/ResultItem.jsx"}],"sourceHashes":{"components/actions/Button.jsx":"970449799699","components/actions/Chip.jsx":"6991a23be124","components/actions/IconButton.jsx":"faf67bac4116","components/actions/PlayButton.jsx":"493fb52c05ad","components/data/MeterBar.jsx":"8b7b53d4b510","components/data/ProgressRing.jsx":"b87aa836498e","components/data/RollingNumber.jsx":"8f03b59f6aef","components/data/WidgetLabel.jsx":"4925583972ce","components/feedback/Approval.jsx":"8b85a585d45b","components/forms/Checkbox.jsx":"4a5df6f201fb","components/forms/Segmented.jsx":"ef6e9a33fa88","components/forms/Select.jsx":"59dd659fb99a","components/forms/Slider.jsx":"87a05196d9be","components/forms/Swatch.jsx":"1523eeefe063","components/forms/TextField.jsx":"6c8e5357f4ac","components/glass/Drawer.jsx":"87db2bd506b5","components/glass/Menu.jsx":"250ebfd24c79","components/glass/WidgetCard.jsx":"f74ae6338fc7","components/icons/Icon.jsx":"14e73e693a05","components/navigation/CommandBar.jsx":"6db0bd279af0","components/navigation/Kbd.jsx":"f54e73d542e6","components/navigation/ProfilePills.jsx":"d98aa793b778","components/navigation/ResultItem.jsx":"9febc42913ae","ui_kits/photon/Shell.jsx":"b52918af41c3","ui_kits/photon/WidgetsInfo.jsx":"ae07c3349a9f","ui_kits/photon/WidgetsMedia.jsx":"74985d16d51c","ui_kits/photon/WidgetsTools.jsx":"769c601e7ebd"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PhotonDesignSystem_d1dfae = window.PhotonDesignSystem_d1dfae || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/data/MeterBar.jsx
try { (() => {
function MeterBar({
  value = 0,
  thickness = 4,
  glow = true,
  color = 'var(--accent)',
  style
}) {
  const v = Math.min(1, Math.max(0, value));
  return /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      flex: 'none',
      height: thickness,
      borderRadius: 4,
      background: 'rgb(255 255 255 / .12)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: '100%',
      borderRadius: 'inherit',
      background: color,
      boxShadow: glow ? '0 0 10px ' + color : 'none',
      transformOrigin: 'left',
      transform: 'scaleX(' + v + ')',
      transition: 'transform 400ms var(--ease-out)'
    }
  }));
}
Object.assign(__ds_scope, { MeterBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/MeterBar.jsx", error: String((e && e.message) || e) }); }

// components/data/ProgressRing.jsx
try { (() => {
const R = 44;
const C = 2 * Math.PI * R;
function ProgressRing({
  progress = 1,
  label,
  tone = 'accent',
  size = 120,
  labelSize,
  style
}) {
  const stroke = tone === 'secondary' ? 'var(--glow-secondary)' : 'var(--accent)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      width: size,
      height: size,
      flex: 'none',
      display: 'grid',
      placeItems: 'center',
      containerType: 'size',
      ...style
    }
  }, /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 100",
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      transform: 'rotate(-90deg)'
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "50",
    cy: "50",
    r: R,
    fill: "none",
    strokeWidth: "6",
    strokeLinecap: "round",
    stroke: "rgb(255 255 255 / .1)"
  }), /*#__PURE__*/React.createElement("circle", {
    cx: "50",
    cy: "50",
    r: R,
    fill: "none",
    strokeWidth: "6",
    strokeLinecap: "round",
    stroke: stroke,
    strokeDasharray: C,
    strokeDashoffset: C * (1 - progress),
    style: {
      filter: 'drop-shadow(0 0 6px color-mix(in srgb, ' + stroke + ' 60%, transparent))'
    }
  })), label != null && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'relative',
      fontSize: labelSize || 'clamp(12px, 22cqmin, 30px)',
      fontWeight: 300,
      fontVariantNumeric: 'tabular-nums'
    }
  }, label));
}
Object.assign(__ds_scope, { ProgressRing });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ProgressRing.jsx", error: String((e && e.message) || e) }); }

// components/data/RollingNumber.jsx
try { (() => {
function Digit({
  value
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      height: '1em',
      overflow: 'hidden',
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      transform: 'translateY(' + -value + 'em)',
      transition: 'transform 600ms var(--ease-spring)',
      willChange: 'transform'
    }
  }, [0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => /*#__PURE__*/React.createElement("span", {
    key: n,
    style: {
      height: '1em'
    }
  }, n))));
}

// Digits roll like a counter instead of jumping; other characters stay put.
function RollingNumber({
  value,
  style
}) {
  const chars = String(value).split('');
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-block',
      fontVariantNumeric: 'tabular-nums',
      ...style
    },
    "aria-label": String(value)
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex'
    },
    "aria-hidden": "true"
  }, chars.map((c, i) => c >= '0' && c <= '9' ? /*#__PURE__*/React.createElement(Digit, {
    key: i,
    value: Number(c)
  }) : /*#__PURE__*/React.createElement("span", {
    key: i
  }, c))));
}
Object.assign(__ds_scope, { RollingNumber });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/RollingNumber.jsx", error: String((e && e.message) || e) }); }

// components/data/WidgetLabel.jsx
try { (() => {
function WidgetLabel({
  children,
  aside,
  style
}) {
  const label = /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      color: 'var(--text-faint)',
      ...(aside ? {} : style)
    }
  }, children);
  if (!aside) return label;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      ...style
    }
  }, label, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-faint)'
    }
  }, aside));
}
Object.assign(__ds_scope, { WidgetLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/WidgetLabel.jsx", error: String((e && e.message) || e) }); }

// components/forms/Segmented.jsx
try { (() => {
const CSS = `.pt-seg{display:grid;grid-auto-flow:column;grid-auto-columns:1fr;gap:2px;min-width:0;margin:0;padding:3px;border:1px solid var(--line);border-radius:999px;background:rgb(255 255 255 / .04)}
.pt-seg label{position:relative;display:flex}
.pt-seg input{position:absolute;inset:0;width:100%;height:100%;margin:0;border-radius:999px;opacity:0;cursor:pointer}
.pt-seg span{flex:1;display:grid;place-items:center;min-height:32px;padding:4px 10px;border-radius:999px;font-family:var(--font-sans);font-size:13px;font-weight:500;line-height:1.2;text-align:center;text-wrap:balance;color:var(--text-muted)}
.pt-seg input:not(:checked):hover + span{color:var(--text);background:rgb(255 255 255 / .06)}
.pt-seg input:checked + span{background:var(--accent);color:var(--on-accent)}
.pt-seg input:focus-visible + span{outline:2px solid var(--accent);outline-offset:2px}
.pt-modes{display:inline-flex;padding:2px;border-radius:999px;background:rgb(0 0 0 / .22)}
.pt-modes button{padding:2px 9px;border:0;border-radius:999px;background:none;font-family:var(--font-sans);font-size:11px;color:var(--text-faint);cursor:pointer}
.pt-modes button:hover{color:var(--text)}
.pt-modes [aria-checked=true]{color:var(--accent);background:color-mix(in srgb,var(--accent) 16%,transparent)}
.pt-modes .pt-danger[aria-checked=true]{color:var(--danger-text-strong);background:rgb(255 77 94 / .18)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-seg-css')) {
  const s = document.createElement('style');
  s.id = 'pt-seg-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
let uid = 0;
function Segmented({
  options,
  value,
  onChange,
  label,
  name,
  size = 'md'
}) {
  const [auto] = React.useState(() => 'pt-seg-' + ++uid);
  const group = name || auto;
  if (size === 'sm') {
    return /*#__PURE__*/React.createElement("div", {
      className: "pt-modes",
      role: "radiogroup",
      "aria-label": label
    }, options.map(o => /*#__PURE__*/React.createElement("button", {
      key: o.value,
      type: "button",
      role: "radio",
      className: o.danger ? 'pt-danger' : undefined,
      "aria-checked": value === o.value,
      title: o.hint,
      onClick: () => onChange && onChange(o.value)
    }, o.label)));
  }
  return /*#__PURE__*/React.createElement("fieldset", {
    className: "pt-seg"
  }, label && /*#__PURE__*/React.createElement("legend", {
    style: {
      position: 'absolute',
      width: 1,
      height: 1,
      overflow: 'hidden',
      clipPath: 'inset(50%)'
    }
  }, label), options.map(o => /*#__PURE__*/React.createElement("label", {
    key: o.value
  }, /*#__PURE__*/React.createElement("input", {
    type: "radio",
    name: group,
    value: o.value,
    checked: value === o.value,
    onChange: () => onChange && onChange(o.value)
  }), /*#__PURE__*/React.createElement("span", null, o.label))));
}
Object.assign(__ds_scope, { Segmented });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Segmented.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
const CSS = `.pt-select{min-height:36px;padding:0 10px;border:1px solid var(--line);border-radius:12px;background:rgb(255 255 255 / .06);color:var(--text);font-family:var(--font-sans);font-size:13px;cursor:pointer}
.pt-select option{background:var(--surface-option);color:var(--text)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-select-css')) {
  const s = document.createElement('style');
  s.id = 'pt-select-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Select({
  options,
  value,
  onChange,
  label,
  hint,
  style
}) {
  const select = /*#__PURE__*/React.createElement("select", {
    className: "pt-select",
    value: value,
    onChange: e => onChange && onChange(e.currentTarget.value),
    "aria-label": label
  }, options.map(o => /*#__PURE__*/React.createElement("option", {
    key: o.value,
    value: o.value
  }, o.label)));
  if (!label) return select;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13
    }
  }, label), select, hint && /*#__PURE__*/React.createElement("small", {
    style: {
      color: 'var(--text-faint)',
      fontSize: 12
    }
  }, hint));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/forms/Slider.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `.pt-range{appearance:none;-webkit-appearance:none;flex:1;min-width:0;margin:0;cursor:pointer;background:transparent}
.pt-range.pt-thin{height:4px;border-radius:2px;background:linear-gradient(to right,var(--text) var(--fill),rgb(255 255 255 / .15) var(--fill))}
.pt-range.pt-thin::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:12px;height:12px;border-radius:50%;background:var(--text);opacity:0;transition:opacity 150ms var(--ease-out)}
.pt-range.pt-thin:hover::-webkit-slider-thumb,.pt-range.pt-thin:focus-visible::-webkit-slider-thumb{opacity:1}
.pt-range.pt-thin.pt-muted{opacity:.4}
.pt-range.pt-accent{flex:none;width:100%;height:20px}
.pt-range.pt-accent::-webkit-slider-runnable-track{height:4px;border-radius:2px;background:linear-gradient(to right,var(--accent) var(--fill),rgb(255 255 255 / .18) var(--fill))}
.pt-range.pt-accent::-webkit-slider-thumb{-webkit-appearance:none;appearance:none;width:16px;height:16px;margin-top:-6px;border:0;border-radius:50%;background:#fff;box-shadow:0 0 0 3px color-mix(in srgb,var(--accent) 40%,transparent),0 2px 6px rgb(0 0 0 / .5);transition:transform 150ms var(--ease-out)}
.pt-range.pt-accent:active::-webkit-slider-thumb{transform:scale(1.15)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-range-css')) {
  const s = document.createElement('style');
  s.id = 'pt-range-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Slider({
  value,
  min = 0,
  max = 100,
  step = 1,
  onChange,
  variant = 'thin',
  label,
  valueText,
  muted,
  style,
  ...rest
}) {
  const fill = (value - min) / (max - min || 1) * 100 + '%';
  const input = /*#__PURE__*/React.createElement("input", _extends({
    type: "range",
    className: 'pt-range pt-' + variant + (muted ? ' pt-muted' : ''),
    min: min,
    max: max,
    step: step,
    value: value,
    "aria-label": label,
    "aria-valuetext": valueText,
    style: {
      '--fill': fill,
      ...(label && variant === 'accent' ? {} : style)
    },
    onChange: e => onChange && onChange(e.currentTarget.valueAsNumber)
  }, rest));
  if (variant !== 'accent' || !label) return input;
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      ...style
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", null, label), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)',
      fontVariantNumeric: 'tabular-nums'
    },
    "aria-hidden": "true"
  }, valueText)), input);
}
Object.assign(__ds_scope, { Slider });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Slider.jsx", error: String((e && e.message) || e) }); }

// components/forms/Swatch.jsx
try { (() => {
function Swatch({
  color,
  label,
  pressed,
  onClick,
  size = 28
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": label,
    title: label,
    "aria-pressed": pressed,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: size,
      height: size,
      padding: 0,
      border: 0,
      borderRadius: '50%',
      background: color,
      cursor: 'pointer',
      boxShadow: 'inset 0 0 0 1px rgb(255 255 255 / .25)' + (pressed ? ', 0 0 0 2px var(--surface-ring), 0 0 0 4px var(--text)' : ''),
      transform: hover ? 'scale(1.12)' : 'none',
      transition: 'transform 150ms var(--ease-out)'
    }
  });
}
Object.assign(__ds_scope, { Swatch });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Swatch.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `.pt-input{box-sizing:border-box;min-height:32px;padding:0 10px;border:1px solid var(--line);border-radius:10px;background:rgb(255 255 255 / .05);color:var(--text);font-family:var(--font-sans);font-size:13px;outline:0;user-select:text}
.pt-input:focus{border-color:color-mix(in srgb,var(--accent) 50%,transparent)}
.pt-input.pt-inset{min-height:34px;border-color:var(--glass-edge);background:rgb(0 0 0 / .25)}
.pt-input.pt-inset:focus-visible{outline:2px solid var(--accent);outline-offset:0}
.pt-input::placeholder{color:var(--text-faint)}
.pt-input:disabled{opacity:.6}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-field-css')) {
  const s = document.createElement('style');
  s.id = 'pt-field-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
function TextField({
  label,
  hint,
  variant = 'default',
  style,
  inputStyle,
  ...rest
}) {
  const input = /*#__PURE__*/React.createElement("input", _extends({
    className: 'pt-input' + (variant === 'inset' ? ' pt-inset' : ''),
    style: inputStyle
  }, rest));
  if (!label && !hint) return React.cloneElement(input, {
    style: {
      ...inputStyle,
      ...style
    }
  });
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      fontSize: variant === 'inset' ? 13 : 12,
      color: variant === 'inset' ? 'var(--text)' : 'var(--text-muted)',
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", null, label), input, hint && /*#__PURE__*/React.createElement("small", {
    style: {
      fontSize: variant === 'inset' ? 11 : 12,
      color: 'var(--text-faint)'
    }
  }, hint));
}
Object.assign(__ds_scope, { TextField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/icons/Icon.jsx
try { (() => {
// Phosphor web-font wrapper. Requires <script src="https://unpkg.com/@phosphor-icons/web@2.1.1"></script> on the page.
function Icon({
  name,
  weight = 'regular',
  size = 18,
  color,
  style,
  label,
  className = ''
}) {
  const cls = weight === 'regular' ? 'ph' : 'ph-' + weight;
  return /*#__PURE__*/React.createElement("i", {
    className: cls + ' ph-' + name + (className ? ' ' + className : ''),
    "aria-hidden": label ? undefined : 'true',
    "aria-label": label,
    role: label ? 'img' : undefined,
    style: {
      fontSize: size,
      lineHeight: 1,
      display: 'inline-flex',
      flex: 'none',
      color,
      ...style
    }
  });
}
Object.assign(__ds_scope, { Icon });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/icons/Icon.jsx", error: String((e && e.message) || e) }); }

// components/actions/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `.pt-action{box-sizing:border-box;min-height:36px;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding:0 14px;border:1px solid var(--line);border-radius:999px;background:rgb(255 255 255 / .05);font-family:var(--font-sans);font-size:13px;font-weight:500;color:var(--text);cursor:pointer;white-space:nowrap;transition:transform 300ms var(--ease-spring)}
.pt-action:hover{background:rgb(255 255 255 / .09)}
.pt-action:active{transform:scale(.97);transition-duration:100ms}
.pt-action.pt-primary{border-color:transparent;background:var(--accent);color:var(--on-accent)}
.pt-action.pt-sm{min-height:30px}
.pt-action.pt-icon{width:36px;padding:0}
.pt-action.pt-icon.pt-sm{width:30px}
.pt-action:disabled{opacity:.4;cursor:default;transform:none}
.pt-ghost{box-sizing:border-box;flex:none;display:grid;place-items:center;padding:0;border:1px solid transparent;border-radius:50%;background:none;color:var(--text-muted);cursor:pointer;transition:transform 300ms var(--ease-spring)}
.pt-ghost:hover{color:var(--text);background:rgb(255 255 255 / .08)}
.pt-ghost:active{transform:scale(.9);transition-duration:100ms}
.pt-ghost.pt-square{border-radius:9px;color:var(--text)}
.pt-ghost.pt-square:hover{border-color:var(--line);background:rgb(255 255 255 / .06)}
.pt-ghost[aria-pressed=true]{color:var(--text);background:rgb(255 255 255 / .08)}
.pt-ghost:disabled{opacity:.4;cursor:default}
.pt-ghost:disabled:hover{background:none;border-color:transparent}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-action-css')) {
  const s = document.createElement('style');
  s.id = 'pt-action-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Button({
  variant = 'default',
  size = 'md',
  icon,
  iconWeight = 'bold',
  children,
  type = 'button',
  ...rest
}) {
  const cls = 'pt-action' + (variant === 'primary' ? ' pt-primary' : '') + (size === 'sm' ? ' pt-sm' : '');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cls
  }, rest), typeof icon === 'string' ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    weight: iconWeight,
    size: 16
  }) : icon, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Button.jsx", error: String((e && e.message) || e) }); }

// components/actions/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const CSS = `.pt-chip{box-sizing:border-box;display:inline-flex;align-items:center;gap:5px;border:1px solid var(--line);border-radius:999px;font-family:var(--font-sans);white-space:nowrap;cursor:pointer;transition:transform 300ms var(--ease-spring)}
.pt-chip.pt-s{min-height:26px;padding:0 10px;font-size:12px;background:rgb(255 255 255 / .04);color:var(--text-muted)}
.pt-chip.pt-m{height:30px;padding:0 12px;gap:6px;font-size:13px;background:rgb(255 255 255 / .05);color:var(--text)}
.pt-chip:not(:disabled):hover{color:var(--text);background:rgb(255 255 255 / .08)}
.pt-chip:not(:disabled):active{transform:scale(.95);transition-duration:100ms}
.pt-chip.pt-danger{border-color:transparent;background:var(--danger);color:#fff}
.pt-chip.pt-danger:hover{background:var(--danger)}
.pt-chip.pt-accent{border-color:transparent;background:var(--accent);color:var(--on-accent)}
.pt-chip.pt-accent:hover{background:var(--accent);color:var(--on-accent)}
.pt-chip.pt-dashed{color:var(--text-muted);background:none}
.pt-chip:disabled{opacity:.4;cursor:default}
.pt-file{max-width:180px;display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:999px;background:color-mix(in srgb,var(--accent) 16%,transparent);font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pt-file button{display:grid;padding:0;border:0;background:none;color:inherit;cursor:pointer}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-chip-css')) {
  const s = document.createElement('style');
  s.id = 'pt-chip-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Chip({
  children,
  icon,
  size = 'sm',
  variant = 'default',
  type = 'button',
  ...rest
}) {
  const cls = 'pt-chip ' + (size === 'md' ? 'pt-m' : 'pt-s') + (variant !== 'default' ? ' pt-' + variant : '');
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cls
  }, rest), typeof icon === 'string' ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    size: 14,
    weight: size === 'md' ? 'duotone' : 'regular'
  }) : icon, children);
}

// Attached-file token (accent 16 % fill, 11px).
function FileChip({
  name,
  title,
  onRemove
}) {
  return /*#__PURE__*/React.createElement("span", {
    className: "pt-file",
    title: title || name
  }, name, onRemove && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": 'Retirer ' + name,
    onClick: onRemove
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    size: 11
  })));
}
Object.assign(__ds_scope, { Chip, FileChip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/Chip.jsx", error: String((e && e.message) || e) }); }

// components/actions/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIZES = {
  action: {
    md: 36,
    sm: 30
  },
  ghost: {
    md: 32,
    sm: 30
  },
  square: {
    md: 30,
    sm: 26
  }
};
function IconButton({
  icon,
  label,
  variant = 'action',
  size = 'md',
  iconSize,
  iconWeight = 'duotone',
  pressed,
  type = 'button',
  style,
  ...rest
}) {
  const px = SIZES[variant][size];
  const cls = variant === 'action' ? 'pt-action pt-icon' + (size === 'sm' ? ' pt-sm' : '') : 'pt-ghost' + (variant === 'square' ? ' pt-square' : '');
  const glyph = iconSize || (variant === 'action' ? size === 'sm' ? 14 : 18 : 16);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: type,
    className: cls,
    "aria-label": label,
    title: label,
    "aria-pressed": pressed,
    style: variant === 'action' ? style : {
      width: px,
      height: px,
      ...style
    }
  }, rest), typeof icon === 'string' ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    weight: iconWeight,
    size: glyph
  }) : icon);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/actions/PlayButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
// Solid light disc with dark glyph — the one high-contrast control inside widgets (pomodoro, music).
function PlayButton({
  playing = false,
  size = 40,
  overlay = false,
  onClick,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    className: "pt-ghost",
    "aria-label": playing ? 'Pause' : 'Lecture',
    onClick: onClick,
    style: {
      width: size,
      height: size,
      border: 0,
      background: overlay ? 'rgb(0 0 0 / .45)' : 'var(--text)',
      color: overlay ? '#fff' : 'var(--bg)'
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: playing ? 'pause' : 'play',
    weight: "fill",
    size: size >= 40 ? 20 : 18
  }));
}
Object.assign(__ds_scope, { PlayButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/actions/PlayButton.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Approval.jsx
try { (() => {
function Approval({
  title,
  detail,
  children,
  tone = 'accent',
  acceptLabel = 'Autoriser',
  refuseLabel = 'Refuser',
  onAccept,
  onRefuse,
  style
}) {
  const danger = tone === 'danger';
  return /*#__PURE__*/React.createElement("div", {
    role: "alertdialog",
    "aria-label": title,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      padding: '10px 12px',
      borderRadius: 14,
      fontSize: 12,
      fontFamily: 'var(--font-sans)',
      color: 'var(--text)',
      border: '1px solid ' + (danger ? 'rgb(255 77 94 / .45)' : 'color-mix(in srgb, var(--accent) 45%, transparent)'),
      background: danger ? 'rgb(255 77 94 / .1)' : 'color-mix(in srgb, var(--accent) 8%, transparent)',
      ...style
    }
  }, title && !danger && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontWeight: 600
    }
  }, title), children && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, children), detail && /*#__PURE__*/React.createElement("pre", {
    style: {
      maxHeight: '8lh',
      margin: 0,
      padding: 8,
      overflow: 'auto',
      borderRadius: 8,
      background: 'rgb(0 0 0 / .3)',
      fontFamily: 'inherit',
      fontSize: 11,
      lineHeight: 1.45,
      whiteSpace: 'pre-wrap',
      overflowWrap: 'anywhere'
    }
  }, detail), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Chip, {
    onClick: onRefuse,
    style: {
      paddingInline: 12
    }
  }, refuseLabel), /*#__PURE__*/React.createElement(__ds_scope.Chip, {
    variant: danger ? 'danger' : 'accent',
    onClick: onAccept,
    style: {
      paddingInline: 12
    }
  }, acceptLabel)));
}
Object.assign(__ds_scope, { Approval });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Approval.jsx", error: String((e && e.message) || e) }); }

// components/forms/Checkbox.jsx
try { (() => {
function Checkbox({
  checked,
  onChange,
  label,
  hint,
  disabled,
  variant = 'native',
  style
}) {
  if (variant === 'task') {
    return /*#__PURE__*/React.createElement("button", {
      type: "button",
      role: "checkbox",
      "aria-checked": !!checked,
      "aria-label": label,
      onClick: () => onChange && onChange(!checked),
      style: {
        flex: 'none',
        width: 18,
        height: 18,
        display: 'grid',
        placeItems: 'center',
        padding: 0,
        cursor: 'pointer',
        boxSizing: 'border-box',
        border: '1.5px solid ' + (checked ? 'var(--accent)' : 'var(--text-faint)'),
        borderRadius: 6,
        background: checked ? 'var(--accent)' : 'none',
        color: 'var(--on-accent)',
        ...style
      }
    }, checked && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
      name: "check",
      weight: "bold",
      size: 12
    }));
  }
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'grid',
      gridTemplateColumns: '18px 1fr',
      alignItems: 'center',
      gap: '2px 10px',
      fontSize: 13,
      cursor: disabled ? 'default' : 'pointer',
      opacity: disabled ? 0.6 : 1,
      ...style
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: !!checked,
    disabled: disabled,
    onChange: e => onChange && onChange(e.currentTarget.checked),
    style: {
      margin: 0,
      accentColor: 'var(--accent)',
      cursor: 'inherit'
    }
  }), /*#__PURE__*/React.createElement("span", null, label), hint && /*#__PURE__*/React.createElement("small", {
    style: {
      gridColumn: 2,
      color: 'var(--text-faint)',
      fontSize: 12
    }
  }, hint));
}
Object.assign(__ds_scope, { Checkbox });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Checkbox.jsx", error: String((e && e.message) || e) }); }

// components/glass/Drawer.jsx
try { (() => {
function Drawer({
  title,
  onClose,
  children,
  style
}) {
  return /*#__PURE__*/React.createElement("div", {
    role: "dialog",
    "aria-label": title,
    style: {
      boxSizing: 'border-box',
      width: 'min(360px, calc(100% - 24px))',
      padding: 20,
      overflowY: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 24,
      border: '1px solid var(--glass-edge)',
      borderRadius: 'var(--radius-panel)',
      background: 'var(--glass-sheen), rgb(14 16 22 / .6)',
      backdropFilter: 'blur(30px) saturate(1.7)',
      WebkitBackdropFilter: 'blur(30px) saturate(1.7)',
      boxShadow: 'var(--glass-rim), 0 24px 60px -20px rgb(0 0 0 / .7)',
      color: 'var(--text)',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("h2", {
    style: {
      margin: 0,
      fontSize: 18,
      fontWeight: 600,
      letterSpacing: '-0.01em'
    }
  }, title), onClose && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "x",
    iconWeight: "bold",
    label: "Fermer",
    onClick: onClose
  })), children);
}
function DrawerSection({
  title,
  children
}) {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 12,
      fontWeight: 600,
      textTransform: 'uppercase',
      letterSpacing: '0.1em',
      color: 'var(--text-faint)'
    }
  }, title), children);
}
Object.assign(__ds_scope, { Drawer, DrawerSection });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glass/Drawer.jsx", error: String((e && e.message) || e) }); }

// components/glass/Menu.jsx
try { (() => {
const CSS = `.pt-menu{min-width:200px;margin:0;padding:6px;list-style:none;border-radius:14px;background:var(--glass-sheen),rgb(20 22 29 / .6);backdrop-filter:blur(24px) saturate(1.7);-webkit-backdrop-filter:blur(24px) saturate(1.7);border:1px solid var(--glass-edge);box-shadow:var(--glass-rim),0 16px 40px -16px rgb(0 0 0 / .6);font-family:var(--font-sans);color:var(--text);box-sizing:border-box}
.pt-menu button{width:100%;min-height:40px;display:flex;align-items:center;gap:10px;padding:0 12px;border:0;border-radius:10px;background:transparent;font-size:14px;color:var(--text);text-align:left;cursor:pointer}
.pt-menu button:hover,.pt-menu button:focus-visible{background:rgb(255 255 255 / .06)}
.pt-menu .pt-menu-label{padding:8px 12px 4px;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--text-faint)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-menu-css')) {
  const s = document.createElement('style');
  s.id = 'pt-menu-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
function Menu({
  children,
  style,
  label
}) {
  return /*#__PURE__*/React.createElement("ul", {
    className: "pt-menu",
    role: "menu",
    "aria-label": label,
    style: style
  }, children);
}
function MenuItem({
  children,
  icon,
  onClick
}) {
  return /*#__PURE__*/React.createElement("li", {
    role: "none"
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    role: "menuitem",
    onClick: onClick
  }, typeof icon === 'string' ? /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: icon,
    weight: "duotone",
    size: 20,
    color: "var(--accent)"
  }) : icon, children));
}
function MenuLabel({
  children
}) {
  return /*#__PURE__*/React.createElement("li", {
    role: "separator",
    className: "pt-menu-label"
  }, children);
}
Object.assign(__ds_scope, { Menu, MenuItem, MenuLabel });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glass/Menu.jsx", error: String((e && e.message) || e) }); }

// components/glass/WidgetCard.jsx
try { (() => {
const CSS = `.pt-card{position:relative;box-sizing:border-box;height:100%;border-radius:var(--radius);background:var(--glass-sheen);border:1px solid var(--glass-edge);box-shadow:var(--glass-rim),0 10px 30px -14px rgb(0 0 0 / .55);transition:transform 450ms var(--ease-spring);color:var(--text);font-family:var(--font-sans)}
.pt-card::before{content:'';position:absolute;inset:-1px;border-radius:inherit;border:1px solid color-mix(in srgb,var(--accent) 55%,transparent);box-shadow:0 0 40px -12px var(--accent);opacity:0;transition:opacity 200ms var(--ease-out);pointer-events:none}
.pt-card:hover{transform:translateY(-2px)}
.pt-card:hover::before,.pt-card:hover .pt-ring{opacity:1}
.pt-card:active:not(.pt-nopress){transform:translateY(-1px) scale(.97);transition-duration:120ms;transition-timing-function:var(--ease-out)}
.pt-card.pt-editing{cursor:grab;transform:none}
.pt-ring{position:absolute;inset:-1px;padding:1px;border-radius:inherit;overflow:hidden;-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask:linear-gradient(#000 0 0) content-box exclude,linear-gradient(#000 0 0);opacity:0;transition:opacity 200ms var(--ease-out);pointer-events:none}
.pt-spot{position:absolute;left:-110px;top:-110px;width:220px;height:220px;border-radius:50%;background:radial-gradient(circle,var(--accent),transparent 70%);will-change:transform}
.pt-card-content{height:100%;container-type:size;overflow:hidden;border-radius:inherit}
.pt-remove{position:absolute;top:-8px;right:-8px;width:28px;height:28px;display:grid;place-items:center;padding:0;border:1px solid var(--line);border-radius:50%;background:var(--surface-chip);color:var(--text);cursor:pointer;z-index:2}
.pt-remove:hover{background:var(--surface-chip-danger);color:var(--danger-text)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-card-css')) {
  const s = document.createElement('style');
  s.id = 'pt-card-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
function WidgetCard({
  children,
  label,
  editing = false,
  noPress = false,
  failed = false,
  onRetry,
  onRemove,
  style,
  className = ''
}) {
  const [spot, setSpot] = React.useState({
    x: 0,
    y: 0
  });
  const track = e => {
    const box = e.currentTarget.getBoundingClientRect();
    setSpot({
      x: e.clientX - box.left,
      y: e.clientY - box.top
    });
  };
  return /*#__PURE__*/React.createElement("article", {
    className: 'pt-card' + (editing ? ' pt-editing' : '') + (noPress ? ' pt-nopress' : '') + (className ? ' ' + className : ''),
    "aria-label": label,
    onPointerMove: track,
    style: style
  }, /*#__PURE__*/React.createElement("span", {
    className: "pt-ring",
    "aria-hidden": "true"
  }, /*#__PURE__*/React.createElement("span", {
    className: "pt-spot",
    style: {
      transform: 'translate(' + spot.x + 'px, ' + spot.y + 'px)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    className: "pt-card-content"
  }, failed ? /*#__PURE__*/React.createElement("div", {
    role: "alert",
    style: {
      height: '100%',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 10,
      padding: 16,
      boxSizing: 'border-box',
      textAlign: 'center',
      color: 'var(--text-muted)',
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0
    }
  }, "Ce widget a rencontr\xE9 un probl\xE8me."), /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: "pt-action",
    onClick: onRetry
  }, "R\xE9essayer")) : children), editing && onRemove && /*#__PURE__*/React.createElement("button", {
    className: "pt-remove",
    type: "button",
    "aria-label": 'Supprimer ' + (label || ''),
    onClick: onRemove
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "x",
    weight: "bold",
    size: 14
  })));
}
Object.assign(__ds_scope, { WidgetCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/glass/WidgetCard.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Kbd.jsx
try { (() => {
function Kbd({
  children
}) {
  return /*#__PURE__*/React.createElement("kbd", {
    style: {
      flex: 'none',
      padding: '2px 7px',
      border: '1px solid var(--line)',
      borderRadius: 6,
      fontFamily: 'var(--font-sans)',
      fontSize: 11,
      color: 'var(--text-faint)'
    }
  }, children);
}
Object.assign(__ds_scope, { Kbd });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Kbd.jsx", error: String((e && e.message) || e) }); }

// components/navigation/ProfilePills.jsx
try { (() => {
const CSS = `.pt-pill{flex:none;display:inline-flex;align-items:center;gap:5px;height:30px;padding:0 12px;border:1px solid transparent;border-radius:999px;background:none;color:var(--text-muted);font-family:var(--font-sans);font-size:13px;white-space:nowrap;cursor:pointer;transition:transform 300ms var(--ease-spring);box-sizing:border-box}
.pt-pill:hover{color:var(--text);background:rgb(255 255 255 / .06)}
.pt-pill:active{transform:scale(.96);transition-duration:100ms}
.pt-pill.pt-active{border-color:color-mix(in srgb,var(--accent) 45%,transparent);background:color-mix(in srgb,var(--accent) 16%,transparent);color:var(--text)}`;
if (typeof document !== 'undefined' && !document.getElementById('pt-pill-css')) {
  const s = document.createElement('style');
  s.id = 'pt-pill-css';
  s.textContent = CSS;
  document.head.appendChild(s);
}
function ProfilePill({
  name,
  active,
  focus,
  title,
  onClick
}) {
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    className: 'pt-pill' + (active ? ' pt-active' : ''),
    "aria-pressed": !!active,
    title: title,
    onClick: onClick
  }, focus && /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "moon",
    weight: "fill",
    size: 12,
    label: "Focus"
  }), name);
}
function ProfilePills({
  profiles = [],
  active,
  onSelect,
  onAdd
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "group",
    "aria-label": "Profils",
    style: {
      minWidth: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      overflowX: 'auto',
      scrollbarWidth: 'none'
    }
  }, profiles.map((p, i) => /*#__PURE__*/React.createElement(ProfilePill, {
    key: p.id,
    name: p.name,
    focus: p.focus,
    active: p.id === active,
    title: i < 9 ? 'Ctrl+' + (i + 1) : undefined,
    onClick: () => onSelect && onSelect(p.id)
  }))), onAdd !== null && /*#__PURE__*/React.createElement(__ds_scope.IconButton, {
    icon: "plus",
    iconWeight: "bold",
    size: "sm",
    label: "Nouveau profil",
    onClick: onAdd
  }));
}
Object.assign(__ds_scope, { ProfilePill, ProfilePills });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/ProfilePills.jsx", error: String((e && e.message) || e) }); }

// components/navigation/ResultItem.jsx
try { (() => {
const ICONS = {
  app: 'app-window',
  file: 'file',
  folder: 'folder',
  site: 'globe',
  web: 'magnifying-glass',
  calc: 'calculator',
  command: 'command',
  action: 'sliders-horizontal',
  claude: 'sparkle'
};
function ResultIcon({
  kind = 'app',
  src
}) {
  const claude = kind === 'claude';
  return /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      flex: 'none',
      width: 32,
      height: 32,
      display: 'grid',
      placeItems: 'center',
      borderRadius: 9,
      background: claude ? 'color-mix(in srgb, var(--accent) 14%, transparent)' : 'rgb(255 255 255 / .06)',
      color: claude ? 'var(--accent)' : 'var(--text-muted)'
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: "",
    width: "24",
    height: "24"
  }) : /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: ICONS[kind] || 'app-window',
    weight: "duotone",
    size: 20
  }));
}
function ResultItem({
  kind,
  title,
  subtitle,
  selected,
  warn,
  kbd,
  iconSrc,
  onClick,
  onPointerMove,
  id
}) {
  return /*#__PURE__*/React.createElement("li", {
    id: id,
    role: "option",
    "aria-selected": !!selected,
    onClick: onClick,
    onPointerMove: onPointerMove,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      padding: '7px 10px',
      borderRadius: 12,
      cursor: 'pointer',
      background: selected ? 'rgb(255 255 255 / .08)' : 'transparent',
      listStyle: 'none'
    }
  }, /*#__PURE__*/React.createElement(ResultIcon, {
    kind: kind,
    src: iconSrc
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: warn ? 'var(--danger-text)' : 'var(--text-faint)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, warn ? 'Entrée encore une fois pour confirmer' : subtitle)), selected && /*#__PURE__*/React.createElement(__ds_scope.Kbd, null, kbd || (kind === 'claude' ? 'Tab' : 'Entrée')));
}
Object.assign(__ds_scope, { ResultIcon, ResultItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/ResultItem.jsx", error: String((e && e.message) || e) }); }

// components/navigation/CommandBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
function CommandBar({
  value = '',
  onChange,
  placeholder = 'Rechercher, calculer, demander à Claude…',
  results = [],
  selected = 0,
  onSelect,
  onHover,
  mini = false,
  notice,
  open,
  style
}) {
  const [focus, setFocus] = React.useState(false);
  const show = open != null ? open : results.length > 0 && (mini || value.trim() !== '');
  const list = show && /*#__PURE__*/React.createElement("ul", {
    role: "listbox",
    "aria-label": "R\xE9sultats",
    style: mini ? {
      margin: '8px 0 0',
      padding: 0
    } : {
      position: 'absolute',
      top: 'calc(100% + 8px)',
      left: 0,
      right: 0,
      zIndex: 30,
      margin: 0,
      padding: 6,
      border: '1px solid var(--glass-edge)',
      borderRadius: 18,
      background: 'var(--glass-sheen), rgb(16 18 24 / .86)',
      backdropFilter: 'var(--glass-filter)',
      WebkitBackdropFilter: 'var(--glass-filter)',
      boxShadow: 'var(--glass-rim), 0 24px 60px -20px rgb(0 0 0 / .7)'
    }
  }, results.map((r, i) => /*#__PURE__*/React.createElement(__ds_scope.ResultItem, _extends({
    key: r.id || i
  }, r, {
    selected: i === selected,
    onClick: () => onSelect && onSelect(r, i),
    onPointerMove: () => onHover && onHover(i)
  }))));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      minWidth: 0,
      maxWidth: mini ? 'none' : 560,
      margin: '0 auto',
      padding: mini ? 12 : 0,
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: mini ? 44 : 38,
      padding: '0 14px',
      boxSizing: 'border-box',
      borderRadius: mini ? 14 : 999,
      background: 'rgb(0 0 0 / .2)',
      color: 'var(--text-faint)',
      border: '1px solid ' + (focus ? 'color-mix(in srgb, var(--accent) 50%, transparent)' : 'var(--line)')
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Icon, {
    name: "magnifying-glass",
    size: 18
  }), /*#__PURE__*/React.createElement("input", {
    value: value,
    onChange: e => onChange && onChange(e.currentTarget.value),
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    type: "text",
    spellCheck: "false",
    autoComplete: "off",
    placeholder: placeholder,
    "aria-label": "Barre de commande",
    role: "combobox",
    "aria-expanded": !!show,
    style: {
      flex: 1,
      minWidth: 0,
      border: 0,
      outline: 0,
      background: 'none',
      color: 'var(--text)',
      fontFamily: 'inherit',
      fontSize: mini ? 16 : 14
    }
  }), notice && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12
    }
  }, notice)), list);
}
Object.assign(__ds_scope, { CommandBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/CommandBar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/photon/Shell.jsx
try { (() => {
// Photon shell: backdrop, glass panel, header (name, profiles, command bar, actions), grid, settings drawer.
const {
  ProfilePill,
  IconButton,
  Button,
  Menu,
  MenuItem,
  MenuLabel,
  CommandBar,
  WidgetCard,
  Drawer,
  DrawerSection,
  Segmented,
  Slider,
  Swatch,
  Checkbox,
  Select,
  Icon
} = window.PhotonDesignSystem_d1dfae;
const WIDGETS = {
  clock: {
    name: 'Horloge',
    icon: 'clock',
    size: [6, 2],
    C: window.ClockWidget
  },
  system: {
    name: 'Système',
    icon: 'cpu',
    size: [3, 2],
    C: window.SystemWidget
  },
  disks: {
    name: 'Disques',
    icon: 'hard-drives',
    size: [3, 2],
    C: window.DisksWidget
  },
  launcher: {
    name: 'Lanceur',
    icon: 'rocket-launch',
    size: [6, 2],
    C: window.LauncherWidget
  },
  weather: {
    name: 'Météo',
    icon: 'cloud-sun',
    size: [3, 2],
    C: window.WeatherWidget
  },
  network: {
    name: 'Réseau',
    icon: 'wifi-high',
    size: [3, 2],
    C: window.NetworkWidget
  },
  calendar: {
    name: 'Agenda',
    icon: 'calendar-dots',
    size: [4, 3],
    C: window.CalendarWidget
  },
  claude: {
    name: 'Claude',
    icon: 'sparkle',
    size: [5, 5],
    C: window.ClaudeWidget,
    noPress: true
  },
  folders: {
    name: 'Dossiers',
    icon: 'folder-open',
    size: [4, 3],
    C: window.FoldersWidget
  },
  notes: {
    name: 'Notes',
    icon: 'note',
    size: [3, 3],
    C: window.NotesWidget,
    noPress: true
  },
  pomodoro: {
    name: 'Pomodoro',
    icon: 'timer',
    size: [3, 2],
    C: window.PomodoroWidget
  },
  todo: {
    name: 'To-do',
    icon: 'list-checks',
    size: [3, 3],
    C: window.TodoWidget,
    noPress: true
  },
  volume: {
    name: 'Son',
    icon: 'speaker-high',
    size: [3, 3],
    C: window.VolumeWidget,
    noPress: true
  },
  ytmusic: {
    name: 'YT Music',
    icon: 'music-notes',
    size: [4, 2],
    C: window.MusicWidget,
    noPress: true
  }
};
const slots = list => list.map(([type, x, y, w, h]) => ({
  id: type,
  type,
  x,
  y,
  w,
  h,
  settings: {}
}));
const INITIAL_PROFILES = [{
  id: 'default',
  name: 'Principal',
  focus: false,
  widgets: slots([['clock', 0, 0, 6, 2], ['system', 6, 0, 3, 2], ['disks', 9, 0, 3, 2], ['launcher', 0, 2, 12, 2]])
}, {
  id: 'work',
  name: 'Travail',
  focus: false,
  widgets: slots([['clock', 0, 0, 8, 2], ['system', 8, 0, 4, 2], ['calendar', 0, 2, 5, 4], ['claude', 5, 2, 7, 4]])
}, {
  id: 'focus',
  name: 'Focus',
  focus: true,
  widgets: slots([['clock', 0, 0, 8, 2], ['pomodoro', 8, 0, 4, 2], ['todo', 0, 2, 6, 4], ['notes', 6, 2, 6, 4]])
}, {
  id: 'chill',
  name: 'Chill',
  focus: false,
  widgets: slots([['ytmusic', 0, 0, 6, 2], ['clock', 6, 0, 6, 2], ['launcher', 0, 2, 12, 2]])
}, {
  id: 'home',
  name: 'Maison',
  focus: false,
  widgets: slots([['weather', 0, 0, 5, 2], ['network', 5, 0, 4, 2], ['volume', 9, 0, 3, 4], ['folders', 0, 2, 9, 2]])
}];
const APPS = ['Spotify', 'Steam', 'Discord', 'Firefox', 'Visual Studio Code', 'OBS Studio', 'Paramètres', 'Explorateur de fichiers', 'Terminal'];
function search(q, profiles) {
  const t = q.trim().toLowerCase();
  if (!t) return [];
  const out = [];
  if (/^[\d\s+\-*/().,]+$/.test(t) && /\d/.test(t)) {
    try {
      const v = Function('return (' + t.replace(/,/g, '.') + ')')();
      if (Number.isFinite(v)) out.push({
        id: 'calc',
        kind: 'calc',
        title: '= ' + String(Math.round(v * 1000) / 1000).replace('.', ','),
        subtitle: 'Calcul · Entrée pour copier'
      });
    } catch (e) {}
  }
  APPS.filter(a => a.toLowerCase().includes(t)).slice(0, 4).forEach(a => out.push({
    id: 'app:' + a,
    kind: 'app',
    title: a,
    subtitle: 'Application'
  }));
  if ('modifier la grille'.includes(t)) out.push({
    id: 'ui:edit',
    kind: 'action',
    title: 'Modifier la grille',
    subtitle: 'Photon'
  });
  if ('réglages'.includes(t)) out.push({
    id: 'ui:settings',
    kind: 'action',
    title: 'Réglages',
    subtitle: 'Photon'
  });
  profiles.filter(p => p.name.toLowerCase().includes(t)).forEach(p => out.push({
    id: 'ui:profile:' + p.id,
    kind: 'action',
    title: 'Profil « ' + p.name + ' »',
    subtitle: 'Basculer de profil'
  }));
  if ('éteindre'.includes(t) || 'redémarrer'.includes(t)) out.push({
    id: 'cmd:off',
    kind: 'command',
    title: 'Éteindre',
    subtitle: 'Commande système',
    confirm: true
  });
  out.push({
    id: 'web',
    kind: 'web',
    title: 'Rechercher « ' + q.trim() + ' »',
    subtitle: 'Sur le web'
  });
  out.push({
    id: 'claude',
    kind: 'claude',
    title: 'Demander à Claude',
    subtitle: '« ' + q.trim() + ' »'
  });
  return out;
}
function onAccent(hex) {
  const [r, g, b] = [1, 3, 5].map(i => {
    const v = parseInt(hex.slice(i, i + 2), 16) / 255;
    return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4;
  });
  return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.18 ? '#07080b' : '#ffffff';
}
function Header({
  profiles,
  active,
  setActive,
  editing,
  setEditing,
  settingsOpen,
  setSettingsOpen,
  onAdd,
  renameActive,
  toggleFocus,
  fullscreen
}) {
  const [query, setQuery] = React.useState('');
  const [sel, setSel] = React.useState(0);
  const [confirmId, setConfirmId] = React.useState('');
  const [addOpen, setAddOpen] = React.useState(false);
  const results = search(query, profiles).map(r => ({
    ...r,
    warn: r.id === confirmId
  }));
  const run = r => {
    if (!r) return;
    if (r.confirm && confirmId !== r.id) {
      setConfirmId(r.id);
      return;
    }
    if (r.id === 'ui:edit') {
      setEditing(true);
      setSettingsOpen(false);
    } else if (r.id === 'ui:settings') setSettingsOpen(true);else if (r.id.startsWith('ui:profile:')) setActive(r.id.slice(11));
    setQuery('');
    setConfirmId('');
  };
  const onKey = e => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      if (results.length) setSel((sel + (e.key === 'ArrowDown' ? 1 : results.length - 1)) % results.length);
      setConfirmId('');
    } else if (e.key === 'Enter') {
      e.preventDefault();
      run(results[sel]);
    } else if (e.key === 'Escape') {
      setQuery('');
    }
  };
  const activeProfile = profiles.find(p => p.id === active);
  return /*#__PURE__*/React.createElement("header", {
    "data-reveal": true,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      minHeight: 36,
      position: 'relative',
      zIndex: 20
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18,
      fontWeight: 600,
      letterSpacing: '-0.01em'
    }
  }, "Photon"), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    role: "group",
    "aria-label": "Profils",
    style: {
      minWidth: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 4,
      overflowX: 'auto',
      scrollbarWidth: 'none'
    }
  }, profiles.map((p, i) => editing && p.id === active ? /*#__PURE__*/React.createElement(React.Fragment, {
    key: p.id
  }, /*#__PURE__*/React.createElement("input", {
    value: p.name,
    onChange: e => renameActive(e.currentTarget.value),
    size: Math.max(p.name.length, 4),
    "aria-label": "Nom du profil",
    spellCheck: "false",
    style: {
      flex: 'none',
      height: 30,
      padding: '0 12px',
      boxSizing: 'border-box',
      border: '1px solid var(--accent)',
      borderRadius: 999,
      background: 'color-mix(in srgb, var(--accent) 16%, transparent)',
      color: 'var(--text)',
      fontFamily: 'inherit',
      fontSize: 13,
      outline: 0
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-pressed": p.focus,
    onClick: toggleFocus,
    title: "Profil Focus : \xAB Ne pas d\xE9ranger \xBB de Windows et pomodoro lanc\xE9 \xE0 l'activation",
    style: {
      flex: 'none',
      height: 30,
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '0 8px',
      border: 0,
      borderRadius: 999,
      background: p.focus ? 'rgb(255 255 255 / .08)' : 'none',
      color: p.focus ? 'var(--text)' : 'var(--text-faint)',
      fontFamily: 'inherit',
      fontSize: 12,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "moon",
    weight: p.focus ? 'fill' : 'regular',
    size: 15
  }), "Focus")) : /*#__PURE__*/React.createElement(ProfilePill, {
    key: p.id,
    name: p.name,
    focus: p.focus,
    active: p.id === active,
    title: i < 9 ? 'Ctrl+' + (i + 1) : undefined,
    onClick: () => setActive(p.id)
  }))), /*#__PURE__*/React.createElement(IconButton, {
    icon: "plus",
    iconWeight: "bold",
    size: "sm",
    label: "Nouveau profil",
    onClick: onAdd
  })), /*#__PURE__*/React.createElement("div", {
    onKeyDown: onKey,
    style: {
      flex: 1,
      minWidth: 0,
      display: 'flex'
    }
  }, /*#__PURE__*/React.createElement(CommandBar, {
    value: query,
    onChange: v => {
      setQuery(v);
      setSel(0);
      setConfirmId('');
    },
    results: results,
    selected: sel,
    onHover: setSel,
    onSelect: r => run(r)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, editing ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    icon: "plus",
    "aria-haspopup": "menu",
    "aria-expanded": addOpen,
    onClick: () => setAddOpen(!addOpen)
  }, "Ajouter"), addOpen && /*#__PURE__*/React.createElement(Menu, {
    style: {
      position: 'absolute',
      right: 0,
      top: 'calc(100% + 8px)',
      zIndex: 10,
      maxHeight: 420,
      overflowY: 'auto'
    }
  }, Object.entries(WIDGETS).map(([type, m]) => /*#__PURE__*/React.createElement(MenuItem, {
    key: type,
    icon: m.icon,
    onClick: () => {
      onAdd(type);
      setAddOpen(false);
    }
  }, m.name)))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    icon: "check",
    onClick: () => {
      setEditing(false);
      setAddOpen(false);
    }
  }, "Termin\xE9")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
    icon: "pencil-simple",
    label: "Modifier la grille",
    onClick: () => {
      setSettingsOpen(false);
      setEditing(true);
    }
  }), /*#__PURE__*/React.createElement(IconButton, {
    icon: "gear-six",
    label: "R\xE9glages",
    "aria-expanded": settingsOpen,
    onClick: () => setSettingsOpen(!settingsOpen)
  }))));
}
function Grid({
  profile,
  editing,
  density,
  onRemove,
  onSave
}) {
  const cell = density === 'compact' ? 80 : 100;
  const gap = density === 'compact' ? 12 : 20;
  if (!profile.widgets.length) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '48px 24px',
        textAlign: 'center',
        color: 'var(--text-muted)'
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0
      }
    }, "Aucun widget pour l'instant."), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: '6px 0 0',
        fontSize: 13,
        color: 'var(--text-faint)'
      }
    }, "Clique sur le crayon en haut \xE0 droite, puis sur \xAB Ajouter \xBB."));
  }
  return /*#__PURE__*/React.createElement("div", {
    key: profile.id,
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(12, minmax(0, 1fr))',
      gridAutoRows: cell,
      gap,
      animation: 'pt-fade 220ms var(--ease-out)'
    }
  }, profile.widgets.map(w => {
    const m = WIDGETS[w.type];
    const C = m.C;
    return /*#__PURE__*/React.createElement("div", {
      key: w.id,
      style: {
        gridColumn: `${w.x + 1} / span ${w.w}`,
        gridRow: `${w.y + 1} / span ${w.h}`,
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement(WidgetCard, {
      label: m.name,
      editing: editing,
      noPress: m.noPress,
      onRemove: () => onRemove(w.id)
    }, /*#__PURE__*/React.createElement(C, {
      editing: editing,
      w: w.w,
      h: w.h,
      settings: w.settings,
      save: s => onSave(w.id, s)
    })), editing && /*#__PURE__*/React.createElement("span", {
      "aria-hidden": "true",
      style: {
        position: 'absolute',
        right: 0,
        bottom: 0,
        width: 18,
        height: 18,
        borderRight: '2px solid var(--accent)',
        borderBottom: '2px solid var(--accent)',
        borderBottomRightRadius: 'var(--radius)',
        opacity: 0.8
      }
    }));
  }));
}
function SettingsPanel({
  theme,
  setTheme,
  settings,
  setSettings,
  onClose
}) {
  const [tab, setTab] = React.useState(theme.background);
  const set = p => setTheme({
    ...theme,
    ...p
  });
  const SW = [['Bleu', '#7CC4FF'], ['Violet', '#B69CFF'], ['Orange', '#FFB86B'], ['Menthe', '#6EF2C2']];
  const color = (label, value, onChange) => /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 13,
      color: 'var(--text-muted)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "color",
    value: value,
    onChange: e => onChange(e.currentTarget.value),
    style: {
      width: 28,
      height: 28,
      padding: 0,
      border: 0,
      borderRadius: '50%',
      background: 'none',
      cursor: 'pointer'
    }
  }), label);
  return /*#__PURE__*/React.createElement(Drawer, {
    title: "R\xE9glages",
    onClose: onClose,
    style: {
      position: 'absolute',
      top: 12,
      right: 12,
      bottom: 12,
      zIndex: 40,
      animation: 'pt-open 180ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Fond"
  }, /*#__PURE__*/React.createElement(Segmented, {
    label: "Type de fond",
    value: tab,
    onChange: v => {
      setTab(v);
      if (v !== 'image') set({
        background: v
      });
    },
    options: [{
      value: 'wallpaper',
      label: "Fond d'écran"
    }, {
      value: 'image',
      label: 'Image'
    }, {
      value: 'gradient',
      label: 'Dégradé'
    }]
  }), tab === 'image' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Button, null, "Choisir une image\u2026")), tab === 'gradient' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '12px 16px'
    }
  }, color('Début', theme.from, from => set({
    from
  })), color('Fin', theme.to, to => set({
    to
  })))), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Couleur d'accent"
  }, /*#__PURE__*/React.createElement(Segmented, {
    label: "Mode de l'accent",
    value: theme.auto ? 'auto' : 'manual',
    onChange: v => set({
      auto: v === 'auto',
      accent: v === 'auto' ? '#7CC4FF' : theme.accent
    }),
    options: [{
      value: 'auto',
      label: 'Auto (extraite du fond)'
    }, {
      value: 'manual',
      label: 'Manuelle'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'center',
      gap: '12px 16px'
    }
  }, SW.map(([n, hex]) => /*#__PURE__*/React.createElement(Swatch, {
    key: hex,
    color: hex,
    label: n,
    pressed: !theme.auto && theme.accent.toLowerCase() === hex.toLowerCase(),
    onClick: () => set({
      auto: false,
      accent: hex
    })
  })), color('Personnalisée', theme.accent, accent => set({
    auto: false,
    accent
  })))), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "Verre"
  }, /*#__PURE__*/React.createElement(Slider, {
    variant: "accent",
    label: "Flou du verre",
    value: theme.blur,
    max: 120,
    valueText: theme.blur + ' px',
    onChange: blur => set({
      blur
    })
  }), /*#__PURE__*/React.createElement(Slider, {
    variant: "accent",
    label: "Opacit\xE9 du verre",
    value: theme.opacity,
    max: 1,
    step: 0.01,
    valueText: Math.round(theme.opacity * 100) + ' %',
    onChange: opacity => set({
      opacity
    })
  }), /*#__PURE__*/React.createElement(Slider, {
    variant: "accent",
    label: "Arrondi",
    value: theme.radius,
    max: 40,
    valueText: theme.radius + ' px',
    onChange: radius => set({
      radius
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13
    }
  }, "Densit\xE9"), /*#__PURE__*/React.createElement(Segmented, {
    label: "Densit\xE9",
    value: theme.density,
    onChange: density => set({
      density
    }),
    options: [{
      value: 'compact',
      label: 'Compacte'
    }, {
      value: 'comfortable',
      label: 'Aérée'
    }]
  }))), /*#__PURE__*/React.createElement(DrawerSection, {
    title: "G\xE9n\xE9ral"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13
    }
  }, "Mode"), /*#__PURE__*/React.createElement(Segmented, {
    label: "Mode",
    value: settings.mode,
    onChange: mode => setSettings({
      ...settings,
      mode
    }),
    options: [{
      value: 'fullscreen',
      label: 'Plein écran'
    }, {
      value: 'window',
      label: 'Fenêtre'
    }]
  })), /*#__PURE__*/React.createElement(Checkbox, {
    label: "Toujours au-dessus",
    hint: settings.mode !== 'window' ? 'Mode fenêtre uniquement' : undefined,
    disabled: settings.mode !== 'window'
  }), /*#__PURE__*/React.createElement(Select, {
    label: "\xC9cran",
    value: "mouse",
    hint: "Jamais par-dessus un jeu ou une vid\xE9o en plein \xE9cran s'il y a un autre \xE9cran",
    options: [{
      value: 'mouse',
      label: 'Écran de la souris'
    }, {
      value: 'primary',
      label: 'Écran principal'
    }]
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Raccourci",
    value: "a",
    options: [{
      value: 'a',
      label: 'Win+Alt+Espace'
    }, {
      value: 'b',
      label: 'Win+Maj+Espace'
    }, {
      value: 'c',
      label: 'Ctrl+Alt+Espace'
    }]
  }), /*#__PURE__*/React.createElement(Select, {
    label: "Barre de commande seule",
    value: "a",
    options: [{
      value: 'a',
      label: 'Alt+Espace'
    }, {
      value: 'b',
      label: 'Win+Ctrl+Espace'
    }, {
      value: 'c',
      label: 'Ctrl+Maj+Espace'
    }]
  }), /*#__PURE__*/React.createElement(Checkbox, {
    label: "R\xE9duire les animations",
    checked: settings.reduceMotion,
    onChange: reduceMotion => setSettings({
      ...settings,
      reduceMotion
    })
  })));
}
function App() {
  const [profiles, setProfiles] = React.useState(INITIAL_PROFILES);
  const [active, setActive] = React.useState('default');
  const [editing, setEditing] = React.useState(false);
  const [settingsOpen, setSettingsOpen] = React.useState(false);
  const [theme, setTheme] = React.useState({
    background: 'wallpaper',
    from: '#16181f',
    to: '#0e1016',
    auto: true,
    accent: '#7CC4FF',
    blur: 48,
    opacity: 0.5,
    radius: 20,
    density: 'comfortable'
  });
  const [settings, setSettings] = React.useState({
    mode: 'fullscreen',
    reduceMotion: false
  });
  const root = React.useRef(null);
  const profile = profiles.find(p => p.id === active);
  const fullscreen = settings.mode === 'fullscreen';
  React.useEffect(() => {
    const s = document.documentElement.style;
    s.setProperty('--accent', theme.accent);
    s.setProperty('--on-accent', onAccent(theme.accent));
    s.setProperty('--glass', String(theme.opacity));
    s.setProperty('--radius', theme.radius + 'px');
    s.setProperty('--radius-panel', theme.radius + 8 + 'px');
    s.setProperty('--blur', theme.blur + 'px');
  }, [theme]);
  React.useEffect(() => {
    if (settings.reduceMotion) return;
    const x = window.innerWidth / 2,
      y = 60;
    root.current.querySelectorAll('[data-reveal], .pt-card').forEach(el => {
      const b = el.getBoundingClientRect();
      const d = Math.hypot(b.x + b.width / 2 - x, b.y + b.height / 2 - y);
      el.animate([{
        opacity: 0,
        transform: 'translateY(8px) scale(0.98)'
      }, {
        opacity: 1,
        transform: 'none'
      }], {
        duration: 180,
        delay: Math.min(100, d / 12),
        easing: 'cubic-bezier(0.2, 0.8, 0.2, 1)',
        fill: 'backwards'
      });
    });
  }, []);
  React.useEffect(() => {
    const onKey = e => {
      if (e.key === 'Escape') {
        if (settingsOpen) setSettingsOpen(false);else if (editing) setEditing(false);
      }
      if (e.ctrlKey && /^[1-9]$/.test(e.key) && profiles[+e.key - 1]) {
        e.preventDefault();
        setActive(profiles[+e.key - 1].id);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [settingsOpen, editing, profiles]);
  const update = fn => setProfiles(ps => ps.map(p => p.id === active ? fn(p) : p));
  const addWidget = type => {
    if (typeof type !== 'string') {
      // « + » profile button: new blank profile
      const id = 'p' + Date.now();
      setProfiles(ps => [...ps, {
        id,
        name: 'Sans nom',
        focus: false,
        widgets: []
      }]);
      setActive(id);
      setEditing(true);
      return;
    }
    const [w, h] = WIDGETS[type].size;
    update(p => {
      const y = p.widgets.reduce((m, x) => Math.max(m, x.y + x.h), 0);
      return {
        ...p,
        widgets: [...p.widgets, {
          id: type + Date.now(),
          type,
          x: 0,
          y,
          w,
          h,
          settings: {}
        }]
      };
    });
  };
  const bg = `linear-gradient(135deg, ${theme.from}, ${theme.to})`;
  return /*#__PURE__*/React.createElement("div", {
    ref: root,
    style: {
      position: 'relative',
      height: '100%',
      overflow: 'hidden',
      background: fullscreen ? 'var(--bg)' : 'var(--bg)'
    },
    "data-reduce-motion": settings.reduceMotion || undefined
  }, /*#__PURE__*/React.createElement("div", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      overflow: 'hidden',
      pointerEvents: 'none'
    }
  }, fullscreen && theme.background === 'gradient' && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: bg
    }
  })), /*#__PURE__*/React.createElement("main", {
    style: fullscreen ? {
      position: 'relative',
      boxSizing: 'border-box',
      width: 'min(1280px, calc(100% - 96px))',
      maxHeight: 'calc(100% - 96px)',
      margin: '48px auto',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      overflow: 'auto',
      background: 'var(--glass-sheen), var(--panel-bg)',
      border: '1px solid var(--glass-edge)',
      borderRadius: 'var(--radius-panel)',
      backdropFilter: 'var(--glass-filter)',
      WebkitBackdropFilter: 'var(--glass-filter)',
      boxShadow: profile.widgets.some(w => w.type === 'claude') && false ? 'var(--halo-bypass)' : 'var(--glass-rim), 0 40px 100px -30px rgb(0 0 0 / .65)'
    } : {
      position: 'relative',
      boxSizing: 'border-box',
      height: '100%',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      overflow: 'auto',
      background: 'var(--glass-sheen), var(--panel-bg)'
    }
  }, /*#__PURE__*/React.createElement(Header, {
    profiles: profiles,
    active: active,
    setActive: id => {
      setActive(id);
    },
    editing: editing,
    setEditing: setEditing,
    settingsOpen: settingsOpen,
    setSettingsOpen: setSettingsOpen,
    onAdd: addWidget,
    renameActive: name => update(p => ({
      ...p,
      name
    })),
    toggleFocus: () => update(p => ({
      ...p,
      focus: !p.focus
    })),
    fullscreen: fullscreen
  }), /*#__PURE__*/React.createElement(Grid, {
    profile: profile,
    editing: editing,
    density: theme.density,
    onRemove: id => update(p => ({
      ...p,
      widgets: p.widgets.filter(w => w.id !== id)
    })),
    onSave: (id, s) => update(p => ({
      ...p,
      widgets: p.widgets.map(w => w.id === id ? {
        ...w,
        settings: s
      } : w)
    }))
  })), settingsOpen && /*#__PURE__*/React.createElement(SettingsPanel, {
    theme: theme,
    setTheme: setTheme,
    settings: settings,
    setSettings: setSettings,
    onClose: () => setSettingsOpen(false)
  }));
}
Object.assign(window, {
  PhotonApp: App,
  WIDGETS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/photon/Shell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/photon/WidgetsInfo.jsx
try { (() => {
// Info widgets: Clock, System, Disks, Network, Weather. Recreated from src/renderer/widgets/*.
const {
  WidgetLabel,
  RollingNumber,
  MeterBar,
  Icon
} = window.PhotonDesignSystem_d1dfae;
const two = n => String(n).padStart(2, '0');
const capital = s => s.replace(/^./, l => l.toUpperCase());
const pad = (min, mid, max) => `clamp(${min}px, ${mid}cqmin, ${max}px)`;
function useTick(ms, fn) {
  const [v, setV] = React.useState(fn);
  React.useEffect(() => {
    const t = setInterval(() => setV(fn()), ms);
    return () => clearInterval(t);
  }, []);
  return v;
}
function ClockWidget({
  editing,
  settings = {},
  save
}) {
  const now = useTick(250, () => new Date());
  const time = `${two(now.getHours())}:${two(now.getMinutes())}` + (settings.seconds ? `:${two(now.getSeconds())}` : '');
  const date = capital(new Intl.DateTimeFormat('fr-FR', {
    weekday: 'long',
    day: 'numeric',
    month: 'long'
  }).format(now));
  const span = settings.seconds ? 4.25 : 2.75;
  const editRows = editing ? 36 : 0;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: pad(14, 6, 28),
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: `min(96px, 100cqh - 2 * ${pad(14, 6, 28)} - 32px - ${editRows}px, (100cqw - 2 * ${pad(14, 6, 28)}) / ${span})`,
      fontWeight: 300,
      letterSpacing: '-0.04em',
      lineHeight: 1,
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(RollingNumber, {
    value: time
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'clamp(12px, 7cqw, 16px)',
      lineHeight: '20px',
      color: 'var(--text-muted)',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis'
    }
  }, date), editing && /*#__PURE__*/React.createElement("label", {
    style: {
      alignSelf: 'flex-start',
      minHeight: 24,
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 13,
      color: 'var(--text-muted)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: !!settings.seconds,
    onChange: e => save({
      ...settings,
      seconds: e.currentTarget.checked
    }),
    style: {
      width: 16,
      height: 16,
      margin: 0,
      accentColor: 'var(--accent)'
    }
  }), /*#__PURE__*/React.createElement("span", null, "Afficher les secondes")));
}
function Measure({
  name,
  value,
  temp,
  detail
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 8,
      fontSize: 13
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, name), temp && /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--text-faint)'
    }
  }, temp), /*#__PURE__*/React.createElement("span", {
    style: {
      fontVariantNumeric: 'tabular-nums',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement(RollingNumber, {
    value: String(value)
  }), "\xA0%")), /*#__PURE__*/React.createElement(MeterBar, {
    value: value / 100
  }), detail && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--text-faint)'
    }
  }, detail));
}
function SystemWidget({
  h
}) {
  const s = useTick(2000, () => ({
    cpu: 12 + Math.round(Math.random() * 30),
    ram: 58 + Math.round(Math.random() * 6),
    gpu: 4 + Math.round(Math.random() * 12)
  }));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: pad(12, 10, 24),
      display: 'flex',
      flexDirection: 'column',
      gap: 'clamp(6px, 4.5cqh, 14px)',
      lineHeight: 1.3
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "Syst\xE8me"), /*#__PURE__*/React.createElement(Measure, {
    name: "CPU",
    value: s.cpu,
    temp: "54\xB0"
  }), /*#__PURE__*/React.createElement(Measure, {
    name: "RAM",
    value: s.ram,
    detail: h >= 3 ? `${(s.ram * 0.318).toFixed(1).replace('.', ',')} / 31,8 Go` : ''
  }), /*#__PURE__*/React.createElement(Measure, {
    name: "GPU",
    value: s.gpu,
    temp: "41\xB0"
  }));
}
function DisksWidget() {
  const others = [['D:', '1,2', 'To', 0.42], ['E:', '86', 'Go', 0.91]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 'clamp(8px, 7cqh, 14px)'
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "Disque"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'baseline',
      columnGap: 8,
      rowGap: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 'clamp(18px, min(11.2cqw, 22cqh), 40px)',
      fontWeight: 300,
      lineHeight: 1,
      fontVariantNumeric: 'tabular-nums'
    }
  }, /*#__PURE__*/React.createElement(RollingNumber, {
    value: "412"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "Go libres sur C:")), /*#__PURE__*/React.createElement(MeterBar, {
    value: 0.56
  }), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      overflow: 'hidden'
    }
  }, others.map(([l, v, u, used]) => /*#__PURE__*/React.createElement("li", {
    key: l,
    style: {
      display: 'grid',
      gridTemplateColumns: '1.5em 3.6em 1fr',
      alignItems: 'center',
      columnGap: 8,
      fontSize: 13,
      lineHeight: '16px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-muted)'
    }
  }, l), /*#__PURE__*/React.createElement("span", {
    style: {
      textAlign: 'right',
      whiteSpace: 'nowrap'
    }
  }, v, " ", u), /*#__PURE__*/React.createElement(MeterBar, {
    value: used,
    thickness: 3
  })))));
}
function NetworkWidget() {
  const [hist, setHist] = React.useState(() => Array.from({
    length: 30
  }, () => 200000 + Math.random() * 1800000));
  React.useEffect(() => {
    const t = setInterval(() => setHist(h => [...h.slice(1), 200000 + Math.random() * 1800000]), 1000);
    return () => clearInterval(t);
  }, []);
  const fmt = b => b < 1e6 ? `${Math.round(b / 1000)} Ko/s` : `${(b / 1e6).toFixed(1).replace('.', ',')} Mo/s`;
  const peak = Math.max(...hist, 1);
  const path = hist.map((v, i) => `${i ? 'L' : 'M'}${(i * 100 / 29).toFixed(1)},${(30 - v / peak * 28).toFixed(1)}`).join(' ');
  const p = {
    margin: 0,
    display: 'flex',
    alignItems: 'center',
    gap: 6,
    fontSize: 'clamp(14px, 8cqmin, 20px)',
    fontVariantNumeric: 'tabular-nums',
    whiteSpace: 'nowrap'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: pad(12, 9, 20),
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "R\xE9seau"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: '4px 16px'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: p
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-down",
    weight: "bold",
    size: 14,
    label: "Re\xE7u"
  }), fmt(hist[29])), /*#__PURE__*/React.createElement("p", {
    style: {
      ...p,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "arrow-up",
    weight: "bold",
    size: 14,
    label: "Envoy\xE9"
  }), fmt(hist[29] / 9))), /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 100 30",
    preserveAspectRatio: "none",
    "aria-hidden": "true",
    style: {
      flex: 1,
      minHeight: 0,
      width: '100%'
    }
  }, /*#__PURE__*/React.createElement("path", {
    d: `${path} L100,30 L0,30 Z`,
    style: {
      fill: 'color-mix(in srgb, var(--accent) 18%, transparent)'
    }
  }), /*#__PURE__*/React.createElement("path", {
    d: path,
    style: {
      fill: 'none',
      stroke: 'var(--accent)',
      strokeWidth: 1.5,
      vectorEffect: 'non-scaling-stroke'
    }
  })));
}
function WeatherWidget({
  w
}) {
  const days = [['dim', 'cloud-rain', 9, 13], ['lun', 'cloud', 8, 12], ['mar', 'cloud-sun', 7, 14], ['mer', 'sun', 6, 15]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: pad(12, 9, 20),
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "cloud-sun",
    weight: "duotone",
    size: 44,
    color: "var(--accent)"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 'clamp(26px, 16cqmin, 44px)',
      fontWeight: 300,
      lineHeight: 1
    }
  }, "12\xB0"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "Peu nuageux"))), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, "Lyon ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-faint)'
    }
  }, "\xB7 8\xB0 / 14\xB0")), w >= 5 && /*#__PURE__*/React.createElement("ul", {
    style: {
      display: 'flex',
      margin: '4px 0 0',
      padding: 0,
      listStyle: 'none',
      gap: 6
    }
  }, days.map(([d, ic, lo, hi]) => /*#__PURE__*/React.createElement("li", {
    key: d,
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 4,
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", null, d), /*#__PURE__*/React.createElement(Icon, {
    name: ic,
    weight: "duotone",
    size: 20
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-faint)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, lo, "\xB0 ", hi, "\xB0")))));
}
Object.assign(window, {
  ClockWidget,
  SystemWidget,
  DisksWidget,
  NetworkWidget,
  WeatherWidget,
  useTick,
  pad
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/photon/WidgetsInfo.jsx", error: String((e && e.message) || e) }); }

// ui_kits/photon/WidgetsMedia.jsx
try { (() => {
// Media + Claude widgets: Pomodoro, Volume, Music, Claude. Recreated from src/renderer/widgets/*.
const {
  WidgetLabel,
  ProgressRing,
  PlayButton,
  IconButton,
  Slider,
  Segmented,
  Chip,
  Approval,
  Icon
} = window.PhotonDesignSystem_d1dfae;
function PomodoroWidget({
  editing
}) {
  const box = React.useRef(null);
  const [narrow, setNarrow] = React.useState(false); // column layout when the card is too narrow for ring + side (Pomodoro.svelte @container)
  React.useEffect(() => {
    const ro = new ResizeObserver(([e]) => setNarrow(e.contentRect.width < 300));
    ro.observe(box.current);
    return () => ro.disconnect();
  }, []);
  const [running, setRunning] = React.useState(false);
  const [phase, setPhase] = React.useState('idle');
  const [left, setLeft] = React.useState(25 * 60);
  React.useEffect(() => {
    if (!running) return;
    const t = setInterval(() => setLeft(l => Math.max(0, l - 1)), 1000);
    return () => clearInterval(t);
  }, [running]);
  const total = phase === 'pause' ? 5 * 60 : 25 * 60;
  const clock = `${Math.floor(left / 60)}:${String(left % 60).padStart(2, '0')}`;
  const label = phase === 'focus' ? 'Travail' : phase === 'pause' ? 'Pause' : 'Pomodoro';
  const field = {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
    fontSize: 12,
    color: 'var(--text-muted)'
  };
  const num = {
    width: 72,
    minHeight: 28,
    padding: '0 8px',
    border: '1px solid var(--line)',
    borderRadius: 8,
    background: 'rgb(255 255 255 / .05)',
    color: 'var(--text)',
    fontFamily: 'inherit',
    boxSizing: 'border-box'
  };
  return /*#__PURE__*/React.createElement("div", {
    ref: box,
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 'clamp(12px, 8cqmin, 20px)',
      display: 'flex',
      flexDirection: narrow ? 'column' : 'row',
      justifyContent: narrow ? 'center' : 'flex-start',
      alignItems: 'center',
      gap: 'clamp(12px, 6cqmin, 20px)'
    }
  }, /*#__PURE__*/React.createElement(ProgressRing, {
    progress: left / total,
    label: clock,
    tone: phase === 'pause' ? 'secondary' : 'accent',
    size: 160,
    style: narrow ? {
      width: 'min(60%, 100cqh - 90px)',
      height: 'auto',
      aspectRatio: '1',
      minHeight: 0
    } : {
      height: '100%',
      width: 'auto',
      aspectRatio: '1',
      maxHeight: 160
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      alignItems: narrow ? 'center' : 'stretch',
      gap: 10
    }
  }, !narrow && /*#__PURE__*/React.createElement(WidgetLabel, null, label), editing ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("label", {
    style: field
  }, "Travail (min)", /*#__PURE__*/React.createElement("input", {
    type: "number",
    defaultValue: 25,
    style: num
  })), /*#__PURE__*/React.createElement("label", {
    style: field
  }, "Pause (min)", /*#__PURE__*/React.createElement("input", {
    type: "number",
    defaultValue: 5,
    style: num
  }))) : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(PlayButton, {
    size: 38,
    playing: running,
    onClick: () => {
      setRunning(!running);
      if (phase === 'idle') setPhase('focus');
    }
  }), phase !== 'idle' && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(IconButton, {
    variant: "ghost",
    size: "sm",
    icon: "skip-forward",
    iconWeight: "fill",
    label: "Phase suivante",
    onClick: () => {
      const p = phase === 'focus' ? 'pause' : 'focus';
      setPhase(p);
      setLeft(p === 'pause' ? 300 : 1500);
    }
  }), /*#__PURE__*/React.createElement(IconButton, {
    variant: "ghost",
    size: "sm",
    icon: "arrow-counter-clockwise",
    iconWeight: "regular",
    label: "Arr\xEAter",
    onClick: () => {
      setRunning(false);
      setPhase('idle');
      setLeft(1500);
    }
  })))));
}
function VolumeWidget() {
  const [vol, setVol] = React.useState(62);
  const [muted, setMuted] = React.useState(false);
  const [current, setCurrent] = React.useState('casque');
  const devices = [['casque', 'Casque', 'Realtek Audio'], ['hp', 'Haut-parleurs', 'NVIDIA High Definition Audio'], ['tv', 'LG TV', 'Intel Display Audio']];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 'clamp(12px, 8cqmin, 20px)',
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "Son"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "ghost",
    icon: muted ? 'speaker-slash' : vol < 50 ? 'speaker-low' : 'speaker-high',
    iconWeight: "regular",
    iconSize: 20,
    label: muted ? 'Rétablir le son' : 'Couper le son',
    pressed: muted,
    onClick: () => setMuted(!muted),
    style: {
      color: 'var(--text)'
    }
  }), /*#__PURE__*/React.createElement(Slider, {
    value: vol,
    label: "Volume",
    muted: muted,
    onChange: v => {
      setVol(v);
      setMuted(false);
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 'none',
      minWidth: '3ch',
      textAlign: 'right',
      fontSize: 13,
      fontVariantNumeric: 'tabular-nums',
      color: 'var(--text-muted)'
    }
  }, vol)), /*#__PURE__*/React.createElement("ul", {
    style: {
      flex: 1,
      minHeight: 0,
      margin: 0,
      padding: 0,
      listStyle: 'none',
      overflowY: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 2
    }
  }, devices.map(([id, n, d]) => {
    const on = id === current;
    return /*#__PURE__*/React.createElement("li", {
      key: id
    }, /*#__PURE__*/React.createElement("button", {
      type: "button",
      "aria-pressed": on,
      onClick: () => setCurrent(id),
      style: {
        width: '100%',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'flex-start',
        padding: '6px 10px',
        borderRadius: 10,
        textAlign: 'left',
        cursor: 'pointer',
        fontFamily: 'inherit',
        border: '1px solid ' + (on ? 'color-mix(in srgb, var(--accent) 45%, transparent)' : 'transparent'),
        background: on ? 'color-mix(in srgb, var(--accent) 16%, transparent)' : 'none',
        color: on ? 'var(--text)' : 'var(--text-muted)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 13
      }
    }, n), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 11,
        color: 'var(--text-faint)'
      }
    }, d)));
  })));
}
function MusicWidget({
  w
}) {
  const [playing, setPlaying] = React.useState(true);
  const [time, setTime] = React.useState(74);
  const [vol, setVol] = React.useState(70);
  React.useEffect(() => {
    if (!playing) return;
    const t = setInterval(() => setTime(x => (x + 1) % 258), 1000);
    return () => clearInterval(t);
  }, [playing]);
  const clock = s => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      boxSizing: 'border-box',
      height: '100%',
      padding: 'clamp(12px, 7cqmin, 20px)',
      display: 'flex',
      alignItems: 'center',
      gap: 'clamp(12px, 5cqmin, 20px)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true",
    style: {
      position: 'absolute',
      inset: 0,
      background: 'radial-gradient(circle at 15% 50%, color-mix(in srgb, rgb(122 92 255) 55%, transparent), transparent 75%)',
      filter: 'saturate(1.6)',
      opacity: 0.5,
      pointerEvents: 'none'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 'none',
      height: '100%',
      aspectRatio: '1',
      maxWidth: '45%',
      display: 'grid',
      placeItems: 'center',
      borderRadius: 14,
      overflow: 'hidden',
      background: 'rgb(255 255 255 / .06)',
      color: 'var(--text-faint)',
      boxShadow: '0 10px 24px -12px rgb(0 0 0 / .7)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "music-notes",
    size: 28
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      flex: 1,
      minWidth: 0,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 15,
      fontWeight: 600,
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, "Nightcall"), /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      fontSize: 13,
      color: 'var(--text-muted)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, "Kavinsky")), /*#__PURE__*/React.createElement(IconButton, {
    variant: "ghost",
    icon: "arrow-square-out",
    iconWeight: "regular",
    iconSize: 18,
    label: "Ouvrir YT Music"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 11,
      color: 'var(--text-faint)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, /*#__PURE__*/React.createElement("span", null, clock(time)), /*#__PURE__*/React.createElement(Slider, {
    value: time,
    max: 258,
    label: "Position dans le morceau",
    onChange: setTime
  }), /*#__PURE__*/React.createElement("span", null, "4:18")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "ghost",
    icon: "skip-back",
    iconWeight: "fill",
    iconSize: 20,
    label: "Morceau pr\xE9c\xE9dent"
  }), /*#__PURE__*/React.createElement(PlayButton, {
    playing: playing,
    size: 40,
    onClick: () => setPlaying(!playing)
  }), /*#__PURE__*/React.createElement(IconButton, {
    variant: "ghost",
    icon: "skip-forward",
    iconWeight: "fill",
    iconSize: 20,
    label: "Morceau suivant"
  }), w >= 5 && /*#__PURE__*/React.createElement("label", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "speaker-high",
    size: 16
  }), /*#__PURE__*/React.createElement(Slider, {
    value: vol,
    label: "Volume",
    onChange: setVol,
    style: {
      width: 72,
      flex: 'none'
    }
  })))));
}
const QUICK = ['Corriger', 'Traduire', 'Résumer', 'Expliquer'];
function ClaudeWidget() {
  const [mode, setMode] = React.useState('question');
  const [confirm, setConfirm] = React.useState(false);
  const [draft, setDraft] = React.useState('');
  const [busy, setBusy] = React.useState(false);
  const [messages, setMessages] = React.useState([{
    role: 'user',
    text: 'Comment vider le cache DNS sous Windows ?'
  }, {
    role: 'assistant',
    text: 'Ouvre un terminal et lance :\n\nipconfig /flushdns\n\nWindows répond « Cache de résolution DNS vidé ». Pas besoin de redémarrer.'
  }]);
  const thread = React.useRef(null);
  React.useEffect(() => {
    if (thread.current) thread.current.scrollTop = thread.current.scrollHeight;
  }, [messages]);
  const send = text => {
    if (!text.trim() || busy) return;
    setMessages(m => [...m, {
      role: 'user',
      text
    }, {
      role: 'assistant',
      text: '',
      status: 'Réflexion…'
    }]);
    setDraft('');
    setBusy(true);
    setTimeout(() => {
      setMessages(m => [...m.slice(0, -1), {
        role: 'assistant',
        text: 'C\u2019est noté. Voici une réponse d\u2019exemple : dans ce prototype, Claude ne répond pas vraiment.'
      }]);
      setBusy(false);
    }, 1400);
  };
  const choose = m => {
    if (m === 'bypass' && mode !== 'bypass') setConfirm(true);else {
      setConfirm(false);
      setMode(m);
    }
  };
  return /*#__PURE__*/React.createElement("div", {
    "data-bypass": mode === 'bypass' || undefined,
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 18,
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      borderRadius: 'inherit',
      boxShadow: mode === 'bypass' ? 'inset 0 0 0 1px rgb(255 77 94 / .7), inset 0 0 40px -10px rgb(255 77 94 / .45)' : 'none',
      transition: 'box-shadow 150ms var(--ease-out)'
    }
  }, /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "Claude"), /*#__PURE__*/React.createElement(Segmented, {
    size: "sm",
    label: "Mode de Claude",
    value: mode,
    onChange: choose,
    options: [{
      value: 'question',
      label: 'Question',
      hint: 'Lit les fichiers donnés, ne modifie et ne lance rien'
    }, {
      value: 'agent',
      label: 'Agent',
      hint: 'Agit sur le PC, chaque action te sera demandée'
    }, {
      value: 'bypass',
      label: 'Bypass',
      hint: 'Agit sur le PC sans rien demander',
      danger: true
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto',
      display: 'flex',
      gap: 4
    }
  }, /*#__PURE__*/React.createElement(IconButton, {
    variant: "square",
    icon: "clock-counter-clockwise",
    iconWeight: "regular",
    label: "Historique"
  }), /*#__PURE__*/React.createElement(IconButton, {
    variant: "square",
    icon: "plus",
    iconWeight: "regular",
    label: "Nouvelle conversation",
    onClick: () => setMessages([]),
    disabled: busy || !messages.length
  }))), confirm && /*#__PURE__*/React.createElement(Approval, {
    tone: "danger",
    acceptLabel: "Activer",
    refuseLabel: "Annuler",
    onRefuse: () => setConfirm(false),
    onAccept: () => {
      setConfirm(false);
      setMode('bypass');
    }
  }, /*#__PURE__*/React.createElement("strong", null, "Bypass"), " : Claude agit sur ton PC (fichiers, commandes) sans rien te demander. Il revient en mode Question d\xE8s que Photon se ferme."), /*#__PURE__*/React.createElement("div", {
    ref: thread,
    style: {
      flex: '1 1 0',
      minHeight: 0,
      overflowY: 'auto',
      display: 'flex',
      flexDirection: 'column',
      gap: 14,
      fontSize: 13,
      userSelect: 'text'
    }
  }, messages.length === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 'auto 0',
      fontSize: 13,
      color: 'var(--text-faint)',
      textAlign: 'center'
    }
  }, "Pose une question, glisse un fichier ou colle une capture."), messages.map((m, i) => m.role === 'user' ? /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      alignSelf: 'flex-end',
      maxWidth: '85%',
      padding: '8px 12px',
      border: '1px solid var(--glass-edge)',
      borderRadius: '14px 14px 4px 14px',
      background: 'rgb(255 255 255 / .07)'
    }
  }, /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      whiteSpace: 'pre-wrap'
    }
  }, m.text)) : /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'flex-start',
      gap: 6
    }
  }, m.text && m.text.split('\n\n').map((para, j) => para.startsWith('ipconfig') ? /*#__PURE__*/React.createElement("pre", {
    key: j,
    style: {
      margin: 0,
      padding: '8px 10px',
      borderRadius: 8,
      background: 'rgb(0 0 0 / .3)',
      fontSize: 12,
      alignSelf: 'stretch'
    }
  }, para) : /*#__PURE__*/React.createElement("p", {
    key: j,
    style: {
      margin: 0,
      lineHeight: 1.5
    }
  }, para)), m.status && /*#__PURE__*/React.createElement("p", {
    style: {
      margin: 0,
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      color: 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: '50%',
      background: 'var(--accent)',
      boxShadow: '0 0 8px var(--accent)'
    }
  }), m.status), m.text && /*#__PURE__*/React.createElement(IconButton, {
    variant: "square",
    size: "sm",
    icon: "copy",
    iconWeight: "regular",
    iconSize: 14,
    label: "Copier la r\xE9ponse",
    style: {
      marginLeft: -6,
      color: 'var(--text-faint)'
    }
  })))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    icon: "clipboard-text",
    title: "Coller le texte copi\xE9 dans le champ"
  }, "Presse-papier"), QUICK.map(q => /*#__PURE__*/React.createElement(Chip, {
    key: q,
    disabled: busy,
    title: q + ' le texte copié'
  }, q))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 8,
      padding: '6px 6px 6px 12px',
      border: '1px solid var(--glass-edge)',
      borderRadius: 16,
      background: 'rgb(0 0 0 / .22)'
    }
  }, /*#__PURE__*/React.createElement("textarea", {
    rows: 1,
    value: draft,
    onChange: e => setDraft(e.currentTarget.value),
    onKeyDown: e => {
      if (e.key === 'Enter' && !e.shiftKey) {
        e.preventDefault();
        send(draft);
      }
    },
    placeholder: "Demande \xE0 Claude\u2026",
    "aria-label": "Question pour Claude",
    style: {
      flex: 1,
      minHeight: 22,
      maxHeight: 132,
      margin: '4px 0',
      padding: 0,
      border: 0,
      outline: 0,
      resize: 'none',
      background: 'none',
      color: 'var(--text)',
      fontFamily: 'inherit',
      fontSize: 13,
      lineHeight: '22px'
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": busy ? 'Arrêter' : 'Envoyer',
    title: busy ? 'Arrêter' : 'Envoyer (Entrée)',
    disabled: !busy && !draft.trim(),
    onClick: () => send(draft),
    style: {
      flex: 'none',
      width: 30,
      height: 30,
      display: 'grid',
      placeItems: 'center',
      padding: 0,
      border: 0,
      borderRadius: 10,
      background: 'var(--accent)',
      color: 'var(--on-accent)',
      cursor: 'pointer',
      opacity: !busy && !draft.trim() ? 0.4 : 1
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: busy ? 'stop' : 'arrow-up',
    weight: busy ? 'fill' : 'bold',
    size: 16
  }))));
}
Object.assign(window, {
  PomodoroWidget,
  VolumeWidget,
  MusicWidget,
  ClaudeWidget
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/photon/WidgetsMedia.jsx", error: String((e && e.message) || e) }); }

// ui_kits/photon/WidgetsTools.jsx
try { (() => {
// Tool widgets: Launcher, Folders, Calendar, Todo, Notes. Recreated from src/renderer/widgets/*.
const {
  WidgetLabel,
  Checkbox,
  TextField,
  Chip,
  Icon
} = window.PhotonDesignSystem_d1dfae;
function LauncherWidget({
  editing
}) {
  const [apps, setApps] = React.useState(['Discord', 'Steam', 'Visual Studio Code', 'Firefox', 'Spotify', 'OBS Studio']);
  const [hover, setHover] = React.useState(null);
  const tile = {
    width: 72,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: 8,
    padding: 0,
    border: 0,
    borderRadius: 12,
    background: 'none',
    cursor: 'pointer',
    transition: 'transform 300ms var(--ease-spring)'
  };
  const square = (h, add) => ({
    boxSizing: 'border-box',
    width: 64,
    height: 64,
    display: 'grid',
    placeItems: 'center',
    border: '1px ' + (add ? 'dashed' : 'solid') + ' var(--line)',
    borderRadius: 16,
    background: add ? 'transparent' : h ? 'rgb(255 255 255 / .12)' : 'rgb(255 255 255 / .07)'
  });
  const name = {
    maxWidth: '100%',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    fontSize: 12,
    color: 'var(--text-muted)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 'clamp(14px, 6cqmin, 24px)',
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      overflow: 'hidden auto'
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "Apps"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      alignItems: 'flex-start',
      gap: 16
    }
  }, apps.map(a => /*#__PURE__*/React.createElement("div", {
    key: a,
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    title: a,
    style: {
      ...tile,
      transform: hover === a ? 'translateY(-2px)' : 'none'
    },
    onMouseEnter: () => setHover(a),
    onMouseLeave: () => setHover(null)
  }, /*#__PURE__*/React.createElement("span", {
    style: square(hover === a)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "app-window",
    weight: "duotone",
    size: 32,
    color: "var(--accent)"
  })), /*#__PURE__*/React.createElement("span", {
    style: name
  }, a)), editing && /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": 'Retirer ' + a,
    onClick: () => setApps(apps.filter(x => x !== a)),
    style: {
      position: 'absolute',
      top: -6,
      right: -2,
      width: 20,
      height: 20,
      display: 'grid',
      placeItems: 'center',
      padding: 0,
      border: '1px solid var(--line)',
      borderRadius: '50%',
      background: 'var(--surface-chip)',
      color: 'var(--text)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    weight: "duotone",
    size: 14
  })))), editing && /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: tile
  }, /*#__PURE__*/React.createElement("span", {
    style: square(false, true)
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "plus",
    weight: "duotone",
    size: 32,
    color: "var(--accent)"
  })), /*#__PURE__*/React.createElement("span", {
    style: name
  }, "Ajouter"))));
}
function FoldersWidget({
  editing
}) {
  const favs = ['Documents', 'Téléchargements', 'Projets', 'Photos'];
  const recents = [['rapport-q3.pdf', 'file'], ['photon', 'folder'], ['facture-octobre.xlsx', 'file'], ['Captures', 'folder']];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 'clamp(12px, 8cqmin, 20px)',
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "Favoris"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, favs.map(f => /*#__PURE__*/React.createElement(Chip, {
    key: f,
    size: "md",
    icon: "folder"
  }, f)), editing && /*#__PURE__*/React.createElement(Chip, {
    size: "md",
    variant: "dashed",
    icon: /*#__PURE__*/React.createElement(Icon, {
      name: "plus",
      size: 14
    })
  }, "Ajouter")), /*#__PURE__*/React.createElement(WidgetLabel, {
    style: {
      marginTop: 4
    }
  }, "R\xE9cents"), /*#__PURE__*/React.createElement("ul", {
    style: {
      flex: 1,
      minHeight: 0,
      margin: 0,
      padding: 0,
      listStyle: 'none',
      overflow: 'hidden'
    }
  }, recents.map(([n, k]) => /*#__PURE__*/React.createElement("li", {
    key: n
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      minHeight: 28,
      padding: '0 6px',
      border: 0,
      borderRadius: 8,
      background: 'none',
      fontSize: 13,
      color: 'var(--text-muted)',
      textAlign: 'left',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: k,
    size: 16
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, n))))));
}
function CalendarWidget({
  editing
}) {
  const groups = [["Aujourd'hui", [['En cours', 'Point équipe produit', true], ['14:30', 'Revue design Photon'], ['18:00', 'Salle de sport']]], ['Demain', [['Journée', 'Anniversaire de Léa'], ['09:15', 'Dentiste']]], ['Lundi 3 nov.', [['10:00', 'Comité de pilotage'], ['12:30', 'Déjeuner avec Marc']]]];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 24,
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "Agenda"), editing ? /*#__PURE__*/React.createElement(TextField, {
    variant: "inset",
    label: "Adresse iCal secr\xE8te",
    placeholder: "https://calendar.google.com/calendar/ical/\u2026/basic.ics",
    hint: "Google Agenda \u203A Param\xE8tres de l'agenda \u203A Adresse secr\xE8te au format iCal"
  }) : /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '1 1 0',
      minHeight: 0,
      overflow: 'hidden',
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      WebkitMask: 'linear-gradient(#000 calc(100% - 24px), transparent)',
      mask: 'linear-gradient(#000 calc(100% - 24px), transparent)'
    }
  }, groups.map(([day, evs]) => /*#__PURE__*/React.createElement("section", {
    key: day,
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      margin: 0,
      fontSize: 12,
      fontWeight: 500,
      color: 'var(--text-muted)'
    }
  }, day), /*#__PURE__*/React.createElement("ul", {
    style: {
      margin: 0,
      padding: 0,
      listStyle: 'none',
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, evs.map(([t, title, now]) => /*#__PURE__*/React.createElement("li", {
    key: title,
    style: {
      display: 'grid',
      gridTemplateColumns: '6px 4.6em 1fr',
      alignItems: 'center',
      columnGap: 10,
      fontSize: 13,
      lineHeight: '18px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: '50%',
      background: now ? 'var(--accent)' : 'color-mix(in srgb, var(--accent) 60%, transparent)',
      boxShadow: now ? '0 0 8px var(--accent)' : 'none'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      color: now ? 'var(--accent)' : 'var(--text-muted)',
      fontVariantNumeric: 'tabular-nums',
      whiteSpace: 'nowrap'
    }
  }, t), /*#__PURE__*/React.createElement("span", {
    style: {
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, title))))))));
}
function TodoWidget() {
  const [tasks, setTasks] = React.useState([{
    id: 1,
    text: 'Envoyer le devis à Camille',
    done: false
  }, {
    id: 2,
    text: 'Appeler le garage',
    done: false
  }, {
    id: 3,
    text: 'Relire la doc des widgets',
    done: false
  }, {
    id: 4,
    text: 'Sauvegarder le NAS',
    done: true
  }]);
  const [draft, setDraft] = React.useState('');
  const [hover, setHover] = React.useState(null);
  const sorted = [...tasks.filter(t => !t.done), ...tasks.filter(t => t.done)];
  const left = tasks.filter(t => !t.done).length;
  const add = () => {
    if (!draft.trim()) return;
    setTasks([...tasks, {
      id: Date.now(),
      text: draft.trim(),
      done: false
    }]);
    setDraft('');
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 'clamp(12px, 9cqmin, 20px)',
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, {
    aside: `${left} à faire`
  }, "To-do"), /*#__PURE__*/React.createElement("ul", {
    style: {
      flex: 1,
      minHeight: 0,
      margin: 0,
      padding: 0,
      listStyle: 'none',
      overflowY: 'auto'
    }
  }, sorted.map(t => /*#__PURE__*/React.createElement("li", {
    key: t.id,
    onMouseEnter: () => setHover(t.id),
    onMouseLeave: () => setHover(null),
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      minHeight: 30,
      fontSize: 14
    }
  }, /*#__PURE__*/React.createElement(Checkbox, {
    variant: "task",
    checked: t.done,
    label: t.text,
    onChange: () => setTasks(tasks.map(x => x.id === t.id ? {
      ...x,
      done: !x.done
    } : x))
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      flex: 1,
      minWidth: 0,
      opacity: t.done ? 0.45 : 1,
      textDecoration: t.done ? 'line-through' : 'none',
      transition: 'opacity 200ms var(--ease-out)'
    }
  }, t.text), /*#__PURE__*/React.createElement("button", {
    type: "button",
    "aria-label": `Supprimer « ${t.text} »`,
    onClick: () => setTasks(tasks.filter(x => x.id !== t.id)),
    style: {
      width: 22,
      height: 22,
      display: 'grid',
      placeItems: 'center',
      padding: 0,
      border: 0,
      borderRadius: '50%',
      background: 'none',
      color: 'var(--text-faint)',
      opacity: hover === t.id ? 1 : 0,
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(Icon, {
    name: "x",
    size: 12
  }))))), /*#__PURE__*/React.createElement(TextField, {
    value: draft,
    onChange: e => setDraft(e.currentTarget.value),
    onKeyDown: e => e.key === 'Enter' && add(),
    placeholder: "Ajouter une t\xE2che\u2026",
    "aria-label": "Nouvelle t\xE2che"
  }));
}
function NotesWidget() {
  const [text, setText] = React.useState('Code portail : 4512B\n\nIdées widget :\n— minuteur cuisine\n— cours de la bourse');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      boxSizing: 'border-box',
      height: '100%',
      padding: 'clamp(12px, 9cqmin, 20px)',
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(WidgetLabel, null, "Notes"), /*#__PURE__*/React.createElement("textarea", {
    value: text,
    onChange: e => setText(e.currentTarget.value),
    placeholder: "Une id\xE9e, un num\xE9ro, une liste\u2026",
    "aria-label": "Notes",
    style: {
      flex: 1,
      minHeight: 0,
      padding: 0,
      border: 0,
      outline: 0,
      resize: 'none',
      background: 'none',
      color: 'var(--text)',
      fontFamily: 'inherit',
      fontSize: 14,
      lineHeight: 1.5
    }
  }));
}
Object.assign(window, {
  LauncherWidget,
  FoldersWidget,
  CalendarWidget,
  TodoWidget,
  NotesWidget
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/photon/WidgetsTools.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.FileChip = __ds_scope.FileChip;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.PlayButton = __ds_scope.PlayButton;

__ds_ns.MeterBar = __ds_scope.MeterBar;

__ds_ns.ProgressRing = __ds_scope.ProgressRing;

__ds_ns.RollingNumber = __ds_scope.RollingNumber;

__ds_ns.WidgetLabel = __ds_scope.WidgetLabel;

__ds_ns.Approval = __ds_scope.Approval;

__ds_ns.Checkbox = __ds_scope.Checkbox;

__ds_ns.Segmented = __ds_scope.Segmented;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Slider = __ds_scope.Slider;

__ds_ns.Swatch = __ds_scope.Swatch;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.Drawer = __ds_scope.Drawer;

__ds_ns.DrawerSection = __ds_scope.DrawerSection;

__ds_ns.Menu = __ds_scope.Menu;

__ds_ns.MenuItem = __ds_scope.MenuItem;

__ds_ns.MenuLabel = __ds_scope.MenuLabel;

__ds_ns.WidgetCard = __ds_scope.WidgetCard;

__ds_ns.Icon = __ds_scope.Icon;

__ds_ns.CommandBar = __ds_scope.CommandBar;

__ds_ns.Kbd = __ds_scope.Kbd;

__ds_ns.ProfilePill = __ds_scope.ProfilePill;

__ds_ns.ProfilePills = __ds_scope.ProfilePills;

__ds_ns.ResultIcon = __ds_scope.ResultIcon;

__ds_ns.ResultItem = __ds_scope.ResultItem;

})();
