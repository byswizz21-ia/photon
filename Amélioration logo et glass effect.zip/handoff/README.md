# Photon : logo animé + verre « fumé lumineux »

Copier le contenu de `handoff/` à la racine de `ergo-app/` (remplace 4 fichiers), puis depuis Windows :

```powershell
npm run icons      # régénère logo.svg, icon.png, icon.ico, tray-*.ico
npm run typecheck; npm run lint; npm test
npm run dev
```

## Fichiers

- `src/renderer/lib/Logo.svelte` : nouveau logo. Props `size`, `ink`, `mode` (`idle` | `thinking` | `still`), `hover`.
  Animations en transform / opacity seulement, mises en pause quand Photon est caché (`app.visible`),
  coupées par « Réduire les animations » (règle existante de `app.css`).
- `src/renderer/App.svelte` : le logo de l'en-tête passe en `thinking` quand `claudeState().busy` est vrai ;
  panneau fumé lumineux (plein écran et mode fenêtre) ; lueurs du voile à 32 %, voile plein écran à 40 %.
- `src/renderer/app.css` : nouveaux tokens `--panel-tint`, `--panel-filter`, `--panel-sheen`, `--panel-light`,
  `--panel-edge`, `--grain`. `--glass-*` inchangés : cartes, menus, barre et mini-mode gardent leur verre.
- `scripts/make-icons.mjs` : icônes au nouveau dessin (traînée en segments, cœur blanc, lueur).

## À savoir

- `--panel-tint` vaut `--glass + 0,06` : le réglage « opacité » du thème reste actif.
- Le liseré dégradé (`.panel::after`) défile avec le contenu si le panneau déborde et défile (rare en plein écran).
